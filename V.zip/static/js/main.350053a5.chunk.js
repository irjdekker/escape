(this["webpackJsonpfestiviti-portal"] = this["webpackJsonpfestiviti-portal"] || []).push([
    [0], {
        109: function(e, t, i) {},
        122: function(e, t, i) {},
        225: function(e, t, i) {},
        249: function(e, t, i) {},
        250: function(e, t, i) {},
        251: function(e, t, i) {},
        252: function(e, t, i) {},
        266: function(e, t, i) {},
        301: function(e, t, i) {},
        302: function(e, t, i) {},
        369: function(e, t, i) {},
        371: function(e, t, i) {},
        372: function(e, t, i) {},
        373: function(e, t, i) {},
        537: function(e, t, i) {},
        538: function(e, t, i) {},
        550: function(e, t, i) {},
        551: function(e, t, i) {},
        552: function(e, t, i) {},
        553: function(e, t, i) {},
        554: function(e, t, i) {},
        555: function(e, t, i) {},
        556: function(e, t, i) {},
        557: function(e, t, i) {},
        558: function(e, t, i) {},
        559: function(e, t, i) {},
        560: function(e, t, i) {},
        561: function(e, t, i) {},
        562: function(e, t, i) {},
        563: function(e, t, i) {},
        564: function(e, t, i) {},
        639: function(e, t, i) {},
        640: function(e, t, i) {},
        641: function(e, t, i) {
            "use strict";
            i.r(t);
            var s = i(1),
                n = i(0),
                a = i.n(n),
                c = i(20),
                r = i.n(c),
                o = (i(301), i(60)),
                l = (i.p, i(302), i(11)),
                d = i(12),
                j = i(14),
                h = i(13),
                u = i.p + "static/media/key.ec05470a.svg",
                b = i.p + "static/media/mail.03e2f495.svg",
                g = i.p + "static/media/logo.a535b073.png",
                m = i.p + "static/media/background.80d3d199.jpg",
                p = (i(122), i(645)),
                x = i(19),
                O = i.n(x),
                A = i(30),
                f = !1,
                v = (O()(".login"), O()(".app"));

            function y(e, t) {
                f || (f = !0, function(e, t) {
                    O()(".ripple").remove();
                    var i = e.offset().top,
                        s = e.offset().left,
                        n = t.pageX - s,
                        a = t.pageY - i,
                        c = O()("<div class='ripple'></div>");
                    c.css({
                        top: a,
                        left: n
                    }), e.append(c)
                }(O()(e), t), O()(e).addClass("processing"))
            }

            function w(e) {
                console.log("test"), y(O()(".login__submit"), e)
            }

            function k() {
                O()(".ripple").remove(), O()(".login__submit").removeClass("processing"), f = !1
            }

            function C() {
                O()(".login__submit").addClass("success"), setTimeout((function() {
                    v.show(), v.css("top"), v.addClass("active")
                }), 330), setTimeout((function() {
                    window.location.href = ""
                }), 400)
            }
            var E = i(209),
                I = i(267),
                B = (i(303), i(132)),
                S = localStorage.getItem("lang-pref");
            console.log(S), E.a.use(I.a).use(B.e).init({
                lng: S,
                ns: ["games", "translation"],
                fallbackLng: "nl",
                debug: !0,
                whitelist: ["nl", "fr"],
                backend: {
                    loadPath: "http://localhost:8000/locales/{{lng}}/{{ns}}.json",
                    crossDomain: !0
                }
            });
            var L = E.a,
                Q = i(78);
            Q.a, Q.a.Item;
            var F = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            ordernumber: "",
                            email: "",
                            error_message: "",
                            show_error: !1
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "handleChange",
                        value: function(e, t) {
                            "ordernumber" == t && this.setState({
                                ordernumber: e.target.value
                            }), "email" == t && this.setState({
                                email: e.target.value
                            })
                        }
                    }, {
                        key: "login1",
                        value: function(e) {
                            w(e)
                        }
                    }, {
                        key: "login2",
                        value: function(e) {
                            w(e)
                        }
                    }, {
                        key: "handleClick",
                        value: function(e) {
                            var t = this,
                                i = this.props.t;
                            "" != this.state.ordernumber && "" != this.state.email && (w(e), console.log("http://localhost:8000/api/login"), fetch("http://localhost:8000/api/login", {
                                method: "GET",
                                headers: {
                                    Authorization: "Basic " + btoa(this.state.ordernumber.toLowerCase().trim() + ":" + this.state.email.toLowerCase().trim())
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(e) {
                                localStorage.setItem("user", JSON.stringify(e)), C()
                            })).catch((function(e) {
                                t.setState({
                                    error_message: i("login-wrong")
                                }), k(), t.setState({
                                    show_error: !0
                                })
                            })))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsx)("div", {
                                className: "cont",
                                style: {
                                    backgroundImage: "url(" + m + ")"
                                },
                                children: Object(s.jsx)("div", {
                                    className: "demo",
                                    children: Object(s.jsxs)("div", {
                                        className: "login",
                                        children: [Object(s.jsx)("div", {
                                            className: "login__check",
                                            children: Object(s.jsx)("img", {
                                                className: "logo",
                                                src: g
                                            })
                                        }), Object(s.jsxs)("div", {
                                            className: "login__form",
                                            children: [Object(s.jsx)("p", {
                                                id: "error_message",
                                                style: {
                                                    visibility: this.state.show_error ? "visible" : "invisible"
                                                },
                                                children: this.state.error_message
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("object", {
                                                    type: "image/svg+xml",
                                                    data: u,
                                                    height: "20"
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "number",
                                                    className: "login__input",
                                                    placeholder: t("ordernumber"),
                                                    value: this.state.ordernumber,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "ordernumber")
                                                    }
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("object", {
                                                    type: "image/svg+xml",
                                                    data: b,
                                                    height: "20"
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "email",
                                                    className: "login__input",
                                                    placeholder: t("email"),
                                                    value: this.state.email,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "email")
                                                    }
                                                })]
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                className: "login__submit",
                                                onClick: function(t) {
                                                    return e.handleClick(t)
                                                },
                                                children: t("start")
                                            }), Object(s.jsxs)("p", {
                                                className: "login__signup",
                                                children: [t("login-info"), Object(s.jsx)("br", {}), " ", Object(s.jsx)("a", {
                                                    style: {
                                                        color: "#F0730D"
                                                    },
                                                    href: "http://www.festiviti.eu",
                                                    children: t("more-info")
                                                })]
                                            })]
                                        })]
                                    })
                                })
                            })
                        }
                    }]), i
                }(n.Component),
                N = Object(A.h)(Object(p.a)()(F)),
                R = i(657),
                G = i(274),
                Y = i(651),
                M = i(50),
                H = i(656),
                J = i(649),
                D = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            ordernumber: "",
                            email: "",
                            games: null,
                            loading: !1
                        }, s.searchGames(), s
                    }
                    return Object(d.a)(i, [{
                        key: "searchGames",
                        value: function() {
                            var e = this,
                                t = encodeURIComponent(this.state.email),
                                i = encodeURIComponent(this.state.ordernumber),
                                s = "";
                            i.length > 0 ? s = "?ordernumber=" + i : t.length > 0 && (s = "?email=" + t), s.length > 0 && (console.log("http://localhost:8000/api/admin_search" + s), fetch("http://localhost:8000/api/admin_search" + s, {
                                method: "GET",
                                headers: {
                                    APIKEY: "SECRET"
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                t.games ? (console.log(t.games), e.setState({
                                    loading: !1,
                                    games: t.games,
                                    email: t.user.email,
                                    userid: t.user.id
                                })) : e.setState({
                                    loading: !1
                                })
                            })))
                        }
                    }, {
                        key: "resetGame",
                        value: function(e) {
                            var t = this,
                                i = this.state.games,
                                s = i[e];
                            i[e].resetting = !0, this.setState({
                                games: i
                            });
                            var n = "?order=" + s.order + "&sku=" + s.sku + "&user=" + this.state.userid;
                            fetch("http://localhost:8000/api/admin_reset" + n, {
                                method: "GET",
                                headers: {
                                    APIKEY: "SECRET"
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(s) {
                                console.log(s), i[e].resetting = !1, t.setState({
                                    games: i
                                })
                            }))
                        }
                    }, {
                        key: "sendEmail",
                        value: function(e) {
                            var t = this,
                                i = this.state.games,
                                s = i[e];
                            i[e].sending = !0, this.setState({
                                games: i
                            }), console.log(s);
                            var n = {
                                email: this.state.email,
                                financial_status: "paid",
                                order_number: s.order,
                                fulfillment_status: "no",
                                customer: {
                                    id: this.state.userid
                                }
                            };
                            console.log(JSON.stringify(n)), console.log("http://localhost:8000/api/new_order?force=true"), fetch("http://localhost:8000/api/new_order?force=true", {
                                method: "POST",
                                headers: {
                                    APIKEY: "SECRET",
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(n)
                            }).then((function(e) {
                                return console.log(e)
                            })).then((function(s) {
                                console.log(s), i[e].sending = !1, t.setState({
                                    games: i
                                })
                            }))
                        }
                    }, {
                        key: "handleClick",
                        value: function(e) {
                            this.searchGames()
                        }
                    }, {
                        key: "handleChange",
                        value: function(e, t) {
                            "ordernumber" == t && this.setState({
                                ordernumber: e.target.value
                            }), "email" == t && this.setState({
                                email: e.target.value
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = [{
                                    title: "Order ID",
                                    dataIndex: "order",
                                    key: "order"
                                }, {
                                    title: "SKU",
                                    dataIndex: "sku",
                                    key: "sku"
                                }, {
                                    title: "Order Date",
                                    dataIndex: "order_date",
                                    key: "order_date"
                                }, {
                                    title: "Activation Time",
                                    dataIndex: "activationTime",
                                    key: "activationTime"
                                }, {
                                    title: "Actions",
                                    key: "action",
                                    render: function(t, i, n) {
                                        return Object(s.jsxs)(R.b, {
                                            size: "middle",
                                            children: [Object(s.jsx)("span", {
                                                children: i.resetting ? Object(s.jsx)(G.a, {}) : Object(s.jsx)("a", {
                                                    disabled: !i.activationTime,
                                                    onClick: function() {
                                                        return e.resetGame(n)
                                                    },
                                                    children: "Reset Access"
                                                })
                                            }), Object(s.jsx)("span", {
                                                children: i.sending ? Object(s.jsx)(G.a, {}) : Object(s.jsx)("a", {
                                                    onClick: function() {
                                                        return e.sendEmail(n)
                                                    },
                                                    children: "Send Email"
                                                })
                                            })]
                                        })
                                    }
                                }];
                            return this.state.userid ? Object(s.jsxs)("div", {
                                children: [Object(s.jsx)(Y.a, {
                                    ghost: !1,
                                    onBack: function() {
                                        return e.setState({
                                            userid: null,
                                            email: "",
                                            ordernumber: ""
                                        })
                                    },
                                    title: "User Overview",
                                    subTitle: "All orders",
                                    extra: [Object(s.jsx)(M.a, {
                                        type: "primary",
                                        onClick: function() {
                                            return e.searchGames()
                                        },
                                        children: "refresh"
                                    }, "1")],
                                    children: Object(s.jsxs)(H.b, {
                                        size: "small",
                                        column: 3,
                                        children: [Object(s.jsx)(H.b.Item, {
                                            label: "Email",
                                            children: this.state.email
                                        }), Object(s.jsx)(H.b.Item, {
                                            label: "User Id",
                                            children: this.state.userid
                                        })]
                                    })
                                }), Object(s.jsx)(J.a, {
                                    dataSource: this.state.games,
                                    columns: t,
                                    pagination: !1
                                })]
                            }) : Object(s.jsx)("div", {
                                className: "cont",
                                style: {
                                    backgroundImage: "url(" + m + ")"
                                },
                                children: Object(s.jsx)("div", {
                                    className: "demo",
                                    style: {
                                        height: 250,
                                        width: 300,
                                        "margin-left": -150
                                    },
                                    children: Object(s.jsxs)("div", {
                                        className: "login",
                                        style: {
                                            height: 250,
                                            width: 300
                                        },
                                        children: [Object(s.jsx)("div", {
                                            className: "login__check"
                                        }), Object(s.jsxs)("div", {
                                            className: "login__form",
                                            children: [Object(s.jsx)("div", {
                                                className: "login__row",
                                                children: Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "number",
                                                    className: "login__input",
                                                    placeholder: "ordernummmer",
                                                    value: this.state.ordernumber,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "ordernumber")
                                                    }
                                                })
                                            }), Object(s.jsx)("div", {
                                                className: "login__row",
                                                children: Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "email",
                                                    className: "login__input",
                                                    placeholder: "email",
                                                    value: this.state.email,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "email")
                                                    }
                                                })
                                            }), Object(s.jsx)(M.a, {
                                                type: "primary",
                                                style: {
                                                    margin: 20,
                                                    background: "#F0730D",
                                                    borderColor: "#F0730D"
                                                },
                                                loading: this.state.loading,
                                                onClick: function(t) {
                                                    e.setState({
                                                        loading: !0
                                                    }), e.handleClick(t)
                                                },
                                                children: "ZOEKEN"
                                            })]
                                        })]
                                    })
                                })
                            })
                        }
                    }]), i
                }(n.Component),
                V = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            ordernumber: "",
                            email: "",
                            error_message: "",
                            show_error: !1
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "login1",
                        value: function(e) {
                            w(e)
                        }
                    }, {
                        key: "login2",
                        value: function(e) {
                            w(e)
                        }
                    }, {
                        key: "handleChange",
                        value: function(e, t) {
                            "ordernumber" == t && this.setState({
                                ordernumber: e.target.value.toUpperCase()
                            }), "email" == t && this.setState({
                                email: e.target.value
                            })
                        }
                    }, {
                        key: "handleClick",
                        value: function(e) {
                            var t = this;
                            "" != this.state.ordernumber && "" != this.state.email && (w(e), fetch("http://localhost:8000/api/login", {
                                method: "GET",
                                headers: {
                                    Authorization: "Basic " + btoa(this.state.ordernumber + ":" + this.state.email)
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(e) {
                                localStorage.setItem("user", JSON.stringify(e)), C()
                            })).catch((function(e) {
                                t.setState({
                                    error_message: "Je inloggegevens zijn foutief."
                                }), k(), t.setState({
                                    show_error: !0
                                })
                            })))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsx)("div", {
                                className: "cont",
                                style: {
                                    backgroundImage: "url(" + m + ")"
                                },
                                children: Object(s.jsx)("div", {
                                    className: "demo",
                                    children: Object(s.jsxs)("div", {
                                        className: "login",
                                        children: [Object(s.jsx)("div", {
                                            className: "login__check",
                                            children: Object(s.jsx)("img", {
                                                className: "logo",
                                                src: g
                                            })
                                        }), Object(s.jsxs)("div", {
                                            className: "login__form",
                                            children: [Object(s.jsx)("p", {
                                                id: "error_message",
                                                style: {
                                                    visibility: this.state.show_error ? "visible" : "invisible"
                                                },
                                                children: this.state.error_message
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("object", {
                                                    type: "image/svg+xml",
                                                    data: b,
                                                    height: "20"
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "number",
                                                    className: "login__input",
                                                    placeholder: t("group_name"),
                                                    value: this.state.ordernumber,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "ordernumber")
                                                    }
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("object", {
                                                    type: "image/svg+xml",
                                                    data: u,
                                                    height: "20"
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "email",
                                                    className: "login__input",
                                                    placeholder: t("group_password"),
                                                    value: this.state.email,
                                                    onChange: function(t) {
                                                        e.handleChange(t, "email")
                                                    }
                                                })]
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                className: "login__submit",
                                                onClick: function(t) {
                                                    return e.handleClick(t)
                                                },
                                                children: t("start")
                                            }), Object(s.jsxs)("p", {
                                                className: "login__signup",
                                                children: [t("group-info"), " ", Object(s.jsx)("a", {
                                                    href: "http://www.festiviti.eu",
                                                    children: t("more-info")
                                                })]
                                            })]
                                        })]
                                    })
                                })
                            })
                        }
                    }]), i
                }(n.Component),
                K = Object(p.a)()(V);
            i(109);
            var z = function() {
                var e = new Date(parseInt(localStorage.getItem("festiviti_start_time"))).getTime(),
                    t = parseInt(localStorage.getItem("festiviti_extra_time")),
                    i = parseInt(localStorage.getItem("festiviti_punish_time"));
                return document.getElementById("id"), setInterval((function() {
                    var s = (new Date).getTime(),
                        n = Math.floor((e - s) % 36e5 / 6e4) + 17 + t + i,
                        a = Math.floor((e - s) % 6e4 / 1e3) + 60,
                        c = document.getElementById("time");
                        if (n === 0 && a === 0) {
                            setTimeout(function() {
                                window.location.href = "http://localhost:8000/game/FB_ER03/test";
                            }, 2e3);
                        }
                        if (n < 0) {
                            n = 0;
                            a = 0;
                        }
                    c && (c.innerHTML = +("0" + n).slice(-2) + ":" + ("0" + a).slice(-2));                    
                }), 1e3);
            };
            var T = function(e) {
                    O()(document).ready((function(t) {
                        t(document).ready((function() {
                            var i = "";
                            i.toString(), t("#numbers button").click((function() {
                                var s = t(this).text().toString();
                                i += s;
                                var n = parseInt(i.length);
                                n--, t("#fields .numberfield:eq(" + n + ")").addClass("active"), 3 == n && ("8184" == i ? window.location.href = e : (t("#fields").addClass("miss"), i = "", setTimeout((function() {
                                    t("#fields .numberfield").removeClass("active")
                                }), 200), setTimeout((function() {
                                    t("#fields").removeClass("miss")
                                }), 500)))
                            })), t("#restartbtn").click((function() {
                                i = "", t("#fields .numberfield").removeClass("active"), t("#fields .numberfield").removeClass("right"), t("#numbers").removeClass("hide")
                            }))
                        }))
                    }))
                },
                U = (i(369), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            T("buttons")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsx)("div", {
                                className: "Agents_Codepad",
                                children: Object(s.jsx)("div", {
                                    id: "pincode",
                                    children: Object(s.jsx)("div", {
                                        className: "table",
                                        children: Object(s.jsxs)("div", {
                                            className: "cell",
                                            children: [Object(s.jsxs)("div", {
                                                id: "anleitung",
                                                children: [Object(s.jsx)("p", {
                                                    id: "time",
                                                    style: {
                                                        visibility: "hidden"
                                                    },
                                                    children: "\u00A0"
                                                }), Object(s.jsx)("p", {
                                                    id: "text1",
                                                    children: Object(s.jsx)("strong", {
                                                        children: e("agent-codepad")
                                                    })
                                                })]
                                            }), Object(s.jsx)("div", {
                                                id: "fields",
                                                children: Object(s.jsxs)("div", {
                                                    className: "grid",
                                                    children: [Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-4 numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-4 numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-4 numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-4 numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    })]
                                                })
                                            }), Object(s.jsx)("div", {
                                                id: "numbers",
                                                children: Object(s.jsxs)("div", {
                                                    className: "grid",
                                                    children: [Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "1"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "2"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "3"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "4"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "5"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "6"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "7"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "8"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "9"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3"
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "0"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "grid__col grid__col--1-of-3"
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        }
                    }]), i
                }(a.a.Component)),
                X = Object(p.a)(["games"])(U);
            var P = function(e) {
                    var t = "GGGG";

                    function i() {
                        console.log(t), "gbygr" == t && (window.location.href = e)
                    }
                    O()(".btn-blue").click((function() {
                        document.getElementById("blue_audio").play(), t = (t + "b").slice(-5), i()
                    })), O()(".btn-yellow").click((function() {
                        document.getElementById("yellow_audio").play(), t = (t + "y").slice(-5), i()
                    })), O()(".btn-green").click((function() {
                        document.getElementById("green_audio").play(), t = (t + "g").slice(-5), i()
                    })), O()(".btn-red").click((function() {
                        document.getElementById("red_audio").play(), t = (t + "r").slice(-5), i()
                    }))
                },
                W = i.p + "static/media/blue_audio.2ba8666d.mp3",
                Z = i.p + "static/media/red_audio.6f6e2e23.mp3",
                q = i.p + "static/media/yellow_audio.7205c38b.mp3",
                _ = i.p + "static/media/green_audio.a7a62033.mp3",
                $ = (i(225), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            P("morse")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                className: "Agents_Buttons",
                                children: [Object(s.jsx)("audio", {
                                    src: W,
                                    id: "blue_audio"
                                }), Object(s.jsx)("audio", {
                                    src: Z,
                                    id: "red_audio"
                                }), Object(s.jsx)("audio", {
                                    src: _,
                                    id: "green_audio"
                                }), Object(s.jsx)("audio", {
                                    src: q,
                                    id: "yellow_audio"
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: "\u00A0"
                                }), Object(s.jsxs)("div", {
                                    id: "centered",
                                    children: [Object(s.jsx)("span", {
                                        className: "btn-blue"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-red"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-green"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-yellow"
                                    })]
                                }), Object(s.jsx)("p", {
                                    className: "bottom",
                                    id: "text1"
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                ee = i(120),
                te = i.n(ee);
            i(370);
            var ie = function(e) {
                    ! function(e) {
                        if (window.styleFix && window.getComputedStyle) {
                            var t = window.PrefixFree = {
                                prefixCSS: function(e, s, n) {
                                    var a = t.prefix;
                                    if (t.functions.indexOf("linear-gradient") > -1 && (e = e.replace(/(\s|:|,)(repeating-)?linear-gradient\(\s*(-?\d*\.?\d*)deg/gi, (function(e, t, i, s) {
                                            return t + (i || "") + "linear-gradient(" + (90 - s) + "deg"
                                        }))), e = i("functions", "(\\s|:|,)", "\\s*\\(", "$1" + a + "$2(", e), e = i("keywords", "(\\s|:)", "(\\s|;|\\}|$)", "$1" + a + "$2$3", e), e = i("properties", "(^|\\{|\\s|;)", "\\s*:", "$1" + a + "$2:", e), t.properties.length) {
                                        var c = RegExp("\\b(" + t.properties.join("|") + ")(?!:)", "gi");
                                        e = i("valueProperties", "\\b", ":(.+?);", (function(e) {
                                            return e.replace(c, a + "$1")
                                        }), e)
                                    }
                                    return s && (e = i("selectors", "", "\\b", t.prefixSelector, e), e = i("atrules", "@", "\\b", "@" + a + "$1", e)), e = (e = e.replace(RegExp("-" + a, "g"), "-")).replace(/-\*-(?=[a-z]+)/gi, t.prefix)
                                },
                                property: function(e) {
                                    return (t.properties.indexOf(e) ? t.prefix : "") + e
                                },
                                value: function(e, s) {
                                    return e = i("functions", "(^|\\s|,)", "\\s*\\(", "$1" + t.prefix + "$2(", e), e = i("keywords", "(^|\\s)", "(\\s|$)", "$1" + t.prefix + "$2$3", e)
                                },
                                prefixSelector: function(e) {
                                    return e.replace(/^:{1,2}/, (function(e) {
                                        return e + t.prefix
                                    }))
                                },
                                prefixProperty: function(e, i) {
                                    var s = t.prefix + e;
                                    return i ? te.a.camelCase(s) : s
                                }
                            };
                            ! function() {
                                var e = {},
                                    i = [],
                                    s = getComputedStyle(document.documentElement, null),
                                    n = document.createElement("div").style,
                                    a = function(t) {
                                        if ("-" === t.charAt(0)) {
                                            i.push(t);
                                            var s = t.split("-"),
                                                n = s[1];
                                            for (e[n] = ++e[n] || 1; s.length > 3;) {
                                                s.pop();
                                                var a = s.join("-");
                                                c(a) && -1 === i.indexOf(a) && i.push(a)
                                            }
                                        }
                                    },
                                    c = function(e) {
                                        return te.a.camelCase(e) in n
                                    };
                                if (s.length > 0)
                                    for (var r = 0; r < s.length; r++) a(s[r]);
                                else
                                    for (var o in s) a(te.a.deCamelCase(o));
                                var l = {
                                    uses: 0
                                };
                                for (var d in e) {
                                    var j = e[d];
                                    l.uses < j && (l = {
                                        prefix: d,
                                        uses: j
                                    })
                                }
                                t.prefix = "-" + l.prefix + "-", t.Prefix = te.a.camelCase(t.prefix), t.properties = [];
                                for (r = 0; r < i.length; r++) {
                                    if (0 === (o = i[r]).indexOf(t.prefix)) {
                                        var h = o.slice(t.prefix.length);
                                        c(h) || t.properties.push(h)
                                    }
                                }
                                "Ms" != t.Prefix || "transform" in n || "MsTransform" in n || !("msTransform" in n) || t.properties.push("transform", "transform-origin"), t.properties.sort()
                            }(),
                            function() {
                                var e = {
                                    "linear-gradient": {
                                        property: "backgroundImage",
                                        params: "red, teal"
                                    },
                                    calc: {
                                        property: "width",
                                        params: "1px + 5%"
                                    },
                                    element: {
                                        property: "backgroundImage",
                                        params: "#foo"
                                    },
                                    "cross-fade": {
                                        property: "backgroundImage",
                                        params: "url(a.png), url(b.png), 50%"
                                    }
                                };
                                e["repeating-linear-gradient"] = e["repeating-radial-gradient"] = e["radial-gradient"] = e["linear-gradient"];
                                var i = {
                                    initial: "color",
                                    "zoom-in": "cursor",
                                    "zoom-out": "cursor",
                                    box: "display",
                                    flexbox: "display",
                                    "inline-flexbox": "display",
                                    flex: "display",
                                    "inline-flex": "display",
                                    grid: "display",
                                    "inline-grid": "display",
                                    "min-content": "width"
                                };
                                t.functions = [], t.keywords = [];
                                var s = document.createElement("div").style;

                                function n(e, t) {
                                    return s[t] = "", s[t] = e, !!s[t]
                                }
                                for (var a in e) {
                                    var c = e[a],
                                        r = c.property,
                                        o = a + "(" + c.params + ")";
                                    !n(o, r) && n(t.prefix + o, r) && t.functions.push(a)
                                }
                                for (var l in i) {
                                    !n(l, r = i[l]) && n(t.prefix + l, r) && t.keywords.push(l)
                                }
                            }(),
                            function() {
                                var i = {
                                        ":read-only": null,
                                        ":read-write": null,
                                        ":any-link": null,
                                        "::selection": null
                                    },
                                    s = {
                                        keyframes: "name",
                                        viewport: null,
                                        document: 'regexp(".")'
                                    };
                                t.selectors = [], t.atrules = [];
                                var n = e.appendChild(document.createElement("style"));

                                function a(e) {
                                    return n.textContent = e + "{}", !!n.sheet.cssRules.length
                                }
                                for (var c in i) {
                                    !a(o = c + (i[c] ? "(" + i[c] + ")" : "")) && a(t.prefixSelector(o)) && t.selectors.push(c)
                                }
                                for (var r in s) {
                                    var o;
                                    !a("@" + (o = r + " " + (s[r] || ""))) && a("@" + t.prefix + o) && t.atrules.push(r)
                                }
                                e.removeChild(n)
                            }(), t.valueProperties = ["transition", "transition-property"], e.className += " " + t.prefix, te.a.register(t.prefixCSS)
                        }

                        function i(e, i, s, n, a) {
                            if ((e = t[e]).length) {
                                var c = RegExp(i + "(" + e.join("|") + ")" + s, "gi");
                                a = a.replace(c, n)
                            }
                            return a
                        }
                    }(document.documentElement);
                    var t = 500,
                        i = [];

                    function s() {
                        i.push(setTimeout((function() {
                            document.getElementById("hide").style.visibility = "hidden", document.getElementById("long").play()
                        }), t)), i.push(setTimeout((function() {
                            document.getElementById("hide").style.visibility = "visible"
                        }), t + 800)), t = t + 800 + 500
                    }

                    function n() {
                        i.push(setTimeout((function() {
                            document.getElementById("hide").style.visibility = "hidden", document.getElementById("short").play()
                        }), t)), i.push(setTimeout((function() {
                            document.getElementById("hide").style.visibility = "visible"
                        }), t + 300)), t = t + 300 + 500
                    }

                    function a() {
                        i.push(setTimeout((function() {
                            c = !1, document.getElementById("morsebutton").innerHTML = "Start MORSE"
                        }), t))
                    }
                    var c = !1;

                    function r() {
                        console.log(c), c ? (! function() {
                            document.getElementById("hide").style.visibility = "visible";
                            for (var e = 0; e < i.length; e++) clearTimeout(i[e]);
                            i = [], c = !1
                        }(), document.getElementById("morsebutton").innerHTML = "Start MORSE") : (c = !0, document.getElementById("morsebutton").innerHTML = "Stop MORSE", document.getElementById("intro_nl").play(), t = 3e3, s(), n(), s(), t += 2e3, n(), s(), n(), n(), t += 2e3, s(), s(), s(), t += 2e3, n(), s(), s(), n(), t += 2e3, n(), n(), n(), s(), s(), t += 2e3, s(), n(), n(), s(), t += 2e3, s(), s(), s(), t += 2e3, n(), s(), s(), n(), t += 2e3, s(), n(), n(), t += 2e3, n(), t += 2e3, n(), n(), s(), t += 2e3, n(), s(), n(), a())
                    }
                    O()("#morsebutton").click((function() {
                        r()
                    })), O()("#loginbutton").click((function() {
                        ! function() {
                            var t = document.getElementById("username"),
                                i = document.getElementById("pass");
                            console.log(t), "AGENTX" == t.value.toUpperCase() && "UNDERCOVER" == i.value.toUpperCase() && (t.value = "", i.value = "", window.location.href = e)
                        }()
                    }))
                },
                se = i.p + "static/media/b1.5c5df4e3.png",
                ne = i.p + "static/media/b2.9c420ecc.png",
                ae = i.p + "static/media/short.7b9721bf.mp3",
                ce = i.p + "static/media/long.e21a5365.mp3",
                re = i.p + "static/media/morse_intro_nl.5e17eaa3.mp3",
                oe = i.p + "static/media/morse_intro_de.11a08a31.mp3",
                le = (i(371), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            ie("alarm")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Agent_Morse",
                                children: [Object(s.jsx)("audio", {
                                    src: re,
                                    id: "intro_nl"
                                }), Object(s.jsx)("audio", {
                                    src: oe,
                                    id: "intro_de"
                                }), Object(s.jsx)("audio", {
                                    src: ce,
                                    id: "long"
                                }), Object(s.jsx)("audio", {
                                    src: ae,
                                    id: "short"
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: "\u00A0"
                                }), Object(s.jsx)("div", {
                                    id: "logo",
                                    children: Object(s.jsx)("h1", {
                                        id: "text1",
                                        children: Object(s.jsxs)("i", {
                                            children: [" ", e("agent-access")]
                                        })
                                    })
                                }), Object(s.jsxs)("section", {
                                    className: "stark-login",
                                    children: [Object(s.jsx)("form", {
                                        action: "",
                                        method: "",
                                        children: Object(s.jsxs)("div", {
                                            id: "fade-box",
                                            children: [Object(s.jsx)("img", {
                                                src: se,
                                                className: "button"
                                            }), Object(s.jsx)("img", {
                                                src: ne,
                                                className: "button",
                                                id: "hide"
                                            }), Object(s.jsx)("input", {
                                                type: "text",
                                                name: "username",
                                                id: "username",
                                                placeholder: e("agent-username"),
                                                required: !0
                                            }), Object(s.jsx)("input", {
                                                type: "text",
                                                placeholder: e("agent-pass"),
                                                id: "pass",
                                                required: !0
                                            }), Object(s.jsx)("button", {
                                                id: "morsebutton",
                                                type: "button",
                                                children: e("agent-morse")
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                id: "loginbutton",
                                                children: e("agent-login")
                                            })]
                                        })
                                    }), Object(s.jsx)("div", {
                                        className: "hexagons"
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "circle1",
                                    children: Object(s.jsx)("div", {
                                        id: "inner-cirlce1",
                                        children: Object(s.jsx)("h2", {
                                            children: " "
                                        })
                                    })
                                }), Object(s.jsxs)("ul", {
                                    children: [Object(s.jsx)("li", {}), Object(s.jsx)("li", {}), Object(s.jsx)("li", {}), Object(s.jsx)("li", {}), Object(s.jsx)("li", {})]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                de = Object(p.a)(["games"])(le),
                je = i.p + "static/media/Fingerprint.82ef223e.png",
                he = i.p + "static/media/alarm.c74b0cc9.mp3",
                ue = (i(372), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            document.getElementById("1").checked && document.getElementById("2").checked && !document.getElementById("3").checked && !document.getElementById("4").checked && document.getElementById("5").checked && !document.getElementById("6").checked && document.getElementById("7").checked && (window.location.href = "secret")
                        }
                    }, {
                        key: "start",
                        value: function(e) {
                            document.getElementById("alarm").play(), document.getElementById("overlay").style.visibility = "hidden"
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Agents_Alarm",
                                children: [Object(s.jsx)("div", {
                                    onClick: this.start,
                                    id: "overlay",
                                    children: Object(s.jsx)("img", {
                                        id: "finger",
                                        src: je
                                    })
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: "\u00A0"
                                }), Object(s.jsx)("p", {
                                    id: "info",
                                    children: e("agent-alarm")
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "1",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        className: "tlabel",
                                        "data-off": "\u2716",
                                        "data-on": "\u2714"
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "2",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        "data-off": "\u25fc",
                                        "data-on": "\u25b6"
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "3",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        id: "b1",
                                        "data-off": e("agent-yellow"),
                                        "data-on": e("agent-blue")
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "4",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        id: "b2",
                                        "data-off": e("agent-stop"),
                                        "data-on": e("agent-start")
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "5",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        id: "b3",
                                        "data-off": e("agent-red"),
                                        "data-on": e("agent-green")
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "6",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        id: "b4",
                                        "data-off": e("agent-on"),
                                        "data-on": e("agent-off")
                                    })]
                                }), Object(s.jsxs)("span", {
                                    className: "toggle",
                                    children: [Object(s.jsx)("input", {
                                        onClick: this.check,
                                        id: "7",
                                        type: "checkbox"
                                    }), Object(s.jsx)("label", {
                                        "data-off": "1",
                                        "data-on": "2"
                                    })]
                                }), Object(s.jsxs)("p", {
                                    id: "serial",
                                    children: [e("agent-number"), " 56098712"]
                                }), Object(s.jsxs)("p", {
                                    id: "type",
                                    children: [e("agent-type"), " B17"]
                                }), Object(s.jsx)("audio", {
                                    src: he,
                                    id: "alarm",
                                    loop: !0
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                be = Object(p.a)(["games"])(ue);
            var ge = function(e) {
                    var t = document.getElementById("bridge"),
                        i = document.getElementById("checkbutton"),
                        s = t.getContext("2d"),
                        n = t.width / 400 * 5,
                        a = new Image;

                    function c(e, i) {
                        var s = t.getBoundingClientRect();
                        return {
                            x: Math.floor((e - s.left) / (s.right - s.left) * t.width),
                            y: Math.floor((i - s.top) / (s.bottom - s.top) * t.height)
                        }
                    }

                    function r(e, t) {
                        s.beginPath(), s.arc(e, t, n, 0, 2 * Math.PI, !0), s.fillStyle = "#000", s.globalCompositeOperation = "destination-out", s.fill()
                    }
                    a.onload = function() {
                        s.drawImage(a, 0, 0, t.width, t.height)
                    }, a.src = "/static/media/file.png", t.addEventListener("mousemove", (function(e) {
                        var t, i = c(e.clientX, e.clientY);
                        1 == ("buttons" in (t = e) ? 1 === t.buttons : "which" in t ? 1 === t.which : 1 === t.button) && r(i.x, i.y)
                    }), !1), t.addEventListener("touchmove", (function(e) {
                        e.preventDefault();
                        var t = e.targetTouches[0];
                        if (t) {
                            var i = c(t.pageX, t.pageY);
                            r(i.x, i.y)
                        }
                    }), !1), i.addEventListener("click", (function(t) {
                        "TOPSECRET" == document.getElementById("codewoord").value.toUpperCase() || "TOP SECRET" == document.getElementById("codewoord").value.toUpperCase() ? (document.getElementById("codewoord").value = "", window.location.href = e) : document.getElementById("codewoord").value = ""
                    }))
                },
                me = (i(373), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            ge("end")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Agents_Secret",
                                children: [Object(s.jsx)("div", {
                                    id: "hintheader"
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: "\u00A0"
                                }), Object(s.jsxs)("div", {
                                    id: "center",
                                    children: [Object(s.jsx)("figure", {
                                        id: "bridgeContainer",
                                        children: Object(s.jsx)("canvas", {
                                            id: "bridge"
                                        })
                                    }), Object(s.jsxs)("div", {
                                        className: "container",
                                        children: [Object(s.jsx)("div", {
                                            className: "container__item",
                                            children: Object(s.jsxs)("form", {
                                                className: "form",
                                                children: [Object(s.jsx)("input", {
                                                    id: "codewoord",
                                                    type: "text",
                                                    className: "form__field",
                                                    placeholder: e("agent-code")
                                                }), Object(s.jsx)("button", {
                                                    type: "button",
                                                    className: "btn btn--primary btn--inside uppercase",
                                                    id: "checkbutton",
                                                    children: e("agent-check")
                                                })]
                                            })
                                        }), Object(s.jsx)("div", {
                                            className: "container__item container__item--bottom"
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                pe = Object(p.a)(["games"])(me);
            i(374);
            var xe = function(e) {
                    var t = document.querySelectorAll(".message__text"),
                        i = e.split(""),
                        s = document.querySelector(".message"),
                        n = (document.querySelector(".message__btn"), ["#0EAD81", "#A8F5E3", "#63D9AD", "#FFA159"]),
                        a = 0;
                    s.classList.contains("clicked") ? s.classList.remove("clicked") : s.classList.add("clicked"), i.forEach((function(e) {
                        var i = '\n      <p class="message__letters">\n         <span class="message__letterMain">'.concat(e, "</span>\n      </p>");
                        t.forEach((function(e) {
                            e.insertAdjacentHTML("beforeend", i)
                        }))
                    })); 
                    
                    document.querySelectorAll(".message__letterMain").forEach((function(e) {
                        a == n.length && (a = 0), e.style.color = n[a], a++
                    }));
                    
                    if (document.readyState !== 'loading') {
                        var e = 0;
                        document.getElementById("end-questionmark").style.display = "none", document.getElementById("win").play();
                        var t = window.setInterval(function() {
                            e -= 3, document.getElementById("end-overlay-left").style.left = e + "px", document.getElementById("end-overlay-right").style.right = e + "px"
                        }, 20);
                        setTimeout(function() {
                            clearInterval(t);
                            setTimeout(function() {
                                window.location.href = "/game/FB_ER03/test";
                            }, 15e3);                            
                        }, 5e3);
                    } else {
                        document.addEventListener("DOMContentLoaded", function() {
                            var e = 0;
                            document.getElementById("end-questionmark").style.display = "none", document.getElementById("win").play();
                            var t = window.setInterval(function() {
                                e -= 3, document.getElementById("end-overlay-left").style.left = e + "px", document.getElementById("end-overlay-right").style.right = e + "px"
                            }, 20);
                            setTimeout(function() {
                                clearInterval(t);
                                setTimeout(function() {
                                    window.location.href = "/game/FB_ER03/test";
                                }, 15e3);    
                            }, 5e3);
                        }); 
                    }
                    /* 
                    document.getElementById("end-questionmark").addEventListener("click", (function(e) {
                        ! function() {
                            var e = 0;
                            document.getElementById("end-questionmark").style.display = "none", document.getElementById("win").play();
                            var t = window.setInterval((function() {
                                e -= 3, document.getElementById("end-overlay-left").style.left = e + "px", document.getElementById("end-overlay-right").style.right = e + "px"
                            }), 20);
                            setTimeout((function() {
                                clearInterval(t)
                            }), 5e3)
                        }()
                    }))
                    */
                },
                Oe = (i(537), i.p + "static/media/winfx.60afa169.wav"),
                Ae = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        Object(l.a)(this, i), s = t.call(this, e);
                        var n = new Date(parseInt(localStorage.getItem("festiviti_start_time"))),
                            a = parseInt(localStorage.getItem("festiviti_extra_time")),
                            c = parseInt(localStorage.getItem("festiviti_punish_time")),
                            r = (new Date).getTime();
                        return s.minutes = Math.floor((r - n) % 36e5 / 6e4) + a + c, s.seconds = Math.floor((r - n) % 6e4 / 1e3), s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this.props.t;
                            xe(e("end-happy"))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                children: [Object(s.jsx)("p", {
                                    id: "end-questionmark",
                                    children: "?"
                                }), Object(s.jsx)("div", {
                                    id: "end-overlay-left"
                                }), Object(s.jsx)("div", {
                                    id: "end-overlay-right"
                                }), Object(s.jsxs)("div", {
                                    className: "ending",
                                    children: [Object(s.jsx)("audio", {
                                        src: Oe,
                                        id: "win"
                                    }), Object(s.jsx)("div", {
                                        className: "text clock",
                                        children: Object(s.jsxs)("p", {
                                            children: [this.minutes, ":", this.seconds < 9 ? "0" : "", this.seconds]
                                        })
                                    }), Object(s.jsxs)("div", {
                                        className: "message",
                                        children: [Object(s.jsx)("button", {
                                            className: "message__btn",
                                            children: "click me"
                                        }), Object(s.jsx)("p", {
                                            className: "message__text"
                                        })]
                                    }), Object(s.jsx)("img", {
                                        src: "/static/media/logo.a535b073.png",
                                        id: "logo"
                                    }), Object(s.jsx)("div", {
                                        className: "text",
                                        children: Object(s.jsx)("p", {
                                            children: e("end-time").replace("SS", this.seconds).replace("MM", this.minutes)
                                        })
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                fe = Object(p.a)(["games"])(Ae),
                ve = i(29),
                ye = i.p + "static/media/start.3ff7c147.jpg",
                we = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).start = s.start.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "start",
                        value: function() {
                            localStorage.setItem("festiviti_start_time", (new Date).getTime()), localStorage.setItem("festiviti_extra_time", 0), localStorage.setItem("festiviti_punish_time", 0), window.location.href = this.props.next
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "start_screen",
                                style: {
                                    backgroundImage: "url(" + this.props.background + ")"
                                },
                                children: [Object(s.jsxs)("div", {
                                    className: "centerbuttons",
                                    children: [this.props.escape ? Object(s.jsx)("p", {
                                        style: {
                                            marginBottom: 0
                                        },
                                        children: e("test-escape")
                                    }) : Object(s.jsx)("p", {
                                        style: {
                                            marginBottom: 0
                                        },
                                        children: e("test-game")
                                    }), this.props.settings && Object(s.jsx)("a", {
                                        className: "linkbutton",
                                        style: {
                                            marginBottom: 10
                                        },
                                        onClick: function() {
                                            return window.location.href = "testsettings"
                                        },
                                        children: e("settings")
                                    }), Object(s.jsx)("a", {
                                        className: "linkbutton",
                                        onClick: this.start,
                                        children: this.props.escape ? e("test-escape-button") : e("test-game-button")
                                    })]
                                }), Object(s.jsx)("img", {
                                    className: "overlay",
                                    src: g
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                ke = Object(p.a)()(we),
                Ce = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).activate = s.activate.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "activate",
                        value: function() {
                            localStorage.setItem("festiviti_start_time", (new Date).getTime()), localStorage.setItem("festiviti_extra_time", 0), localStorage.setItem("festiviti_punish_time", 0), window.location.href = this.props.next
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "start_screen",
                                style: {
                                    backgroundImage: "url(" + this.props.background + ")"
                                },
                                children: [Object(s.jsxs)("div", {
                                    className: "centerbuttons",
                                    children: [Object(s.jsxs)("p", {
                                        children: ["Het is zover!", Object(s.jsx)("br", {}), " Klaar voor een spannend avontuur?"]
                                    }), this.props.settings && Object(s.jsx)("a", {
                                        className: "linkbutton",
                                        style: {
                                            marginBottom: 10
                                        },
                                        onClick: function() {
                                            return window.location.href = "startsettings"
                                        },
                                        children: "Instellingen"
                                    }), Object(s.jsx)("a", {
                                        className: "linkbutton",
                                        onClick: this.activate,
                                        children: this.props.escape ? "Start Escape Room" : "Start Spel"
                                    })]
                                }), Object(s.jsx)("img", {
                                    className: "overlay",
                                    src: g
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ee = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "codepad" == this.props.match.params.phase ? Object(s.jsx)(X, {}) : "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: ye,
                                escape: !0,
                                next: "codepad"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: ye,
                                escape: !0,
                                next: "codepad"
                            }) : "buttons" == this.props.match.params.phase ? Object(s.jsx)($, {}) : "morse" == this.props.match.params.phase ? Object(s.jsx)(de, {}) : "alarm" == this.props.match.params.phase ? Object(s.jsx)(be, {}) : "secret" == this.props.match.params.phase ? Object(s.jsx)(pe, {}) : "end" == this.props.match.params.phase ? Object(s.jsx)(fe, {}) : Object(s.jsx)(A.a, {
                                to: "/overview"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ie = Object(A.h)(Ee);
            var Be = function(e) {
                    var t = "GGGG";

                    function i() {
                        console.log(t), "rygbrg" == t && (window.location.href = e)
                    }
                    O()(".btn-blue").click((function() {
                        document.getElementById("blue_audio").play(), t = (t + "b").slice(-6), i()
                    })), O()(".btn-yellow").click((function() {
                        document.getElementById("yellow_audio").play(), t = (t + "y").slice(-6), i()
                    })), O()(".btn-green").click((function() {
                        document.getElementById("green_audio").play(), t = (t + "g").slice(-6), i()
                    })), O()(".btn-red").click((function() {
                        document.getElementById("red_audio").play(), t = (t + "r").slice(-6), i()
                    }))
                },
                Se = i.p + "static/media/snake.3a4608af.mp3",
                Le = i.p + "static/media/dog.652b5096.mp3",
                Qe = i.p + "static/media/goat.adaac826.mp3",
                Fe = i.p + "static/media/bird.9dc0436d.mp3",
                Ne = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            Be("morse")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                className: "Agents_Buttons",
                                children: [Object(s.jsx)("audio", {
                                    src: Se,
                                    id: "blue_audio"
                                }), Object(s.jsx)("audio", {
                                    src: Le,
                                    id: "red_audio"
                                }), Object(s.jsx)("audio", {
                                    src: Fe,
                                    id: "green_audio"
                                }), Object(s.jsx)("audio", {
                                    src: Qe,
                                    id: "yellow_audio"
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    children: "\u00A0"
                                }), Object(s.jsxs)("div", {
                                    id: "centered",
                                    children: [Object(s.jsx)("span", {
                                        className: "btn-blue"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-red"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-green"
                                    }), Object(s.jsx)("span", {
                                        className: "btn-yellow"
                                    })]
                                }), Object(s.jsx)("p", {
                                    className: "bottom",
                                    id: "text1"
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Re = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "codepad" == this.props.match.params.phase ? Object(s.jsx)(X, {}) : "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: ye,
                                escape: !0,
                                next: "codepad"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: ye,
                                escape: !0,
                                next: "codepad"
                            }) : "buttons" == this.props.match.params.phase ? Object(s.jsx)(Ne, {}) : "morse" == this.props.match.params.phase ? Object(s.jsx)(de, {}) : "alarm" == this.props.match.params.phase ? Object(s.jsx)(be, {}) : "secret" == this.props.match.params.phase ? Object(s.jsx)(pe, {}) : "end" == this.props.match.params.phase ? Object(s.jsx)(fe, {}) : Object(s.jsx)(A.a, {
                                to: "/overview"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ge = Object(A.h)(Re),
                Ye = i.p + "static/media/background_start.11a86e90.jpg",
                Me = i(646);
            var He = function(e, t) {
                    var i;
                    (i = O.a).fn.makeLock = function(s) {
                        var n;
                        console.clear();
                        var a = s || i(this).attr("data-dials") || 3,
                            c = i(this).addClass("myLock");
                        c.append('<div class="lockInset"><div class="lockLine"></div><div class="lockWrapper"></div></div>');
                        for (var r = i('<div class="btnEnter button">' + t + "</div>").appendTo(c), o = c.find(".lockWrapper"), l = ["red", "lime", "yellow"], d = 0; d < a; d++) {
                            for (var j = i('<div class="dial" style="color:' + l[d] + ';"><ol></ol></div>').appendTo(o).find("ol"), h = 0; h < 10; h++) j.append("<li>" + h + "</li>");
                            j.prepend(j.find("li:last-child"))
                        }
                        o.append('<div class="shadow"></div>'), c.find("ol").on("click", (function(e) {
                            i(this).append(i("li:first-child", this)), Me.b.fromTo(this, .35, {
                                top: 0
                            }, {
                                top: -50,
                                ease: Me.a.easeOut
                            })
                        })), r.on("click", (function(t) {
                            n = "", c.find("li:nth-child(3)").each((function() {
                                n += i(this).text()
                            })), console.log(n), "257" == n && (window.location.href = "/game/FB_ER02/" + e)
                        }))
                    }, O()("#lock").makeLock()
                },
                Je = (i(538), i.p + "static/media/spacesticker1.0f4b4fae.png"),
                De = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this.props.t;
                            He("phone", e("astro-restart"))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Astronaut",
                                children: [Object(s.jsxs)("p", {
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: [e("astro-alarm"), " ", Object(s.jsx)("span", {
                                        id: "time",
                                        children: "\u00A0"
                                    })]
                                }), Object(s.jsx)("div", {
                                    className: "myCenter",
                                    children: Object(s.jsxs)("div", {
                                        id: "lock",
                                        "data-dials": "3",
                                        children: [Object(s.jsx)("img", {
                                            class: "sticker",
                                            src: Je
                                        }), Object(s.jsx)("img", {
                                            class: "sticker2",
                                            src: Je
                                        })]
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ve = Object(p.a)(["games"])(De),
                Ke = i(278),
                ze = (i(550), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "stateChange",
                        value: function(e) {
                            0 == e.data && (window.location.href = "access")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsx)("div", {
                                id: "window",
                                style: {
                                    height: "100%"
                                },
                                className: "Astronaut_Movie",
                                children: Object(s.jsx)("div", {
                                    className: "videoWrapper",
                                    children: Object(s.jsx)(Ke.a, {
                                        className: "videowrapper",
                                        videoId: "vumHfR3xYww",
                                        opts: {
                                            height: "700",
                                            width: "100%",
                                            playerVars: {
                                                rel: 0,
                                                showinfo: 0,
                                                autoplay: 1
                                            }
                                        },
                                        onStateChange: this.stateChange
                                    })
                                })
                            })
                        }
                    }]), i
                }(a.a.Component));
            var Te = function(e, t, i, s, n) {
                    O()(".number-dig").click((function() {
                        g(this);
                        var e = O()(".phoneString input").val(),
                            t = O()(this).attr("name");
                        O()(".phoneString input").val(e + t)
                    }));
                    var a, c = !0,
                        r = 0,
                        o = !0,
                        l = !1;
                    O()(".action-dig").click((function() {
                        if (g(this), O()(this).hasClass("goBack")) {
                            var h = (m = O()(".phoneString input").val()).substring(0, m.length - 1);
                            O()(".phoneString input").val(h)
                        } else if (O()(this).hasClass("call"))
                            if (O()(".call-pad").hasClass("in-call")) setTimeout((function() {
                                j()
                            }), 500), o = !1, r = 0, b(), a.pause(), a.currentTime = 0, O()(".pulsate").toggleClass("active-call"), O()(".phoneString input").val("");
                            else {
                                O()(".ca-status").text(s);
                                var m = O()(".phoneString input").val();
                                document.getElementById("number").innerHTML = m, "0013984277" == m ? (l = !0, document.getElementById("name").innerHTML = i, a = document.getElementById("alien"), console.log(n), document.getElementById("avatar").style.backgroundImage = "url(" + n + ")", a.play(), setTimeout((function() {
                                    j(), c = !0, u();
                                    var button_1 = document.getElementById("call_button"),
                                        new_button_1 = button_1.cloneNode(true);
                                        new_button_1.style.cursor = 'auto';
                                        button_1.parentNode.replaceChild(new_button_1, button_1);
                                    setTimeout((function() {
                                        c = !1, o = !0, d(), O()(".pulsate").toggleClass("active-call"), O()(".ca-status").animate({
                                            opacity: 0
                                        }, 1e3, (function() {
                                            O()(this).text("00:00"), O()(".ca-status").attr("data-dots", ""), O()(".ca-status").animate({
                                                opacity: 1
                                            }, 1e3)
                                        }))
                                    }), 13e3);
                                    setTimeout((function() {
                                        setTimeout((function() {
                                            j()
                                        }), 500);
                                        o = !1;
                                        r = 0;
                                        b();
                                        a.pause();
                                        a.currentTime = 0;
                                        O()(".pulsate").toggleClass("active-call");
                                        O()(".phoneString input").val("");
                                        var button_1 = document.getElementById("call_button"),
                                            button_2 = document.getElementById("back_button"),
                                            new_button_1 = button_1.cloneNode(true),
                                            new_button_2 = button_2.cloneNode(true);
                                        new_button_1.style.opacity = "0.1", new_button_1.style.cursor = 'auto', new_button_2.style.opacity = "0.1", new_button_2.style.cursor = 'auto';
                                        button_1.parentNode.replaceChild(new_button_1, button_1), button_2.parentNode.replaceChild(new_button_2, button_2);
                                        var elements = document.querySelectorAll('.dig.number-dig');
                                        elements.forEach(function(element) {
                                            var new_element = element.cloneNode(true);
                                            new_element.style.opacity = "0.1", new_element.style.cursor = 'auto';
                                            element.parentNode.replaceChild(new_element, element);
                                        });
                                    }), 40e3);
                                }), 500)) : ((a = document.getElementById("oproep")).play(), setTimeout((function() {
                                    j()
                                }), 500))
                            }
                        else O()(this).hasClass("addPerson") && (l ? window.location.href = "/game/FB_ER03/" + e : alert(t))
                    }));
                    var d = function e() {
                            o && setTimeout((function() {
                                var t = Math.floor(r / 60),
                                    i = r % 60;
                                t < 10 && (t = "0" + t), i < 10 && (i = "0" + i), O()(".ca-status").text(t + ":" + i), r += 1, e()
                            }), 2e3)
                        },
                        j = function() {
                            O()(".call-pad").toggleClass("in-call"), O()(".call-icon").toggleClass("in-call"), O()(".call-change").toggleClass("in-call"), O()(".ca-avatar").toggleClass("in-call")
                        },
                        h = 0,
                        u = function e() {
                            c && setTimeout((function() {
                                h > 3 && (h = 0);
                                for (var t = "", i = 0; i < h; i++) t += ".";
                                O()(".ca-status").attr("data-dots", t), h += 1, e()
                            }), 500)
                        },
                        b = function() {
                            c = !1
                        },
                        g = function(e) {
                            O()(e).removeClass("clicked");
                            var t = e;
                            setTimeout((function() {
                                O()(t).addClass("clicked")
                            }), 1)
                        }
                },
                Ue = (i(551), i.p + "static/media/call.24076ffc.mp3"),
                Xe = i.p + "static/media/pruts.mp3",
                Pe = i.p + "static/media/professor.png",
                We = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this.props.t;
                            Te("end", e("astro-alert"), e("astro-help"), e("astro-calling"), Pe)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Astronaut_Phone",
                                children: [Object(s.jsxs)("div", {
                                    className: "pad",
                                    children: [Object(s.jsxs)("div", {
                                        className: "dial-pad",
                                        children: [Object(s.jsx)("div", {
                                            className: "phoneString",
                                            children: Object(s.jsx)("input", {
                                                className: "text",
                                                disabled: !0
                                            })
                                        }), Object(s.jsxs)("div", {
                                            className: "digits",
                                            children: [Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "1",
                                                children: ["1", Object(s.jsx)("div", {
                                                    className: "sub-dig"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "2",
                                                children: ["2", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "ABC"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "3",
                                                children: ["3", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "DEF"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "4",
                                                children: ["4", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "GHI"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "5",
                                                children: ["5", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "JKL"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "6",
                                                children: ["6", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "MNO"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "7",
                                                children: ["7", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "PQRS"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "8",
                                                children: ["8", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "TUV"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "dig number-dig",
                                                name: "9",
                                                children: ["9", Object(s.jsx)("div", {
                                                    className: "sub-dig",
                                                    children: "WXYZ"
                                                })]
                                            }), Object(s.jsx)("div", {
                                                className: "dig number-dig astrisk",
                                                name: "*",
                                                children: "*"
                                            }), Object(s.jsx)("div", {
                                                className: "dig number-dig pound",
                                                name: "0",
                                                children: "0"
                                            }), Object(s.jsx)("div", {
                                                className: "dig number-dig pound",
                                                name: "#",
                                                children: "#"
                                            })]
                                        }), Object(s.jsxs)("div", {
                                            className: "digits",
                                            children: [Object(s.jsx)("div", {
                                                className: "dig addPerson action-dig"
                                            }), Object(s.jsx)("div", {
                                                className: "dig-spacer"
                                            }), Object(s.jsx)("div", {
                                                id: "back_button",
                                                className: "dig goBack action-dig"
                                            })]
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        className: "call-pad",
                                        children: [Object(s.jsxs)("div", {
                                            className: "pulsate",
                                            children: [Object(s.jsx)("div", {}), Object(s.jsx)("div", {}), Object(s.jsx)("div", {})]
                                        }), Object(s.jsx)("div", {
                                            id: "avatar",
                                            className: "ca-avatar"
                                        }), Object(s.jsx)("div", {
                                            className: "ca-name",
                                            id: "name",
                                            children: "Onbekend nummer"
                                        }), Object(s.jsx)("div", {
                                            className: "ca-number",
                                            id: "number",
                                            children: "123 456 789"
                                        }), Object(s.jsx)("div", {
                                            className: "ca-status",
                                            "data-dots": "...",
                                            children: "Oproep"
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        className: "call action-dig",
                                        id: "call_button",
                                        children: [Object(s.jsx)("div", {
                                            className: "call-change",
                                            children: Object(s.jsx)("span", {
                                                children: Object(s.jsx)("img", {
                                                    src: "http://localhost:8000/static/media/phone.png",
                                                    style: {
                                                        marginTop: 10,
                                                        width: 50
                                                    }
                                                })
                                            })                                        
                                        }), Object(s.jsx)("div", {
                                            className: "call-icon"
                                        })]
                                    })]
                                }), Object(s.jsx)("p", {
                                    id: "timep",
                                    children: Object(s.jsx)("span", {
                                        id: "time",
                                        style: {
                                            visibility: "hidden"
                                        },
                                        children: "\u00A0"
                                    })
                                }), Object(s.jsx)("audio", {
                                    src: Ue,
                                    id: "oproep",
                                    loop: !0
                                }), Object(s.jsx)("audio", {
                                    src: Xe,
                                    id: "alien"
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ze = Object(p.a)(["games"])(We);
            var qe = function(e) {
                    var t = {
                            0: {
                                0: "L",
                                1: "UL",
                                2: "UD",
                                3: "UD",
                                4: "UD",
                                5: "LD"
                            },
                            1: {
                                0: "LR",
                                1: "UR",
                                2: "UD",
                                3: "LD",
                                4: "LU",
                                5: "RD"
                            },
                            2: {
                                0: "RU",
                                1: "DL",
                                2: "",
                                3: "LR",
                                4: "LR",
                                5: "L"
                            },
                            3: {
                                0: "",
                                1: "RU",
                                2: "UD",
                                3: "RD",
                                4: "LR",
                                5: "LR"
                            },
                            4: {
                                0: "",
                                1: "",
                                2: "",
                                3: "LU",
                                4: "RD",
                                5: "LR"
                            },
                            5: {
                                0: "",
                                1: "LU",
                                2: "UD",
                                3: "RD",
                                4: "",
                                5: "LR"
                            },
                            6: {
                                0: "LU",
                                1: "RD",
                                2: "LU",
                                3: "UD",
                                4: "UD",
                                5: "LRD"
                            },
                            7: {
                                0: "LR",
                                1: "LU",
                                2: "RD",
                                3: "",
                                4: "LU",
                                5: "RD"
                            },
                            8: {
                                0: "UR",
                                1: "R",
                                2: "",
                                3: "",
                                4: "UR",
                                5: ""
                            }
                        },
                        i = 0,
                        s = 0,
                        n = 16.6666666,
                        a = 11.1111111,
                        c = !1;

                    function r(e) {
                        c || (document.getElementById("music").play(), c = !0);
                        return !!t[s][i].includes(e) || (s = 0, i = 0, document.getElementById("rocket").style.bottom = "0%", document.getElementById("rocket").style.right = "0%", alert("Pas op! Botsing met een ruimtelichaam! Je zoekt best een plattegrond..."), !1)
                    }
                    O()("#arrowl").click((function() {
                        r("L") && (s += 1, s = Math.min(s, 8), document.getElementById("rocket").style.right = (s * a).toString() + "%")
                    })), O()("#arrowr").click((function() {
                        r("R") && (s -= 1, s = Math.max(s, 0), document.getElementById("rocket").style.right = (s * a).toString() + "%")
                    })), O()("#arrowu").click((function() {
                        r("U") && (i += 1, i = Math.min(i, 5), document.getElementById("rocket").style.bottom = (i * n).toString() + "%"), 8 == s && 5 == i && (window.location.href = e)
                    })), O()("#arrowd").click((function() {
                        r("D") && (i -= 1, i = Math.max(i, 0), document.getElementById("rocket").style.bottom = (i * n).toString() + "%")
                    }))
                },
                _e = (i(552), i.p + "static/media/spacegrid.06029af0.jpg"),
                $e = i.p + "static/media/rocket.45a77be3.png",
                et = i.p + "static/media/aarde.efd03025.png",
                tt = i.p + "static/media/arrowU.70047538.png",
                it = i.p + "static/media/arrowD.47fdd45c.png",
                st = i.p + "static/media/arrowL.ef73f5cb.png",
                nt = i.p + "static/media/arrowR.050a6062.png",
                at = i.p + "static/media/epic_space.43204e22.mp3",
                ct = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            qe("doors")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Astronaut_Maze",
                                children: [Object(s.jsxs)("div", {
                                    id: "timefixed",
                                    children: [Object(s.jsx)("p", {
                                        style: {
                                            visibility: "hidden"
                                        },
                                        children: e("astro-alarm")
                                    }), Object(s.jsx)("p", {
                                        id: "time",
                                        style: {
                                            visibility: "hidden"
                                        },
                                        children: "\u00A0"
                                    })]
                                }), Object(s.jsx)("img", {
                                    id: "back",
                                    src: _e
                                }), Object(s.jsx)("img", {
                                    id: "rocket",
                                    src: $e
                                }), Object(s.jsx)("img", {
                                    id: "aarde",
                                    src: et
                                }), Object(s.jsx)("img", {
                                    id: "arrowu",
                                    src: tt
                                }), Object(s.jsx)("img", {
                                    id: "arrowd",
                                    src: it
                                }), Object(s.jsx)("img", {
                                    id: "arrowr",
                                    src: nt
                                }), Object(s.jsx)("img", {
                                    id: "arrowl",
                                    src: st
                                }), Object(s.jsx)("audio", {
                                    src: at,
                                    id: "music",
                                    loop: !0
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                rt = Object(p.a)(["games"])(ct),
                ot = (i(553), i.p + "static/media/battery.e7ea9bf8.png"),
                lt = i.p + "static/media/matchbox.jpg",
                dt = i.p + "static/media/button.16289653.png",
                jt = (i.p, i(121)),
                ht = i(74),
                ut = i(652),
                bt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            s1: 0,
                            s2: 0,
                            s3: 0,
                            s4: 0,
                            s5: 0
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {}
                    }, {
                        key: "checkStart",
                        value: function() {
                            4 == this.state.s1 && 2 == this.state.s2 && 34 == this.state.s3 && 29 == this.state.s4 && 15 == this.state.s5 && (window.location.href = "/game/FB_ER02/phone")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            setTimeout((function() {
                                document.getElementById("music").play();
                            }), 1e3);
                            var e = this,
                                t = {
                                    padding: 20,
                                    display: "inline-flex",
                                    justifyContent: "center",
                                    alignItems: "center"
                                },
                                i = {
                                    padding: 30,
                                    height: "50%"
                                },
                                n = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                style: {
                                    height: "100%"
                                },
                                className: "Astronaut_Engine",
                                children: [Object(s.jsx)("audio", {
                                    src: "http://localhost:8000/static/media/engine.mp3",
                                    id: "music",
                                    loop: !0
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: "\u00A0"
                                }), Object(s.jsxs)(jt.a, {
                                    style: {
                                        height: "50%"
                                    },
                                    children: [Object(s.jsxs)(ht.a, {
                                        span: 16,
                                        style: {
                                            height: "100%"
                                        },
                                        children: [Object(s.jsxs)(jt.a, {
                                            style: i,
                                            children: [Object(s.jsx)("img", {
                                                style: {
                                                    height: "60%",
                                                    margin: "auto"
                                                },
                                                src: ot
                                            }), Object(s.jsxs)("div", {
                                                style: {
                                                    width: "70%",
                                                    height: 45,
                                                    padding: 5,
                                                    backgroundColor: "grey",
                                                    marginTop: 60,
                                                    marginLeft: 30
                                                },
                                                children: [" ", Object(s.jsx)(ut.a, {
                                                    onAfterChange: function(t) {
                                                        return e.setState({
                                                            s1: t
                                                        })
                                                    },
                                                    style: {
                                                        width: "90%"
                                                    },
                                                    defaultValue: 5,
                                                    max: 10,
                                                    tooltipVisible: !0
                                                })]
                                            })]
                                        }), Object(s.jsxs)(jt.a, {
                                            style: i,
                                            children: [Object(s.jsx)("img", {
                                                style: {
                                                    height: "60%",
                                                    margin: "auto"
                                                },
                                                src: lt
                                            }), Object(s.jsxs)("div", {
                                                style: {
                                                    width: "70%",
                                                    height: 45,
                                                    padding: 5,
                                                    backgroundColor: "grey",
                                                    marginTop: 60,
                                                    marginLeft: 30
                                                },
                                                children: [" ", Object(s.jsx)(ut.a, {
                                                    onAfterChange: function(t) {
                                                        return e.setState({
                                                            s2: t
                                                        })
                                                    },
                                                    style: {
                                                        width: "90%"
                                                    },
                                                    defaultValue: 5,
                                                    max: 10,
                                                    tooltipVisible: !0
                                                })]
                                            })]
                                        })]
                                    }), Object(s.jsx)(ht.a, {
                                        span: 8,
                                        style: {
                                            display: "inline-flex",
                                            justifyContent: "center",
                                            alignItems: "center"
                                        },
                                        children: Object(s.jsx)("img", {
                                            src: dt,
                                            style: {
                                                height: 200
                                            },
                                            onClick: function() {
                                                return e.checkStart()
                                            }
                                        })
                                    })]
                                }), Object(s.jsxs)(jt.a, {
                                    style: {
                                        height: "50%"
                                    },
                                    children: [Object(s.jsx)("h2", {
                                        className: "title",
                                        children: n("astro-gas")
                                    }), Object(s.jsx)(ht.a, {
                                        span: 8,
                                        style: t,
                                        children: Object(s.jsxs)("div", {
                                            style: {
                                                width: 50,
                                                height: "90%"
                                            },
                                            children: [Object(s.jsx)("p", {
                                                className: "subtitle",
                                                children: n("astro-sweet")
                                            }), Object(s.jsx)("div", {
                                                style: {
                                                    height: "80%",
                                                    padding: 5,
                                                    backgroundColor: "grey"
                                                },
                                                children: Object(s.jsx)(ut.a, {
                                                    onAfterChange: function(t) {
                                                        return e.setState({
                                                            s3: t
                                                        })
                                                    },
                                                    style: {
                                                        height: "80%",
                                                        margin: "auto"
                                                    },
                                                    vertical: !0,
                                                    defaultValue: 30,
                                                    max: 50,
                                                    tooltipVisible: !0
                                                })
                                            })]
                                        })
                                    }), Object(s.jsx)(ht.a, {
                                        span: 8,
                                        style: t,
                                        children: Object(s.jsxs)("div", {
                                            style: {
                                                width: 50,
                                                height: "90%"
                                            },
                                            children: [Object(s.jsx)("p", {
                                                className: "subtitle",
                                                style: {
                                                    marginLeft: "-30px"
                                                },
                                                children: n("astro-neutral")
                                            }), Object(s.jsx)("div", {
                                                style: {
                                                    height: "80%",
                                                    padding: 5,
                                                    backgroundColor: "grey"
                                                },
                                                children: Object(s.jsx)(ut.a, {
                                                    onAfterChange: function(t) {
                                                        return e.setState({
                                                            s4: t
                                                        })
                                                    },
                                                    style: {
                                                        height: "80%",
                                                        margin: "auto"
                                                    },
                                                    vertical: !0,
                                                    defaultValue: 30,
                                                    max: 50,
                                                    tooltipVisible: !0
                                                })
                                            })]
                                        })
                                    }), Object(s.jsx)(ht.a, {
                                        span: 8,
                                        style: t,
                                        children: Object(s.jsxs)("div", {
                                            style: {
                                                width: 50,
                                                height: "90%"
                                            },
                                            children: [Object(s.jsx)("p", {
                                                className: "subtitle",
                                                children: n("astro-salt")
                                            }), Object(s.jsx)("div", {
                                                style: {
                                                    height: "80%",
                                                    padding: 5,
                                                    backgroundColor: "grey"
                                                },
                                                children: Object(s.jsx)(ut.a, {
                                                    onAfterChange: function(t) {
                                                        return e.setState({
                                                            s5: t
                                                        })
                                                    },
                                                    style: {
                                                        height: "80%",
                                                        margin: "auto"
                                                    },
                                                    vertical: !0,
                                                    defaultValue: 30,
                                                    max: 50,
                                                    tooltipVisible: !0
                                                })
                                            })]
                                        })
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                gt = Object(p.a)(["games"])(bt),
                mt = (i(554), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "open_door",
                        value: function() {
                            var e = this.props.t;
                            document.getElementById("window").style.backgroundColor = "green", document.getElementById("lock1").style.bottom = "200px", document.getElementById("lock2").style.bottom = "300px", document.getElementById("lock2").style.backgroundColor = "green", document.getElementById("inside").style.backgroundColor = "green", document.getElementById("title").innerHTML = e("astro-open"), setTimeout((function() {
                                window.location.href = "end"
                            }), 2e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                style: {
                                    height: "100%"
                                },
                                className: "Astronaut_Doors",
                                children: [Object(s.jsxs)("div", {
                                    class: "wrapper",
                                    children: [Object(s.jsxs)("div", {
                                        class: "base",
                                        children: [Object(s.jsx)("div", {
                                            class: "base-bottom"
                                        }), Object(s.jsx)("div", {
                                            class: "lock-inside-top"
                                        }), Object(s.jsx)("div", {
                                            class: "lock-inside-bottom"
                                        })]
                                    }), Object(s.jsx)("div", {
                                        class: "lock-cirlce",
                                        id: "lock1",
                                        children: Object(s.jsx)("div", {
                                            class: "lock-circle-inside",
                                            id: "inside"
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "lock-box",
                                        id: "lock2"
                                    })]
                                }), Object(s.jsxs)("h1", {
                                    id: "title",
                                    children: [t("astro-closed-1"), Object(s.jsx)("span", {
                                        onClick: function() {
                                            return e.open_door()
                                        },
                                        children: "R"
                                    }), t("astro-closed-2"), " ", t("astro-closed-3")]
                                }), Object(s.jsxs)("h2", {
                                    style: {
                                        visibility: "hidden"
                                    },
                                    children: [t("astro-level"), " ", Object(s.jsx)("br", {}), Object(s.jsx)("span", {
                                        id: "time",
                                        children: "\u00A0"
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                pt = Object(p.a)(["games"])(mt),
                xt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: Ye,
                                escape: !0,
                                next: "movie"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: Ye,
                                escape: !0,
                                next: "movie"
                            }) : "movie" == this.props.match.params.phase ? Object(s.jsx)(ze, {}) : "access" == this.props.match.params.phase ? Object(s.jsx)(Ve, {}) : "phone" == this.props.match.params.phase ? Object(s.jsx)(Ze, {}) : "maze" == this.props.match.params.phase ? Object(s.jsx)(rt, {}) : "engine" == this.props.match.params.phase ? Object(s.jsx)(gt, {}) : "doors" == this.props.match.params.phase ? Object(s.jsx)(pt, {}) : "end" == this.props.match.params.phase ? Object(s.jsx)(fe, {}) : Object(s.jsx)(A.a, {
                                to: "/"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ot = Object(A.h)(xt),
                At = i.p + "static/media/background_start.7191e1ca.jpg",
                ft = (i(555), i.p, function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            "697118" == document.getElementById("wachtwoord").value && (document.getElementById("wachtwoord").value = "", localStorage.setItem("festiviti_start_time", (new Date).getTime()), localStorage.setItem("festiviti_extra_time", 0), localStorage.setItem("festiviti_punish_time", 0), window.location.href = "helicopter")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsx)("div", {
                                className: "Boyard_Access",
                                children: Object(s.jsx)("div", {
                                    className: "demo",
                                    children: Object(s.jsxs)("div", {
                                        className: "login",
                                        children: [Object(s.jsx)("img", {
                                            src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAL4AAACoCAYAAABe+1QbAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAFbhJREFUeNrsXT1s5Eh25g6MDmYBVxtjCJfMkk4Eb7LFSTS4ZIuTzGbHXsAQMInZkwh2sGY7GcBRa6FAYfdEWtwG7HEi4BL2HLwQ4ITUJjps0tQkOlxCahINVga6tQAFeAO3A5MyVcPfYvGnu98DCjP662aTX1V9773vvfpkuVwKYGCbZg/gFoAB8MHAAPhgYAB8MDAAPhgYAB8MDIAPBgbABwMD4IOBtcn+Cm5Bc+Y4zvZiseiGX9u2rXS73YUsy074PUmSPEmSfoa7BcBfWZDbtq3Ytv3McRz58vLys+BHDzP+9FYQBAFj/E6WZUdRFEtRFBsmQ0lbLpcwKhqu627pun4oiuKFIAi+IAhLTsPHGJ+NRqO9+XzegXtdfMBNqGBYlrVDCDnhDPbESaBp2pHrultw7wH4jYzZbLZdI+A/mgC6rh/CDgDAr3UMh8NXDQH+3kAIXZmm+RyeCQC/ch6PMT5rA+hp+gPPJ3l8AoUo5SI1iqKc3tzc/KbEy9zm+J2HLK+LMX5n2zbpdru/wtO6bwD8+kB/KwiCQAj5UZZlR5blmSRJnizLThowbdve8TxP8jxPsm372enp6ZdFJgPG+E8AfghncnNiEUJXeSgHQuhK07QjnrzbNM3nmqYd5aVXGOMzcHqB49cBep8QcmIYxm6V1zKfzzsY4yWAH4AvVA20IBmVCnjLsnbquBZVVY+LOL2qqh7DcwTgFx5BjD4xk1oH4MNdJ2MCJk7M0Wi0B88SgJ97jEajvQROXSuYCvgXieCfzWbbAHwAda5YfRzYMMZndYKIA+jvrhuAD8BmoTi+pmlHdTqLvEAPlAeAn1twRlGc2rOi8/m8wxH0d9KGTY7yALiLrfZ+1SHKuBFIIrhLG4bD4SsAPoys1b4RelCl+G2TV30AeL7VvhHR12w2265a/Lapqz4APAfoCCEnLcsbcF31Afgw7kaghVmKonjRBB0wDGO3rgquJvwWAH5Bzl1zFMWv6z3pwZiZZRqbKGVYmQs1DGO3rgcUrLaN8d+YEGrlq/6m1ew2xp+TMqRJTmTYqaAO2qGq6nFTFCdKs+ocm5bQEpraxuNApWnaUZyzFeW7dUh9BUHwm6xbbaKMsSkHfmOAH4KYBrDrulvBA/8IdFG+W/UDMk3zeZMgME3zeVNdGjYppl9778zJZPJSEISH0+n06+j39/f3vw3K6T76WdROT0+/9Dxvq6rrm06nX+/v7w+bqoizbfsZY41tWXto27ayKZWHtQLf87ytsGb07du3v1ssFp0I4Hpx/xcEQej1etPoA6J/ztsURfmpwVpeueFJBzW3ebfmvBEB2mmL0h3qZ/foDp3BrFJW21T4skl+v4lyZW6cNKuNXZzCMAoymtvS0R0qrr224beG+/NsDM/nnWxJrDkNKpjubrIoikv6JkcnBi2g0nX9cN3Dbw3E7z8aTe94KwX8MOGTVnRNZyJ1XV9ijM+ilCaNCtVJdzYZ+JsiWqu6UMLHGJ8Fq7VPiaM+ojQ03aEztZtAd1zX3TJN83lF7cUzx6a0HuStGy+tDqQmkL9pdCduFyjSPAoSWTUDP5KAKuxQAd3Jd3+DPjpVTwAfgF+TxkTX9UOgO/mjaLzrbzcxstOKiiFRFC+A7jC1JofITlu0OoxVQ/eaHAHdyd03s5K+/JtwsAR3ycJgMBjl7Pl+TycSaHhCiYIZfY2odkeW5b+Iovg+/Pr8/PyLKrU7bbVut/ur4zi/JYT8uE6yiZVuE86yEgHdKb3yQyy/aXWm4zi/NQzjpSiKuf/m8vLyM8dxtvMI02RZnq2LuGqxWHRs296Jjqh4L8/KP51OVYTQBxCrteBgiNlstj0aje4SVUV7vATRndi6UGqF81eJk4bJqciuGNuINkz+hYdKZEVaeOr4NyGWX3UjJObtlaYzYUaRTuvTFKmtUZiwuowVnOHJKmnh26L98vPSTgB+RQkterWPkUDcxevph9vm1hjz+bwTJ9cQOJxoGLcDcOyx6QPwa0ho0as9reQMaQ49mXi1wKsiYWNZ1k6Viaak82xZpSMAfM6rvq7rh2lbfBx46exsmFChJxKv6MNwOHzFMwNc42HPPn0PchxXBIdH1FlsbhjGbtxx93QCiu4gFv05DXxeYczhcPgqKpvgsMvV2hOHVlTy6MK27tnbRnrqpOlt0sBNZ215OWHhrrSCoE8Ef9lVH4BfwaAjNtHtml6taJEaHcrk8YDCnahMWLRB0Mf2wKT9JEhitQD4tJOalbWN7gh0tRePwolQX8RKd1IOhqt1IISuwntVNsIDwK9opK3caTtCXKizbFQmBC2L4K3BBlCZySf6PkIj2RYAP23lztoR6FYkZWP50VNPiu5cFWvjS1GeEsVBa5+9bTS5k9ZVgT57iu6zE2Yy0xrQhtKAAjUEhQpbqtTE88q8smZz1z1724rDF+KysFlObpY8IArmtB0hkEAUjmZUkJHluuqHn6NE5wYfgF9TOw16ew0TX6IoXmTRGcuydpJqUtO2bTrTmQf4bWgDUoSqMIY2/XUOaTZ+AWkx/dFotJeVpLIsaycuMZY3E0nvOlkPm1NmNCkqU8mqH9P3KNdY5yOCGr8AesXNG0YzDGO3SN+ZpLAnzdOzgM9LARkD+vPZbNYxDOOxIAjXPFf9wJ8q1QQAgF9xTD/LGS0K+LSwZ3gIRF7gVxW6DEEf+Yy8wH93Nq+u69BEtk3ADyM4hJATwzB2k+S2w+HwVRk9e5yTSxe7pPFajpJfGlzfR0EfubZHCKFzHvRpNpstXdeFViNtA37abhABPPeqohjZtF8jxbnWdf2rjM//gBByUHb1xxgv5/P5UlVV6LjQZuDHhCRLx7XjVq6YCeXXEMW5JoQcxK3yKRTrkSiKP5SZAISQpWVZ0EuzjcCvqE9kbEQnjq/HcVpOUZxrhNC5rutfua77oMT9+VTTtBesE4AQssQYA91pC/BzhiS5FGqkNb6KS5KV0LtcI4TONU17YZrmowokH49VVf2GVwRo0wRrjb55UnFK1UfbJFEX+gEzUpxrQshBFWBPUYd+XpYKFamJBuCXAHwNvd9jKU4adYk6cgwU55oQcmBZ1qcNLiSPgwnA/X6uW0y/qeorv6ntOYW63MsaF6E4CKHz0Wj0ecF70SGEHOQZDIU+X1Ww+vvrFOGpXZFZB+iTojhp1CVaelgkUSWK4g9FIjRUVOk8h0N6wLr68wb/OlGexhWZVVCcuJUpi7qEjm2RRBXG+Puy1CQN/GUmVbircNb/rE2BytodcJakxMyiLmFqv0iiinU1ppNUmqbFUbUllwdcoeQZgF9OkVn5Q8lTiRT0+ixaO3tdchEI4/JJyaMXZVb8gO5UWugCwC9enF3bap91WEWoZ2F0op+yABJj/H1ODn6NMf7eMIzHDBqog6oWmFVvzd5Y2WEVyao4bp+HWhFClqIoMisr81IaXde/KiE8K5T9tSzr0yqTW6vu6Lam7LCq7ZfxaKKiDt83aat7XqEZxjivpCAzSVZVPH9dMrqNvTHrQXFFHgLv90gDIg3CgtnU66ijXECReS2K4g90DiGI49da1A7AZ++tU4rmxHVHqCF0mkp5TNN8NBwOnxJCDgKKcx0dCKFzVVW/iePvlBbno78jhBwMh8OndKbYNM1Hdeh3eLV22VitTlWanLqSZSzhTZZITd6/4VG8sgn9dxo/OIFHkUlchIHXpCpKeYpKF3iOYIeovZXJKh6y3fgFcKAjsWK0qorC81CevJp7TdNeRPj8R4MQcpBVpdUQxclceAD4FTu5Se29m2ztl5fyjEajz7N2kLzx+7opzqrLGFpxEWWc3DiOWWM0J3eUhwWweXMEdUVxii4+APwKndy4MGaZ12MpyE4SmOXsK/S0TFZ4Npt1OPbh2Rie35rTAVmpSRy/LHMAmmEYPBM8T/NkdBOAm0sHxFOWYJrmxpyg0poLYa1tjbvhrA4zIeSEc/+c6zyObpxQTdO0F3Vq7lVVXS7/T84JwG+yo1qZG84qUwj9BU5HZuZ2dGPoSq4Jw9GhvVO1bop84YHQEpMk6WdCyI9NXsNisegKgiAMBoMxQugDj9c8PT39p/F4/Hna78iy/Csh5Lvwa0LId5Ik/U/a3/R6vW9ubm6+4HGNhJAfFUX5yfO8LdbX6Ha7C2GVrE2zkOWYyrgVv0RLEL+Kc63yxPYjcfjrrIJ1zjH7uzwIfVYAUJ0aR1F+HXfDS1CVe8kwnsrOPGWKoij+kPV7QTkhN4oTpSgl6iR8AH7NTm4ctyyzckWjRLx74Wc5rIZhPM5KWPGUG9PtAUvkU3yI49fs5Mb1diwjUKOltuF5Wzz7ZrIWjvMEPcb4LFpIsmkHxbXyoopQjCRNeAmtzkdS25jT2Etz/rxSBNd1HwRJLm6cXlXVY7p6qoxmahWlyZ8EIaxW2WQy2X358qUhCMLDHL9+67ru30mS9HP0m7Zt7zx79szK+Rr3TBTFPzuOg7vd7q+RiE9HUZTT8/PzL1heM8H+ixDynaIo/xEXYbJt+x/Oz897giD8Laf3u9U07d8nk8k/R7/pOM72kydPZiyfCyH0wfM8MXqvIKpTUyeGIo1hy7bMa/lph6l6mqSVuQy3X9Xyw9ZeWN7IDELoKkkWW5KfJ1YXWZa1U2GLFO56eULISZKWpkxb9lU+KqjVp6GkPRCE0NVwOHyVVenPkhuIvkfSaYnh8URtXv3TVnme9wYKUfhXFB2zAp4XPUkDf/jQk87XbRLwWfeoDOjpuD0h5EQUxQtd1w9XZRK0+uKo5q2+pmlHrL1cqgR/xYdbFAKkpmlHWeAru9JH+xfFNNj1McZnSQf5AfALOLl5HmZeSQQr58+iDQ1PAD/vPSrD6UVRvIguADl8KF9V1eM2thdfm0b/eVeX2Wy2XQKYuaMYNU2A3ICfz+edMp9b1/XD6D2ez+edAtEgHyF0pev6YdbOCcBnoDJFuH+J1d8PdfsNTgC/yC5YIgHnE0JOaB2O67pbZUKgGOOz0Wi01yQVWqsVH2N8VsT5DSMzLKe00Fy3pgngF6V9jJGnO57OOUTcGiq0VifZRbdfhNBVEZAwHkT3EQXIMwEYJlpqLD5plQ/uhV90YiUpLXlKtZumQmt3cG8M90x9mHHhydFotFcENEVX/wJUy8cYnxWV/BZY5X2E0JWqqsdpURjXdbdqdNhroUJrB/wUxytx+057HdM0n+u6fphjIviqqh4XWZXn83knKcyalpFO200yrtMPd4/hcPgqa0K1IEnnh5MSgF8AVAmrFPO2Op/PO5Zl7QyHw1eaph1FXt+nk0dFARtxPmPVk1nXRYUp/fBzEkJOdF0/HI1Ge0V2jjKh36qokKZpR7yoUCvVmTyt3+8fvXnz5h8TlIe3GON3/X7f6PV6U1rhmdc8z9vyPE8Kx2Kx+JvFYtGlVZAZ9b6d/f39byVJcgeDwe+LvPdgMHgty/IsqN91ut3uQlGUnxhqjjvj8XgwmUxeXl5efsZRhcrTbkVRfD8YDEZlntnarvgMTpmfxXXXdcxms21N045atMIXokJAdTLoRIEHe+dgtSXhUoUIsKgT30bgs/J/YZNWNsbspR/KJgzD2F1FJWJ0ZV8DsHM5lGKjgB+lPmV0+uFEaPuOMJvNtg3D2NU07YglSbeqcuvGndvQYRuPx//WNg/J87ytfr//5vT09MuSTtytIAgCxvidLMuOJEmuoii2JEkes+PFYLZt74TOtW3bzxzHkW9ubv66pQ4qs4mi+OfpdKrKsvyXMq9TeVRnPB7vTSaTl7ZtkzbWZY7H4739/f1vb25ufsM7+hA8qPeSJHndbncRRl6CSeHRnciiDzOMFFGTVQq/5zjOk8Vi0Y0AXFg3kNP3U1XVP04mE40Ljurqf59H094k9y8j1+XFWWPGEgZbMq8VHD8ibKr8RGzTNJ+zTrCaU/MwKtAotc65jVT9FM5MsuwwZar/W1JNtdGAF0XxokrVZmMHvSGErqrqt+i67hZC6ApjfFaGXsEEaK5eeK3UmXHKyaKy3iKgDXeYosXpcROpBT7ARgC+rqx5I44kXQ0kiuJFFat/tKiax9Y5n887o9Fob51i4m2gNE3IRBpLrMQkkCpZ/Smdjk8IOeERXbIsayeib4FJwKCxabK1eKNZxbjsKY+sXI7OAj6vzg1hJAkmwWrU2rZCspBSv8ltZc5oq8F1AkQnAdCh+2Bvm8apFXqSFN0MV2CmVBP5PIscaFGYqqrHG7Ib3BWMQEMp9lLBSjz+jC5iPiHkpKr4cTgR1mhHWBnBXmvVmXkkw7wmgGmaz7M6gImieFE1Hw1LGcPJEFfK2BaAh4uCpmlHYb3uKhfstK70cDAYHL5+/fpf0gRXCKEPg8FgNBgMxqyCJcdxtnu93tvLy8u/zyOOCsoT/7OOe7BYLDqO48jRUkbHceTguqOitLLCtNvoF+Fxq4GIzg2Ec05epanjONvdbndRpyq1tepMFptMJruDweB1lmKy7ARYLBadfr//5u3bt7/LAaBbhNAvvV5v2uv1zLomQZ5a3wSZshL+P6zDjfs9ltpc+hqm02lvMpm8lGXZKVJn3Ki1uYiiQKVQKeeUoVHSnRPXxoaoDZQt+nGH8AHHL3/8Z15Q+oSQE5Y8AGPnsWVUeLfONbqWZe0k9BdaOdCvTOkhw9E7zH1YODRQuutOVrSXTdvu+XA4fJXhcK8k6Feq5rZEVy8/PK0j7yQo2Uo8MSLC0tipLpAbhrGr6/phgchS5bUVG3fcZ1bkYDAYvGaslb0VRfF96KBmOXZ5nWzWaApC6JdI1MQNSxLpMkSeTrBt20oYJfI8TwoaRxWKDiGEPozHY73f7/9hVesYV7aT2mQy2d3f3/+2RMevW4TQL4qi2MEksOPCcEF3sf8ej8fCzc1NbfWlEZD9IsuywwD2KKi51eNijP80mUw0nhMTojqMMgROHcDuuHlMgmbpuu5S07SN1t2UOYMMqE5FCZ/xeDwYj8f/ypuWiKIoSJIkKIoidLtdodvtCrZtC9PptM4doFFDCH2YTCZaG3IXsOKnOMAr2AOy1br5dewluratAlmP+IHx/5GwVQ3FQgvBQI25Jr0iV6Y9HwAfWmFDsTcAvz00yDCMXVVVj2EXqEd+DcCHHvGt6lC2CZRmY48CKpLdtG1bmU6nXwcyZW5Jn5bYrSiK7/v9vtHv9yeroJmHzG0DZtv2znQ6/dq2beX8/PyLFZ0Etxjjd4qi2P1+31j5bCsAv/4EmeM4sm3bSst7z9+KovheURRbURQrSYYBBsAvRY0cx5GD8cTzPCnYGeqgSPd67yuKYsmy7ASCNwA6AL+ZCRE9+jOgTc8iu0c3MkESDWP8LiwXjB4qoSiKHfz7E9xtAD4YWCF7ALcADIAPBgbABwMD4IOBAfDBwAD4YGAAfDAwAD4YGAAfDAyADwYGwAcDA+CDgdVi/zsAh3dWJSI2sGIAAAAASUVORK5CYII=",
                                            className: "logo"
                                        }), Object(s.jsx)("div", {
                                            className: "login__check"
                                        }), Object(s.jsxs)("div", {
                                            className: "login__form",
                                            children: [Object(s.jsx)("p", {
                                                id: "error_message",
                                                children: t("robin-wrong")
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("input", {
                                                    type: "password",
                                                    id: "wachtwoord",
                                                    className: "login__input name",
                                                    placeholder: t("robin-code")
                                                }), Object(s.jsx)("button", {
                                                    onClick: function() {
                                                        return e.check()
                                                    },
                                                    type: "button",
                                                    className: "loginsubmit",
                                                    children: t("robin-login")
                                                })]
                                            })]
                                        })]
                                    })
                                })
                            })
                        }
                    }]), i
                }(a.a.Component)),
                vt = Object(p.a)(["games"])(ft),
                yt = i.p + "static/media/tv.0daba667.png",
                wt = i.p + "static/media/micbutton.305a92db.png",
                kt = i.p + "static/media/locationbutton.b7ad8ba9.png",
                Ct = i.p + "static/media/audio1.21d2eae2.gif",
                Et = i.p + "static/media/robin_1.41896252.mp3",
                It = i(653),
                Bt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            NB: "",
                            OL: "",
                            playing: !1
                        }, s.check = s.check.bind(Object(ve.a)(s)), s.play = s.play.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            "241" === this.state.NB && "380" === this.state.OL && (window.location.href = "rooms")
                        }
                    }, {
                        key: "play",
                        value: function() {
                            document.getElementById("call").play(), this.setState({
                                playing: !0
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Boyard_Heli",
                                style: {
                                    height: "100%",
                                    margin: 0,
                                    backgroundColor: "#333333"
                                },
                                children: [Object(s.jsxs)(jt.a, {
                                    children: [Object(s.jsxs)(ht.a, {
                                        span: 12,
                                        children: [this.state.playing && Object(s.jsx)("img", {
                                            src: Ct,
                                            style: {
                                                position: "absolute",
                                                width: "50%",
                                                margin: "auto",
                                                top: 0,
                                                bottom: 0,
                                                marginLeft: "25%",
                                                padding: 20
                                            }
                                        }), Object(s.jsx)("img", {
                                            src: yt,
                                            style: {
                                                width: "70%",
                                                marginLeft: "15%"
                                            }
                                        })]
                                    }), Object(s.jsxs)(ht.a, {
                                        span: 12,
                                        children: [Object(s.jsx)("div", {
                                            style: {
                                                height: "100px",
                                                display: "block",
                                                position: "absolute",
                                                width: "50%",
                                                margin: "auto",
                                                top: 0,
                                                bottom: 0,
                                                marginLeft: "25%",
                                                padding: 20
                                            },
                                            children: Object(s.jsx)("p", {
                                                id: "time",
                                                style: {
                                                    color: "white",
                                                    textAlign: "center",
                                                    lineHeight: "50px",
                                                    fontSize: 70,
                                                    fontWeight: 800
                                                },
                                                children: "TEST"
                                            })
                                        }), Object(s.jsx)("img", {
                                            src: yt,
                                            style: {
                                                width: "70%",
                                                marginLeft: "15%"
                                            }
                                        })]
                                    })]
                                }), Object(s.jsxs)(jt.a, {
                                    children: [Object(s.jsx)(ht.a, {
                                        span: 12,
                                        style: {
                                            textAlign: "center"
                                        },
                                        children: Object(s.jsx)("img", {
                                            onClick: this.play,
                                            src: wt,
                                            style: {
                                                width: "150px"
                                            }
                                        })
                                    }), Object(s.jsxs)(ht.a, {
                                        span: 12,
                                        style: {
                                            textAlign: "center"
                                        },
                                        children: [Object(s.jsx)("p", {
                                            style: {
                                                margin: 0,
                                                color: "white",
                                                fontSize: 20
                                            },
                                            children: t("robin-north")
                                        }), Object(s.jsx)("br", {}), Object(s.jsx)(It.a, {
                                            style: {
                                                width: 300,
                                                marginBottom: 20
                                            },
                                            onChange: function(t) {
                                                return e.setState({
                                                    NB: t.target.value
                                                })
                                            },
                                            value: this.state.NB
                                        }), Object(s.jsx)("br", {}), Object(s.jsxs)("p", {
                                            style: {
                                                margin: 0,
                                                color: "white",
                                                fontSize: 20
                                            },
                                            children: [t("robin-east"), "}"]
                                        }), Object(s.jsx)("br", {}), Object(s.jsx)(It.a, {
                                            style: {
                                                width: 300,
                                                marginBottom: 20
                                            },
                                            onChange: function(t) {
                                                return e.setState({
                                                    OL: t.target.value
                                                })
                                            },
                                            value: this.state.OL
                                        }), Object(s.jsx)("br", {}), Object(s.jsx)("img", {
                                            onClick: this.check,
                                            src: kt,
                                            style: {
                                                width: "80px"
                                            }
                                        })]
                                    })]
                                }), Object(s.jsx)("audio", {
                                    src: Et,
                                    id: "call"
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                St = Object(p.a)(["games"])(Bt),
                Lt = i.p + "static/media/doorlock.2c628219.png",
                Qt = (i.p, i.p + "static/media/call.ff00f913.gif"),
                Ft = i.p + "static/media/calling.838b1c87.gif",
                Nt = i.p + "static/media/robin_3.334ecd18.mp3",
                Rt = (i(249), i(655)),
                Gt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            buttons: new Array(36).fill(!1),
                            audio: !0
                        }, s.play = s.play.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "play",
                        value: function() {
                            var e = this;
                            if (!this.state.playing) {
                                var t = document.getElementById("call");
                                this.setState({
                                    playing: !0
                                }), t.play(), setTimeout((function() {
                                    document.getElementById("call").pause(), e.setState({
                                        audio: !1
                                    })
                                }), 16e3)
                            }
                        }
                    }, {
                        key: "match",
                        value: function(e) {
                            for (var t = [!0, !1, !1, !1, !1, !0, !1, !0, !1, !1, !0, !1, !1, !1, !0, !0, !1, !1, !1, !1, !0, !0, !1, !1, !1, !0, !1, !1, !0, !1, !0, !1, !1, !1, !1, !0], i = 0; i < e.length; i++)
                                if (e[i] !== t[i]) return !1;
                            return !0
                        }
                    }, {
                        key: "switchbutton",
                        value: function(e) {
                            var t = this.state.buttons;
                            t[e] = !t[e], this.setState({
                                buttons: t
                            }), this.match(t) && (window.location.href = "alarm")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Boyard_Door",
                                style: {
                                    height: "100%",
                                    margin: 0
                                },
                                children: [Object(s.jsx)("audio", {
                                    src: Nt,
                                    id: "call"
                                }), Object(s.jsx)(Rt.a, {
                                    title: t("robin-phone"),
                                    visible: this.state.audio,
                                    width: 570,
                                    footer: [],
                                    children: this.state.playing ? Object(s.jsx)("img", {
                                        src: Ft,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        }
                                    }) : Object(s.jsx)("img", {
                                        src: Qt,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        },
                                        onClick: this.play
                                    })
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        width: "100%",
                                        height: "100%",
                                        textALign: "center"
                                    },
                                    children: [Object(s.jsx)("img", {
                                        src: Lt,
                                        style: {
                                            margin: "auto",
                                            height: 600,
                                            display: "block"
                                        }
                                    }), Object(s.jsx)("div", {
                                        style: {
                                            width: 250,
                                            position: "absolute",
                                            top: 270,
                                            left: "50%",
                                            marginLeft: -111
                                        },
                                        children: this.state.buttons.map((function(t, i) {
                                            return Object(s.jsx)("div", {
                                                onClick: function() {
                                                    return e.switchbutton(i)
                                                },
                                                style: {
                                                    width: 30,
                                                    height: 30,
                                                    float: "left",
                                                    margin: 3,
                                                    backgroundColor: t ? "blue" : "black"
                                                }
                                            })
                                        }))
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Yt = Object(p.a)(["games"])(Gt),
                Mt = i.p + "static/media/robin_4.75bf23db.mp3",
                Ht = (i(556), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            modal: !0,
                            playing: !1,
                            message: !1
                        }, s.check = s.check.bind(Object(ve.a)(s)), s.play = s.play.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            document.getElementById("1").checked && !document.getElementById("2").checked && document.getElementById("3").checked && document.getElementById("4").checked && !document.getElementById("5").checked && document.getElementById("6").checked && !document.getElementById("7").checked && (window.location.href = "end")
                        }
                    }, {
                        key: "start",
                        value: function(e) {
                            document.getElementById("alarm").play(), document.getElementById("overlay").style.visibility = "hidden"
                        }
                    }, {
                        key: "play",
                        value: function() {
                            var e = this;
                            if (!this.state.playing) {
                                var t = document.getElementById("call");
                                this.setState({
                                    playing: !0
                                }), t.play(), setTimeout((function() {
                                    document.getElementById("call").pause(), e.setState({
                                        message: !0
                                    })
                                }), 34e3)
                            }
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Boyard_Alarm",
                                children: [Object(s.jsxs)(Rt.a, {
                                    title: t("robin-phone"),
                                    visible: this.state.modal,
                                    width: 570,
                                    footer: [],
                                    children: [this.state.playing && this.state.message && Object(s.jsxs)("div", {
                                        children: [Object(s.jsx)("p", {
                                            children: t("robin-step1")
                                        }), Object(s.jsx)("p", {
                                            children: t("robin-step2")
                                        }), Object(s.jsx)("p", {
                                            children: t("robin-step3")
                                        }), Object(s.jsx)(M.a, {
                                            onClick: function() {
                                                return e.setState({
                                                    modal: !1
                                                })
                                            },
                                            children: t("robin-step4")
                                        })]
                                    }), this.state.playing && !this.state.message && Object(s.jsx)("img", {
                                        src: Ft,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        },
                                        onClick: this.play
                                    }), !this.state.playing && Object(s.jsx)("img", {
                                        src: Qt,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        },
                                        onClick: this.play
                                    })]
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    children: "\u00A0"
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        backgroundColor: "#888"
                                    },
                                    children: [Object(s.jsxs)("p", {
                                        id: "info",
                                        children: [t("robin-cam"), " ", Object(s.jsxs)("span", {
                                            style: {
                                                color: "green"
                                            },
                                            children: ["  ", t("robin-online")]
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "1",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            className: "tlabel",
                                            "data-off": t("robin-red"),
                                            "data-on": t("robin-yellow")
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "2",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            "data-off": t("robin-on"),
                                            "data-on": t("robin-off")
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "3",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            id: "b1",
                                            "data-off": "8",
                                            "data-on": "3"
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "4",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            id: "b2",
                                            "data-off": "\u25fc",
                                            "data-on": "\u2605"
                                        })]
                                    }), Object(s.jsx)("br", {}), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "5",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            id: "b3",
                                            "data-off": t("robin-stop"),
                                            "data-on": t("robin-start")
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "6",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            id: "b4",
                                            "data-off": "11",
                                            "data-on": "7"
                                        })]
                                    }), Object(s.jsxs)("span", {
                                        className: "toggle",
                                        children: [Object(s.jsx)("input", {
                                            onClick: this.check,
                                            id: "7",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            "data-off": "B",
                                            "data-on": "K"
                                        })]
                                    })]
                                }), Object(s.jsx)("audio", {
                                    src: Mt,
                                    id: "call"
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                Jt = Object(p.a)(["games"])(Ht),
                Dt = (i.p, i.p + "static/media/robin_2.467570fa.mp3"),
                Vt = i(165),
                Kt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            modal: !1,
                            audio: !0,
                            selection: "1",
                            playing: !1
                        }, s.check = s.check.bind(Object(ve.a)(s)), s.play = s.play.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            this.setState({
                                modal: !1
                            }), "3" === this.state.selection && (window.location.href = "door")
                        }
                    }, {
                        key: "play",
                        value: function() {
                            var e = this;
                            if (!this.state.playing) {
                                var t = document.getElementById("call");
                                this.setState({
                                    playing: !0
                                }), t.play(), setTimeout((function() {
                                    document.getElementById("call").pause(), e.setState({
                                        audio: !1
                                    })
                                }), 18e3)
                            }
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Boyard_Rooms",
                                style: {
                                    height: "100%",
                                    margin: 0,
                                    backgroundColor: "#999"
                                },
                                children: [Object(s.jsx)("audio", {
                                    src: Dt,
                                    id: "call"
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    children: "\u00A0"
                                }), Object(s.jsx)(M.a, {
                                    id: "contact",
                                    onClick: function() {
                                        return e.setState({
                                            modal: !0
                                        })
                                    },
                                    children: t("robin-contact")
                                }), Object(s.jsx)("div", {
                                    id: "plan"
                                }), Object(s.jsx)(Rt.a, {
                                    title: t("robin-phone"),
                                    visible: this.state.audio,
                                    width: 570,
                                    footer: [],
                                    children: this.state.playing ? Object(s.jsx)("img", {
                                        src: Ft,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        }
                                    }) : Object(s.jsx)("img", {
                                        src: Qt,
                                        style: {
                                            width: "70%",
                                            marginLeft: "15%"
                                        },
                                        onClick: this.play
                                    })
                                }), Object(s.jsxs)(Rt.a, {
                                    title: t("robin-info"),
                                    visible: this.state.modal,
                                    onCancel: function() {
                                        return e.setState({
                                            modal: !1
                                        })
                                    },
                                    width: 690,
                                    footer: [Object(s.jsx)(M.a, {
                                        style: {
                                            background: "#F0730D",
                                            color: "white",
                                            borderColor: "#F0730D"
                                        },
                                        onClick: this.check,
                                        children: t("robin-send")
                                    }, "info")],
                                    children: [Object(s.jsx)("p", {
                                        style: {
                                            textAlign: "center",
                                            fontWeight: 600,
                                            color: "#F0730D"
                                        },
                                        children: t("robin-warning")
                                    }), Object(s.jsxs)(Vt.a.Group, {
                                        value: this.state.selection,
                                        onChange: function(t) {
                                            return e.setState({
                                                selection: t.target.value
                                            })
                                        },
                                        children: [Object(s.jsxs)(Vt.a.Button, {
                                            value: "1",
                                            children: [t("robin-room"), " 1"]
                                        }), Object(s.jsxs)(Vt.a.Button, {
                                            value: "2",
                                            children: [t("robin-room"), " 2"]
                                        }), Object(s.jsxs)(Vt.a.Button, {
                                            value: "3",
                                            children: [t("robin-room"), " 3"]
                                        }), Object(s.jsxs)(Vt.a.Button, {
                                            value: "4",
                                            children: [t("robin-room"), " 4"]
                                        }), Object(s.jsxs)(Vt.a.Button, {
                                            value: "5",
                                            children: [t("robin-room"), " 5"]
                                        }), Object(s.jsxs)(Vt.a.Button, {
                                            value: "6",
                                            children: [t("robin-room"), " 6"]
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                zt = Object(p.a)(["games"])(Kt),
                Tt = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: At,
                                escape: !0,
                                next: "login"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: At,
                                escape: !0,
                                next: "login"
                            }) : "end" == this.props.match.params.phase ? Object(s.jsx)(fe, {}) : "login" == this.props.match.params.phase ? Object(s.jsx)(vt, {}) : "helicopter" == this.props.match.params.phase ? Object(s.jsx)(St, {}) : "door" == this.props.match.params.phase ? Object(s.jsx)(Yt, {}) : "alarm" == this.props.match.params.phase ? Object(s.jsx)(Jt, {}) : "rooms" == this.props.match.params.phase ? Object(s.jsx)(zt, {}) : Object(s.jsx)(A.a, {
                                to: "/"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ut = Object(A.h)(Tt),
                Xt = i.p + "static/media/background_start.c0de3bd7.jpg",
                Pt = (i(557), i.p + "static/media/screw1.b828ff18.png"),
                Wt = i.p + "static/media/screw2.9e4a4c4f.png",
                Zt = i.p + "static/media/screw3.be324600.png",
                qt = i.p + "static/media/screw4.b982b42c.png",
                _t = i.p + "static/media/cablered.001afc29.png",
                $t = i.p + "static/media/cablegreen.8246fe00.png",
                ei = i.p + "static/media/cableyellow.86a1fc4a.png",
                ti = i.p + "static/media/ledred.bd63140a.png",
                ii = i.p + "static/media/ledgreen.4439d038.png",
                si = i.p + "static/media/cablegreen-cut.8c59d30d.png",
                ni = i.p + "static/media/cableyellow-cut.568307da.png",
                ai = i.p + "static/media/cablered-cut.c57fe82f.png",
                $q = i.p + "static/media/epic_space.43204e22.mp3",
                ci = i(647),
                ri = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            screws: [0, 0, 0, 0],
                            moving: !1,
                            cut: ""
                        }, s.next = s.next.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "open",
                        value: function() {
                            if (135 == this.state.screws[0] && 0 == this.state.screws[1] && 90 == this.state.screws[2] && 45 == this.state.screws[3]) {
                                this.setState({
                                    moving: !0
                                });
                                var e, t = document.getElementById("cover");
                                var i = 0;
                                e = setInterval((function() {
                                    i += 2, t.style.marginTop = i + "px";
                                    var s = t.getBoundingClientRect();
                                    window.screen.height - s.top - 130 < 0 && (clearInterval(e), document.getElementById("covercontainer").style.display = "none")
                                }), 25)
                            }
                            console.log(this.state)
                        }
                    }, {
                        key: "next",
                        value: function() {
                            var e = this.props.t;
                            this.setState({
                                cut: "red"
                            }), document.getElementById("ledtext").innerHTML = e("OPEN"), setTimeout((function() {
                                window.location.href = "codepad"
                            }), 2e3)
                        }
                    }, {
                        key: "handleScrew",
                        value: function(e) {
                            var t = this.state.screws;
                            t[e] = (t[e] + 45) % 180, this.setState({
                                screws: t
                            }), console.log(this.state.screws), this.open()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                                setTimeout((function() {
                                    document.getElementById("music").play();
                                }), 1e3);                                
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Labo_Wires",
                                children: [Object(s.jsx)("div", {
                                    id: "metal-left"
                                }), Object(s.jsx)("div", {
                                    id: "metal-right"
                                }), Object(s.jsx)("div", {
                                    id: "metal-top"
                                }), Object(s.jsx)("div", {
                                    id: "covercontainer",
                                    children: Object(s.jsxs)("div", {
                                        id: "cover",
                                        children: [Object(s.jsx)("img", {
                                            id: "screw1",
                                            onClick: function() {
                                                return e.handleScrew(0)
                                            },
                                            style: {
                                                transform: "rotate(".concat(this.state.screws[0], "deg)")
                                            },
                                            class: "screw",
                                            src: Pt
                                        }), Object(s.jsx)("img", {
                                            id: "screw2",
                                            onClick: function() {
                                                return e.handleScrew(1)
                                            },
                                            style: {
                                                transform: "rotate(".concat(this.state.screws[1], "deg)")
                                            },
                                            class: "screw",
                                            src: Wt
                                        }), Object(s.jsx)("img", {
                                            id: "screw3",
                                            onClick: function() {
                                                return e.handleScrew(2)
                                            },
                                            style: {
                                                transform: "rotate(".concat(this.state.screws[2], "deg)")
                                            },
                                            class: "screw",
                                            src: Zt
                                        }), Object(s.jsx)("img", {
                                            id: "screw4",
                                            onClick: function() {
                                                return e.handleScrew(3)
                                            },
                                            style: {
                                                transform: "rotate(".concat(this.state.screws[3], "deg)")
                                            },
                                            class: "screw",
                                            src: qt
                                        })]
                                    })
                                }), Object(s.jsxs)("div", {
                                    id: "cables",
                                    children: [Object(s.jsx)("div", {
                                        id: "buffer"
                                    }), Object(s.jsxs)(ci.a, {
                                        title: Object(s.jsx)("p", {
                                            children: t("labo-wire-alert")
                                        }),
                                        onConfirm: this.next,
                                        okText: t("labo-cut"),
                                        cancelText: t("labo-back"),
                                        children: [Object(s.jsxs)("div", {
                                            children: [Object(s.jsx)("div", {
                                                class: "number",
                                                children: "1"
                                            }), Object(s.jsx)("img", {
                                                id: "red",
                                                class: "cable",
                                                src: "red" == this.state.cut ? ai : _t
                                            }), " "]
                                        }), " "]
                                    }), Object(s.jsx)(ci.a, {
                                        title: Object(s.jsx)("p", {
                                            children: t("labo-wire-alert")
                                        }),
                                        onConfirm: function() {
                                            return e.setState({
                                                cut: "yellow"
                                            })
                                        },
                                        okText: t("labo-cut"),
                                        cancelText: t("labo-back"),
                                        children: Object(s.jsxs)("div", {
                                            children: [Object(s.jsx)("div", {
                                                class: "number",
                                                children: "2"
                                            }), Object(s.jsx)("img", {
                                                id: "yellow",
                                                class: "cable",
                                                src: "yellow" == this.state.cut ? ni : ei
                                            })]
                                        })
                                    }), Object(s.jsx)(ci.a, {
                                        title: Object(s.jsx)("p", {
                                            children: t("labo-wire-alert")
                                        }),
                                        onConfirm: function() {
                                            return e.setState({
                                                cut: "green"
                                            })
                                        },
                                        okText: t("labo-cut"),
                                        cancelText: t("labo-back"),
                                        width: 400,
                                        children: Object(s.jsxs)("div", {
                                            children: [Object(s.jsx)("div", {
                                                class: "number",
                                                children: "3"
                                            }), Object(s.jsx)("img", {
                                                id: "green",
                                                class: "cable",
                                                src: "green" == this.state.cut ? si : $t
                                            })]
                                        })
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "timecontainer",
                                    children: Object(s.jsx)("p", {
                                        id: "time",
                                        style: {
                                            visibility: "hidden"
                                        },
                                        children: "\u00A0"
                                    })
                                }), Object(s.jsxs)("div", {
                                    id: "ledcontainer",
                                    children: [t("labo-doors"), Object(s.jsx)("br", {}), Object(s.jsxs)("div", {
                                        id: "doors",
                                        children: [Object(s.jsx)("img", {
                                            id: "led",
                                            src: "red" == this.state.cut ? ii : ti
                                        }), Object(s.jsx)("div", {
                                            id: "ledtext",
                                            children: t("labo-closed")
                                        })]
                                    })]
                                }), Object(s.jsx)("audio", {
                                    src: $q,
                                    id: "music",
                                    loop: !0
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                oi = Object(p.a)(["games"])(ri);
            var li = function(e) {
                    O()(document).ready((function(t) {
                        t(document).ready((function() {
                            var i = "";
                            i.toString(), t("#l_numbers button").click((function() {
                                var s = t(this).text().toString();
                                i += s;
                                var n = parseInt(i.length);
                                n--, t("#l_fields .l_numberfield:eq(" + n + ")").addClass("active"), 4 == n && ("PRUTS" == i ? window.location.href = e : (t("#l_fields").addClass("miss"), i = "", setTimeout((function() {
                                    t("#l_fields .l_numberfield").removeClass("active")
                                }), 200), setTimeout((function() {
                                    t("#l_fields").removeClass("miss")
                                }), 500)))
                            })), t("#restartbtn").click((function() {
                                i = "", t("#l_fields .l_numberfield").removeClass("active"), t("#l_fields .l_numberfield").removeClass("right"), t("#l_numbers").removeClass("hide")
                            }))
                        }))
                    }))
                },
                di = (i(558), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            li("../FB_ER02/engine")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            setTimeout((function() {
                                document.getElementById("music").play();
                            }), 1e3);
                            return Object(s.jsx)("div", {
                                className: "Labo_Codepad",
                                children: Object(s.jsx)("div", {
                                    id: "pincode",
                                    children: Object(s.jsx)("div", {
                                        className: "table",
                                        children: Object(s.jsxs)("div", {
                                            className: "cell",
                                            children: [Object(s.jsxs)("div", {
                                                id: "anleitung",
                                                children: [Object(s.jsx)("audio", {
                                                    src: "http://localhost:8000/static/media/tension.mp3",
                                                    id: "music",
                                                    loop: !0
                                                }), Object(s.jsx)("p", {
                                                    id: "time",
                                                    style: {
                                                        visibility: "hidden"
                                                    },
                                                    children: "\u00A0"
                                                }), Object(s.jsx)("p", {
                                                    id: "text1",
                                                    children: Object(s.jsx)("strong", {
                                                        children: e("labo-codepad")
                                                    })
                                                })]
                                            }), Object(s.jsx)("div", {
                                                id: "l_fields",
                                                children: Object(s.jsxs)("div", {
                                                    className: "l_grid",
                                                    children: [Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-5 l_numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-5 l_numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-5 l_numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-5 l_numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-5 l_numberfield",
                                                        children: Object(s.jsx)("span", {})
                                                    })]
                                                })
                                            }), Object(s.jsx)("div", {
                                                id: "l_numbers",
                                                children: Object(s.jsxs)("div", {
                                                    className: "l_grid",
                                                    children: [Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "S"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "U"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "E"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "R"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "I"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "N"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "T"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "K"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "P"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3"
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3",
                                                        children: Object(s.jsx)("button", {
                                                            children: "#"
                                                        })
                                                    }), Object(s.jsx)("div", {
                                                        className: "l_grid__col l_grid__col--1-of-3"
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        }
                    }]), i
                }(a.a.Component)),
                ji = Object(p.a)(["games"])(di),
                hi = i.p + "static/media/left.9df58750.png",
                ui = i.p + "static/media/right.55bf6438.png",
                bi = i.p + "static/media/experiment.66ceda05.png",
                gi = i.p + "static/media/back.c0a7145e.png",
                mi = (i(559), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            secretVisible: !1
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsx)("div", {
                                id: "window",
                                className: "Labo_Menu",
                                children: this.state.secretVisible ? Object(s.jsxs)("div", {
                                    children: [" ", Object(s.jsx)("img", {
                                        src: bi,
                                        id: "image"
                                    }), Object(s.jsx)("img", {
                                        src: gi,
                                        id: "back",
                                        onClick: function() {
                                            return e.setState({
                                                secretVisible: !1
                                            })
                                        }
                                    }), Object(s.jsx)("div", {
                                        id: "timecontainer2",
                                        children: Object(s.jsx)("p", {
                                            id: "time2"
                                        })
                                    })]
                                }) : Object(s.jsxs)("div", {
                                    children: [Object(s.jsxs)("div", {
                                        id: "left",
                                        onClick: function() {
                                            return e.setState({
                                                secretVisible: !0
                                            })
                                        },
                                        children: [Object(s.jsx)("img", {
                                            class: "icon",
                                            src: hi
                                        }), Object(s.jsx)("p", {
                                            class: "title",
                                            children: t("labo-docs")
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        id: "right",
                                        onClick: function() {
                                            return window.location.href = "recept"
                                        },
                                        children: [Object(s.jsx)("img", {
                                            class: "icon",
                                            src: ui
                                        }), Object(s.jsx)("p", {
                                            class: "title",
                                            children: t("labo-send")
                                        })]
                                    }), Object(s.jsx)("div", {
                                        id: "timecontainer",
                                        children: Object(s.jsx)("p", {
                                            id: "time",
                                            children: "\u00A0"
                                        })
                                    })]
                                })
                            })
                        }
                    }]), i
                }(a.a.Component)),
                pi = Object(p.a)(["games"])(mi),
                xi = (i.p, i.p + "static/media/back2.97bb5ca5.png"),
                Oi = (i(560), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            secretVisible: !1
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "send",
                        value: function() {
                            var e = ["item1", "item2", "item3", "item4", "item5", "item6", "item7", "item8"],
                                t = [!0, !1, !1, !0, !1, !1, !0, !1, !1];
                            for (var i in e) {
                                var s = document.getElementById(e[i]).checked;
                                if (console.log(s, t[i]), s != t[i]) return null
                            }
                            "A6H9L@hotmail.com" == document.getElementById("email").value && (window.location.href = "end")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "Labo_Recept",
                                children: [Object(s.jsxs)("div", {
                                    class: "container",
                                    children: [Object(s.jsxs)("div", {
                                        id: "header",
                                        children: [Object(s.jsx)("h1", {
                                            children: e("labo-sendto")
                                        }), Object(s.jsxs)("center", {
                                            children: [" ", Object(s.jsx)("input", {
                                                type: "text",
                                                id: "email",
                                                placeholder: "email@email.com"
                                            }), Object(s.jsx)("button", {
                                                id: "sendbutton",
                                                onClick: this.send,
                                                children: e("labo-send")
                                            })]
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "items",
                                        children: [Object(s.jsx)("input", {
                                            id: "item1",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item1",
                                            children: e("labo-i1")
                                        }), Object(s.jsx)("input", {
                                            id: "item2",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item2",
                                            children: e("labo-i2")
                                        }), Object(s.jsx)("input", {
                                            id: "item3",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item3",
                                            children: e("labo-i3")
                                        }), Object(s.jsx)("input", {
                                            id: "item4",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item4",
                                            children: e("labo-i4")
                                        }), Object(s.jsx)("input", {
                                            id: "item5",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item5",
                                            children: e("labo-i5")
                                        }), Object(s.jsx)("input", {
                                            id: "item6",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item6",
                                            children: e("labo-i6")
                                        }), Object(s.jsx)("input", {
                                            id: "item7",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item7",
                                            children: e("labo-i7")
                                        }), Object(s.jsx)("input", {
                                            id: "item8",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item8",
                                            children: e("labo-i8")
                                        }), Object(s.jsx)("input", {
                                            id: "item9",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item9",
                                            children: e("labo-i9")
                                        }), Object(s.jsx)("input", {
                                            id: "item10",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item10",
                                            children: e("labo-i10")
                                        }), Object(s.jsx)("input", {
                                            id: "item11",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item11",
                                            children: e("labo-i11")
                                        }), Object(s.jsx)("input", {
                                            id: "item12",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item12",
                                            children: e("labo-i12")
                                        }), Object(s.jsx)("input", {
                                            id: "item13",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item13",
                                            children: e("labo-i13")
                                        }), Object(s.jsx)("input", {
                                            id: "item14",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item14",
                                            children: e("labo-i14")
                                        }), Object(s.jsx)("input", {
                                            id: "item15",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item15",
                                            children: e("labo-i15")
                                        }), Object(s.jsx)("input", {
                                            id: "item16",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item16",
                                            children: e("labo-i16")
                                        }), Object(s.jsx)("input", {
                                            id: "item17",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item17",
                                            children: e("labo-i17")
                                        }), Object(s.jsx)("input", {
                                            id: "item18",
                                            type: "checkbox"
                                        }), Object(s.jsx)("label", {
                                            for: "item18",
                                            children: e("labo-i18")
                                        }), Object(s.jsx)("h2", {
                                            class: "done",
                                            "aria-hidden": "true",
                                            children: e("labo-recipe")
                                        }), Object(s.jsx)("h2", {
                                            class: "undone",
                                            "aria-hidden": "true",
                                            children: e("labo-notused")
                                        })]
                                    })]
                                }), Object(s.jsx)("p", {
                                    id: "time",
                                    children: "\u00A0"
                                }), Object(s.jsx)("img", {
                                    src: xi,
                                    id: "back",
                                    onClick: function() {
                                        return window.location.href = "menu"
                                    }
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                Ai = Object(p.a)(["games"])(Oi),
                fi = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: Xt,
                                escape: !0,
                                next: "wires"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: Xt,
                                escape: !0,
                                next: "wires"
                            }) : "wires" == this.props.match.params.phase ? Object(s.jsx)(oi, {}) : "codepad" == this.props.match.params.phase ? Object(s.jsx)(ji, {}) : "menu" == this.props.match.params.phase ? Object(s.jsx)(pi, {}) : "recept" == this.props.match.params.phase ? Object(s.jsx)(Ai, {}) : "end" == this.props.match.params.phase ? Object(s.jsx)(fe, {}) : Object(s.jsx)(A.a, {
                                to: "/"
                            })
                        }
                    }]), i
                }(a.a.Component),
                vi = Object(A.h)(fi),
                yi = i.p + "static/media/background_start.3ff5ce09.jpg",
                wi = (i(561), i.p, i.p + "static/media/secret_logo.c6411944.png"),
                ki = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            "superman" == document.getElementById("wachtwoord").value && (document.getElementById("wachtwoord").value = "", window.location.href = "welcome")
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsx)("div", {
                                className: "Hero_Access",
                                children: Object(s.jsx)("div", {
                                    className: "demo",
                                    children: Object(s.jsxs)("div", {
                                        className: "login",
                                        children: [Object(s.jsx)("div", {
                                            className: "login__check"
                                        }), Object(s.jsxs)("div", {
                                            className: "login__form",
                                            children: [Object(s.jsx)("p", {
                                                id: "error_message",
                                                children: "Foute toegangscode."
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("img", {
                                                    src: wi,
                                                    height: 25
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "naam",
                                                    className: "login__input name",
                                                    placeholder: "Naam Hoofdkwartier"
                                                })]
                                            }), Object(s.jsxs)("div", {
                                                className: "login__row",
                                                children: [Object(s.jsx)("img", {
                                                    src: wi,
                                                    height: 25
                                                }), Object(s.jsx)("input", {
                                                    type: "text",
                                                    id: "leider",
                                                    className: "login__input name",
                                                    placeholder: "Naam Leider"
                                                }), Object(s.jsxs)("div", {
                                                    className: "login__row",
                                                    children: [Object(s.jsx)("img", {
                                                        src: wi,
                                                        height: 25
                                                    }), Object(s.jsx)("input", {
                                                        type: "password",
                                                        id: "wachtwoord",
                                                        className: "login__input name",
                                                        placeholder: "Geheim Wachtwoord"
                                                    }), Object(s.jsx)("button", {
                                                        onClick: function() {
                                                            return e.check()
                                                        },
                                                        type: "button",
                                                        className: "loginsubmit",
                                                        children: "Aanmelden"
                                                    })]
                                                })]
                                            })]
                                        })]
                                    })
                                })
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ci = (i(562), i.p + "static/media/loading.46c884f8.gif"),
                Ei = i.p + "static/media/alert.af0fc796.png",
                Ii = i.p + "static/media/mission_superhelden.164e8e34.mp3",
                Bi = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = document.getElementById("title");
                            setTimeout((function() {
                                e.innerHTML = "Toegang krijgen tot beveiligd systeem..."
                            }), 2e3), setTimeout((function() {
                                e.innerHTML = "Inloggen in database..."
                            }), 5e3), setTimeout((function() {
                                e.innerHTML = "Controleren op recente misdaden..."
                            }), 8e3), setTimeout((function() {
                                document.getElementById("form").style.display = "block"
                            }), 11e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                className: "Hero_Welcome",
                                style: {
                                    width: "100%",
                                    height: "100%"
                                },
                                children: [Object(s.jsx)("audio", {
                                    src: Ii,
                                    id: "mission"
                                }), Object(s.jsx)("div", {
                                    className: "cont",
                                    children: Object(s.jsxs)("div", {
                                        className: "demo",
                                        children: [Object(s.jsx)("h1", {
                                            id: "title",
                                            children: "Account aanmaken voor hoodkwartier..."
                                        }), Object(s.jsx)("img", {
                                            className: "loading",
                                            src: Ci
                                        })]
                                    })
                                }), Object(s.jsx)("div", {
                                    id: "form",
                                    className: "modal",
                                    children: Object(s.jsxs)("form", {
                                        className: "modal-content animate",
                                        method: "post",
                                        children: [Object(s.jsxs)("div", {
                                            className: "imgcontainer",
                                            children: [Object(s.jsx)("span", {
                                                className: "close",
                                                title: "Close Modal",
                                                children: "\xd7"
                                            }), Object(s.jsx)("img", {
                                                src: Ei,
                                                alt: "Avatar",
                                                className: "avatar"
                                            })]
                                        }), Object(s.jsxs)("div", {
                                            className: "container",
                                            children: [Object(s.jsxs)("p", {
                                                children: [Object(s.jsx)("b", {
                                                    children: "Inbraak in de snoepfabriek"
                                                }), Object(s.jsx)("br", {}), "Tijdstip : 3 uur geleden.", Object(s.jsx)("br", {})]
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                className: "briefing",
                                                onClick: function() {
                                                    return document.getElementById("mission").play()
                                                },
                                                children: "Beluister Briefing"
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                onClick: function() {
                                                    return window.location.href = "witness"
                                                },
                                                className: "getuigen_knop",
                                                children: "Contacteer Getuigen"
                                            })]
                                        })]
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Si = (i(563), i.p + "static/media/loading2.9b83f7d8.gif"),
                Li = i.p + "static/media/profile1.a94fbf17.png",
                Qi = i.p + "static/media/profile2.d95a1ffb.png",
                Fi = i.p + "static/media/profile3.df714e19.png",
                Ni = i.p + "static/media/profile4.70c4c65c.png",
                Ri = i.p + "static/media/profile5.733faead.png",
                Gi = {
                    cleaner: Li,
                    manager: Qi,
                    gaurd: Fi,
                    taster: Ni,
                    driver: Ri,
                    driver2: Ri
                },
                Yi = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        Object(l.a)(this, i), s = t.call(this, e);
                        var n = new URLSearchParams(s.props.location.search),
                            a = s.props.t;
                        return s.t = a, s.person = n.get("p"), s.state = {
                            loading: !0,
                            i: 1,
                            answer: a("FB_SH01_" + s.person + "_a_1")
                        }, s.typeWriter = s.typeWriter.bind(Object(ve.a)(s)), s.next = s.next.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "typeWriter",
                        value: function(e, t) {
                            var i = this;
                            e < t.length && (document.getElementById("chatbox").innerHTML += t.charAt(e), setTimeout((function() {
                                return i.typeWriter(e + 1, t)
                            }), 50)), e == t.length && "" != document.getElementById("b1").innerHTML && (document.getElementById("buttons").style.display = "block")
                        }
                    }, {
                        key: "next",
                        value: function() {
                            document.getElementById("buttons").style.display = "none", document.getElementById("chatbox").innerHTML = "", this.typeWriter(0, this.t("FB_SH01_" + this.person + "_q_" + (this.state.i + 1).toString())), this.setState({
                                i: this.state.i + 1,
                                answer: this.t("FB_SH01_" + this.person + "_a_" + (this.state.i + 1).toString())
                            })
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            setTimeout((function() {
                                e.setState({
                                    loading: !1
                                }), e.typeWriter(0, e.t("FB_SH01_" + e.person + "_q_1"))
                            }), 3e3, this)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                className: "Hero_Chat",
                                style: {
                                    width: "100%",
                                    height: "100%"
                                },
                                children: [Object(s.jsxs)("div", {
                                    id: "loading",
                                    className: "center",
                                    style: {
                                        display: this.state.loading ? "block" : "none"
                                    },
                                    children: [Object(s.jsx)("img", {
                                        className: "profilepicloader",
                                        src: Gi[this.person]
                                    }), Object(s.jsx)("img", {
                                        className: "loader",
                                        src: Si
                                    })]
                                }), Object(s.jsx)("a", {
                                    href: "witness",
                                    children: Object(s.jsx)("img", {
                                        className: "cross",
                                        src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALiQAAC4kBN8nLrQAAHOBJREFUeJzt3U+sbvtd1/HPObu35V6JIRoihKQGCTVtAMUJoa0TwQaUmjTaqB1oQohgiAMDxTZMHACthaEJEh2QMNCg0kgMGmjRAEKjNxoSKFCsFtMQAWMMto1t9V4Hz1337LPP/vP8WWv9/nxfr+Q7uOe2zTrJ7vN5n2fvs/ejsKbHSd6a5JuTfF2SNyT54iTPJflMkt9O8itJfj7JTyb5eJvHBOjGH0/yLUnekuSNSb4kyfNJPpfkd5P8RpKPJPlXSV5s9IxwpxeSfFeSTyR5+YT7uSRv3/9xAZp6lOSdSX4pp71m/lqSb8/hD1XQ3DuSfDKnfRDfvH+bw7sFALP7miT/Ppe9Zv5mkm/Y+8Fh8VySf5DLPoiv36eTvGvX3wHAvr4jyWezzmvmS0l+IIdPvcJuns/h81Frjf/1e/eOvw+AvXx/tnnN/CdJXrPj74PCnk/y09nmA3m59+z2uwHY3vuy7WvmP40IYGN7jL8IAGay9fiLADa35/iLAGAGe42/CGAzLcZfBAAj23v8RQCrazn+IgAYUavxFwGspofxFwHASFqPvwjgYj2NvwgARtDL+IsAztbj+IsAoGe9jb8I4GQ9j78IAHrU6/iLAI42wviLAKAnvY+/COBBI42/CAB6MMr4iwDuNOL4iwCgpdHGXwTwjJHHXwQALYw6/iKAV80w/iIA2NPo4y8CmGr8RQCwh1nGXwQUNuP4iwBgS7ONvwgoaObxFwHAFmYdfxFQSIXxFwHAmmYffxFQQKXxFwHAGqqMvwiYWMXxFwHAJaqNvwiYUOXxFwHAOaqOvwiYiPEXAcBpqo//ciJgYMb/2RMBwH2M/9MnAgZk/O8+EQDcxvjffiJgIMb/4RMBwHXG//4TAQMw/sefCAAS43/siYCOGf/TTwRAbcb/tBMBHTL+558IgJqM/3knAjpi/C8/EQC1GP/LTgR0wPivdyIAajD+65wIaMj4r38iAOZm/Nc9EdCA8d/uRADMyfhvcyJgR8Z/+xMBMBfjv+2JgB0Y//1OBMAcjP8+JwI2ZPz3PxEAYzP++54I2IDxb3ciAMZk/NucCFiR8W9/IgDGYvzbnghYgfHv50QAjMH493Ei4ALGv78TAdA349/XiYAzGP9+TwRAn4x/nycCTmD8+z8RAH0x/n2fCDiC8R/nRAD0wfiPcSLgHsZ/vBMB0JbxH+tEwC2M/7gnAqAN4z/miYBrjP/4JwJgX8Z/7BMBMf4znQiAfRj/Oa50BBj/+U4EwLaM/1xXMgKM/7wnAmAbxn/OKxUBxn/+EwGwLuM/95WIAONf50QArMP417ipI8D41zsRAJcx/rVuyggw/nVPBMB5jH/NmyoCjL8TAXAa41/7pogA4++WEwFwHOPvXs7gEWD83c0TAXA/4++u35ARYPzdXScC4HbG3912Q0WA8XcPnQiApxl/d98NEQHG3x17IgAOjL875rqOAOPvTj0RQHXG351yXUaA8XfnngigKuPvzrmuIsD4u0tPBFCN8XeXXBcRYPzdWicCqML4uzXu4gi4uuC/+3ySf5Hkz17yAPCKb0zy2SS/0PpBYEPvi9hlHW965T6Y5KVz/gfODQDjzxZEADMz/qztogg4JwCMP1sSAczI+LOVsyPg1AAw/uxBBDAT48/WzoqAUwLA+LMnEcAMjD97OTkCjg0A408LIoCRGX/2dlIEHBMAxp+WRAAjMv60cnQEPBQAxp8eiABGYvxp7agIuC8AjD89EQGMwPjTiwcj4K4AMP70SATQM+NPb+6NgNsCwPjTMxFAj4w/vbozAm4GwGte+Q990z7PBWcRAfTE+NO7NyV5Q5KfuP6LNwPg7yd5115PBBcQAfTA+DOKr0ryXJKfXX7hegC8I8kP7f1EcAERQEvGn9G8NcnPJflE8iQAXkjyU0n+YJtngrOJAFow/ozoUZKvT/IjSV5aAuBvJXlns0eCy4gA9mT8GdkfzuEdgP90lUMR/OMkX9TyieBCIoA9GH9m8BVJfvhRkj+dw+cEYAbvTfL+1g/BlIw/M/kTV0m+I4cIgBl4J4AtGH9m81tXSb43yZe3fhJYkQhgTcafGX3qKsn3xVf/Mx8RwBqMP7N66SqHD/DXtH4S2IAI4BLGn6k9TvLa1g8BG/Iizjl83DC71z1O8pnWTwEb82LOKXy8UMFnrpJ8a5I/1PpJYGM+HcAxjD9VfOwqhx/7+4bWTwI7EAHcx/hTyc9eJXl9Di+MUIEI4DbGn2p++FGSNyb5aOsngZ35joEsjD/VvJzk9Y+T/FqSFxs/DOzNiz6JjwNq+nCSTy4/DfD3k/ylhg8DLfh0QG3Gn6r+ZpKPLwHw0SR/LsmXtXseaEIE1GT8qepDSf5uklxd+8X/kMNfCby65b8AMxMBtRh/qvpUkrcn+Z/J02P/35P8jyTf0uChoDURUIPxp6qXk/z1JD+//MLNP+2/mOR18eOBqUkEzM34U9n3JPmH13/htrf7P5zkC5O8eY8ngs6IgDkZfyp7T5IfvPmLd32+/2ciAqhLBMzF+FPZe5L8vdv+xX1f8CcCqEwEzMH4U9md4588/BX/IoDKRMDYjD+V3Tv+yXF/5U8EUJkIGJPxp7IHxz85/u/8iwAqEwFjMf5UdtT4J6d90x8RQGUiYAzGn8qOHv/k9O/6JwKoTAT0zfhT2Unjn5z3bX9FAJWJgD4Zfyo7efyT87/vvwigMhHQF+NPZWeNf3LZD/4RAVQmAvpg/Kns7PFPLv/JfyKAykRAW8afyi4a/2SdH/0rAqhMBLRh/Kns4vFP1gmARARQmwjYl/GnslXGP1kvABIRQG0iYB/Gn8pWG/9k3QBIRAC1iYBtGX8qW3X8k/UDIBEB1CYCtmH8qWz18U+2CYBEBFCbCFiX8aeyTcY/2S4AEhFAbSJgHcafyjYb/2TbAEhEALWJgMsYfyrbdPyT7QMgEQHUJgLOY/ypbPPxT/YJgEQEUJsIOI3xp7Jdxj/ZLwASEUBtIuA4xp/Kdhv/ZN8ASEQAtYmA+xl/Ktt1/JP9AyARAdQmAm5n/Kls9/FP2gRAIgKoTQQ8zfhTWZPxT9oFQCICqE0EHBh/Kms2/knbAEhEALVVjwDjT2VNxz9pHwCJCKC2qhFg/Kms+fgnfQRAIgKorVoEGH8q62L8k34CIBEB1FYlAow/lXUz/klfAZCIAGqbPQKMP5V1Nf5JfwGQiABqmzUCjD+VdTf+SZ8BkIgAapstAow/lXU5/km/AZCIAGqbJQKMP5V1O/5J3wGQiABqGz0CjD+VdT3+Sf8BkIgAahs1Aow/lXU//skYAZCIAGobLQKMP5UNMf7JOAGQHCLgDyR5S+sHgQZGiQDjT2V/J8kHWj/EsUYKgEQEUFvvEWD8qWyo8U/GC4BEBFBbrxFg/KlsuPFPxgyARARQW28RYPypbMjxT8YNgEQEUFsvEWD8qWzY8U/GDoBEBFBb6wgw/lQ29Pgn4wdAIgKorVUEGH8qG378kzkCIBEB1LZ3BBh/Kpti/JN5AiARAdS2VwQYfyqbZvyTuQIgEQHUtnUEGH8qm2r8k/kCIBEB1LZVBBh/Kptu/JM5AyARAdS2dgQYfyqbcvyTeQMgEQHUtlYEGH8qm3b8k7kDIBEB1HZpBBh/Kpt6/JP5AyARAdR2bgQYfyqbfvyTGgGQiABqOzUCjD+VlRj/pE4AJCKA2o6NAONPZWXGP6kVAIkIoLaHIsD4U1mp8U/qBUAiAqjtrggw/lRWbvyTmgGQiABquxkBxp/KSo5/UjcAEhFAbUsE/PkYf+oqO/5J8qj1A3TgA0ne3fohANhV6fFPar8DsPBOAEAt5cc/EQALEQBQg/F/hQB4QgQAzM34XyMAniYCAOZk/G8QAM8SAQBzMf63EAC3EwEAczD+dxAAdxMBAGMz/vcQAPcTAQBjMv4PEAAPEwEAYzH+RxAAxxEBAGMw/kcSAMcTAQB9M/4nEACnEQEAfTL+JxIApxMBAH0x/mcQAOcRAQB9MP5nEgDnEwEAbRn/CwiAy4gAgDaM/4UEwOVEAMC+jP8KBMA6fibJCxEBAFv7niQ/2PohZiAA1vOhiACALRn/FQmAdYkAgG0Y/5UJgPWJAIB1Gf8NCIBtiACAdRj/jQiA7YgAgMsY/w0JgG2JAIDzGP+NCYDtiQCA0xj/HQiAfYgAgOMY/50IgP2IAID7Gf8dCYB9iQCA2xn/nQmA/YkAgKcZ/wYEQBsiAODA+DciANoRAUB1xr8hAdCWCACqMv6NCYD2RABQjfHvgADogwgAqjD+nRAA/RABwOyMf0cEQF9EADAr498ZAdAfEQDMxvh3SAD0SQQAszD+nRIA/RIBwOiMf8cEQN9EADAq4985AdA/EQCMxvgPQACMQQQAozD+gxAA4xABQO+M/0AEwFhEANAr4z8YATAeEQD0xvgPSACMSQQAvTD+gxIA4xIBQGvGf2ACYGwiAGjF+A9OAIxPBAB7M/4TEABzEAHAXoz/JATAPEQAsDXjPxEBMBcRAGzF+E9GAMxHBABrM/4TEgBzEgHAWoz/pATAvEQAcCnjPzEBMDcRAJzL+E9OAMzvQ0meT/LW1g8CDOPdSX6o9UOwLQFQgwgAjmX8ixAAdYgA4CHGvxABUIsIAO5i/IsRAPWIAOAm41+QAKhJBAAL41+UAKhLBADGvzABUJsIgLqMf3ECABEA9Rh/BABJRABUYvxJIgB4QgTA/Iw/rxIAXCcCYF7Gn6cIAG4SATAf488zBAC3EQEwD+PPrQQAdxEBMD7jz50EAPcRATAu48+9BAAPEQEwHuPPgwQAxxABMA7jz1EEAMcSAdA/48/RBACnEAHQL+PPSQQApxIB0B/jz8kEAOcQAdAP489ZBADnEgHQnvHnbAKAS4gAaMf4cxEBwKVEAOzP+HMxAcAaRADsx/izCgHAWkQAbM/4sxoBwJpEAGzH+LMqAcDaRACsz/izOgHAFkQArMf4swkBwFZEAFzO+LMZAcCWRACcz/izKQHA1kQAnM74szkBwB5EABzP+LMLAcBeRAA8zPizGwHAnkQA3M34sysBwN5EADzL+LM7AUALIgCeMP40IQBo5UNJviAigNqMP808bv0AAMD+vANAK+9L8p7WDwGNvS3Jp5P8YusHoR4BQAvGH54QATQhANib8YdniQB2JwDYk/GHu4kAdiUA2Ivxh4eJAHYjANiD8YfjiQB2IQDYmvGH04kANicA2JLxh/OJADYlANiK8YfLiQA2IwDYgvGH9YgANiEAWJvxh/WJAFYnAFiT8YftiABWJQBYi/GH7YkAViMAWIPxh/2IAFYhALiU8Yf9iQAuJgC4hPGHdkQAFxEAnMv4Q3sigLMJAM5h/KEfIoCzCABOZfyhPyKAkwkATmH8oV8igJMIAI5l/KF/IoCjCQCOYfxhHCKAowgAHmL8YTwigAcJAO5j/GFcIoB7CQDuYvxhfCKAOwkAbmP8YR4igFsJAG4y/jAfEcAzBADXGX+YlwjgKQKAhfGH+YkAXiUASIw/VCICSCIAMP5QkQhAABRn/KEuEVCcAKjL+AMioDABUJPxBxYioCgBUI/xB24SAQUJgFqMP3AXEVCMAKjD+AMPEQGFCIAajD9wLBFQhACYn/EHTiUCChAAczP+wLlEwOQEwLyMP3ApETAxATAn4w+sRQRMSgDMx/gDaxMBExIAczH+wFZEwGQEwDyMP7A1ETARATAH4w/sRQRMQgCMz/gDexMBExAAYzP+QCsiYHACYFzGH2hNBAxMAIzJ+AO9EAGDEgDjMf5Ab0TAgATAWIw/0CsRMBgBMA7jD/ROBAxEAIzB+AOjEAGDEAD9M/7AaETAAARA34w/MCoR0DkB0C/jD4xOBHRMAPTJ+AOzEAGdEgD9Mf7AbERAhwRAX4w/MCsR0BkB0A/jD8xOBHREAPTB+ANViIBOCID2jD9QjQjogABoy/gDVYmAxgRAO8YfqE4ENCQA2jD+AAcioBEBsD/jD/A0EdCAANiX8Qe4nQjYmQDYj/EHuJ8I2JEA2IfxBziOCNiJANie8Qc4jQjYgQDYlvEHOI8I2JgA2I7xB7iMCNiQANiG8QdYhwjYiABYn/EHWJcI2IAAWJfxB9iGCFiZAFiP8QfYlghYkQBYh/EH2IcIWIkAuJzxB9iXCFiBALiM8QdoQwRcSACcz/gDtCUCLiAAzmP8AfogAs4kAE5n/AH6IgLOIABOY/wB+iQCTiQAjmf8AfomAk4gAI5j/AHGIAKOJAAeZvwBxiICjiAA7mf8AcYkAh4gAO5m/AHGJgLuIQBuZ/wB5iAC7iAAnmX8AeYiAm4hAJ5m/AHmJAJuEABPGH+AuYmAawTAgfEHqEEEvEIAGH+AakRABIDxp7L3JnkxyVtbPwg0UD4CKgeA8aey9yZ5f5IPJ/mCiABqKh0BVQPA+FPZMv4LEUBlZSOgYgAYfyq7Of4LEUBlJSOgWgAYfyq7a/wXIoDKykVApQAw/lT20PgvRACVlYqAKgFg/Kns2PFfiAAqKxMBFQLA+FPZqeO/EAFUViICZg8A409l547/QgRQ2fQRMHMAGH8qu3T8FyKAyqaOgFkDwPhT2VrjvxABVDZtBMwYAMafytYe/4UIoLIpI2C2ADD+VLbV+C9EAJVNFwEzBYDxp7Ktx38hAqhsqgiYJQCMP5XtNf4LEUBl00TADAFg/Kls7/FfiAAqmyICRg8A409lrcZ/IQKobPgIGDkAjD+VtR7/hQigsqEjYNQAMP5U1sv4L0QAlQ0bASMGgPGnst7GfyECqGzICBgtAIw/lfU6/gsRQGXDRcBIAWD8qaz38V+IACobKgJGCQDjT2WjjP9CBFDZMBEwQgAYfyobbfwXIoDKhoiA3gPA+FPZqOO/EAFU1n0E9BwAxp/KRh//hQigsq4joNcAMP5UNsv4L0QAlXUbAT0GgPGnstnGfyECqKzLCOgtAIw/lc06/gsRQGXdRUBPAWD8qWz28V+IACrrKgJ6CQDjT2VVxn8hAqismwjoIQCMP5VVG/+FCKCyLiKgdQAYfyqrOv4LEUBlzSOgZQAYfyqrPv4LEUBlTSOgVQAYfyoz/k8TAVTWLAJaBIDxpzLjfzsRQGVNImDvADD+VGb87ycCqGz3CNgzAIw/lRn/44gAKts1AvYKAONPZcb/NCKAynaLgD0CwPhTmfE/jwigsl0iYOsAMP5UZvwvIwKobPMI2DIAjD+VGf91iAAq2zQCtgoA409lxn9dIoDKNouALQLA+FOZ8d+GCKCyTSJg7QAw/lRm/LclAqhs9QhYMwCMP5UZ/32IACpbNQLWCgDjT2XGf18igMpWi4A1AsD4U5nxb0MEUNkqEXBpABh/KjP+bYkAKrs4Ai4JAONPZca/DyKAyi6KgHMDwPhTmfHviwigsrMj4JwAMP5UZvz7JAKo7KwIODUAjD+VGf++iQAqOzkCTgkA409lxn8MIoDKToqAYwPA+FOZ8R+LCKCyoyPgmAAw/lRm/MckAqjsqAh4KACMP5UZ/7GJACp7MALuCwDjT2XGfw4igMrujYC7AsD4U5nxn4sIoLI7I+C2APiBHF4AoSLjPycRQGVvS/L7ST5y/RdvBsB35vCnf6jI+M9NBFDZ25J89JVLkjy69i//VA518NzODwU9MP51+BQnVX0qyZ9M8vHkyTsAj5P8yyRf1uihoCXjX4t3AqjqtUnemOTHkicB8FdzePsfqjH+NYkAqvqKHL4g8L8sAfCjSb602eNAG8a/NhFAVV+S5MceJfmaJL/c+GFgb8afha8JoJqXk7z+Ksm3JfkzjR8G9mT8uc47AVTzKMnHrnJ4MfzKxg8DezH+3EYEUM3/ukry/Um+qPWTwA6MP/cRAVTyf6+SfCDH/1hgGJXx5xgigCoeP8rhiwFgZsafU/nCQGb3vx8nean1U8CGjD/n8HHD7D73OMnvtX4K2IgXcS7h44eZ/c5Vkr+Q5I+2fhJYmRdv1uBrApjVv7tK8qYkb279JLAi48+aRAAz+tGrHL4G4K+1fhJYifFnCyKA2XzXoxz+CuBvxU8CZHzGn6352wHM4FeSfPVVDn8N8HVJvqHt88BFjD978E4AM/jeJP/x0Sv/8IVJ/nOSP9LueeBsxp+9eSeAUX0syVcl+fzyHQA/l+S/JXlns0eC8xh/WvBOACN6OclfTvLx5OlvAfyrSV6f5GsbPBScw/jTkghgNO9P8o+Wf7j5MwD+dZKvT/LH9nwiOIPxpwcigFH8eJLvzLVv/38zAP5fkn+eQwR8+X7PBScx/vREBNC7DyZ5Vw4b/6rbfgrg55P8s4gA+mT86ZEIoFcfzOHz/p+/+S/u+jHAIoAeGX96JgLozZ3jf4wXcvigftm5xuevXDGK96X9/1+c+4kkz+VCIsC1PuPPaESAa3mrjP9CBLhWZ/wZlQhwLW7V8V+IALf3GX9GJwLcnrfJ+C9EgNvrjD+zEAFuj9t0/BciwG19xp/ZiAC35e0y/gsR4LY648+sRIDb4nYd/4UIcGuf8Wd2IsCteU3GfyEC3Fpn/KlCBLg1run4L0SAu/SMP9WIAHfJdTH+CxHgzj3jT1UiwJ1zXY3/QgS4U8/4U50IcKdcl+O/EAHu2DP+cCAC3DHX9fgvRIB76Iw/PE0EuPtuiPFfiAB31xl/uJ0IcLfdUOO/EAHu5hl/uJ8IcNdvyPFfiAC3nPGH44gA93IGH/+FCHDGH04jAmrfFOO/EAF1z/jDeURAzZtq/BcioN4Zf7iMCKh1U47/QgTUOeMP6xABNW7q8V+IgPnP+MO6RMDcV2L8FyJg3jP+sA0RMOeVGv+FCJjvjD9sSwTMdSXHfyEC5jnjD/sQAXNc6fFfiIDxz/jDvkTA2Gf8rxEB457xhzZEwJhn/G8hAsY74w9tiYCxzvjfQwSMc8Yf+iACxjjjfwQR0P8Zf+iLCOj7jP8JREC/Z/yhTyKgzzP+ZxAB/Z3xh76JgL7O+F9ABPRzxh/GIAL6OOO/AhHQ/ow/jEUEtD3jvyIR0O6MP4xJBLQ5478BEbD/GX8YmwjY94z/hkTAfmf8YQ4iYJ8z/jsQAduf8Ye5iIBtz/jvSARsd8Yf5iQCtjnj34AIWP+MP8xNBKx7xr8hEbDeGX+oQQSsc8a/AyLg8jP+UIsIuOyMf0dEwPln/KEmEXDeGf8OiYDTz/hDbSLgtDP+HRMBx5/xBxIRcOwZ/wGIgIfP+APXiYD7z/gPRATcfcYfuI0IuP2M/4BEwLNn/IH7iICnz/gPTAQ8OeMPHEMEHM74T0AEGH/gNNUjwPhPpHIEGH/gHFUjwPhPqGIEGH/gEtUiwPhPrFIEGH9gDVUiwPgXUCECjD+wptkjwPgXMnMEGH9gC7NGgPEvaMYIMP7AlmaLAONf2EwRYPyBPcwSAcafKSLA+AN7Gj0CjD+vGjkCjD/QwqgRYPx5xogRYPyBlkaLAOPPnUaKAOMP9GCUCDD+PGiECDD+QE96jwDjz9F6jgDjD/So1wgw/pysxwgw/kDPeosA48/ZeooA4w+MoJcIMP5crIcIMP7ASFpHgPFnNS0jwPgDI2oVAcaf1bWIAOMPjGzvCDD+bGbPCDD+wAz2igDjz+b2iADjD8xk6wgw/uzmhSQ/nW0+kL97x98HwF6+L9u8Zv54jD87ey7Jj2S9D+JPJfkru/4OAPb1N5L8n6zzmvlSDu8sPN71dwDXvCPJJ3PZB/KHk3zl3g8O0MBXJ/mlXPaa+ZtJvnHvB4fbPJ/kbyf5rzntg/jfJPnmBs8L0NKjJH8xp4fAryf59njLfxWPWj/AZB4leXOSb0rydTn8qf6Lk7w2yaeT/HaSX03yC0l+MsknmjwlQD/ekOTtSd6S5I1JvjSHr7P6bJLfTfIbST6S5KeSvNjoGaf0/wE8gXg04DDbWgAAAABJRU5ErkJggg=="
                                    })
                                }), Object(s.jsxs)("div", {
                                    className: "center",
                                    id: "chatting",
                                    style: {
                                        display: this.state.loading ? "none" : "block"
                                    },
                                    children: [Object(s.jsx)("img", {
                                        className: "profilepic",
                                        src: Gi[this.person]
                                    }), Object(s.jsx)("p", {
                                        className: "name",
                                        children: this.t("FB_SH01_" + this.person)
                                    }), Object(s.jsx)("p", {
                                        id: "chatbox"
                                    }), Object(s.jsx)("div", {
                                        id: "buttons",
                                        children: Object(s.jsx)("button", {
                                            id: "b1",
                                            className: "button",
                                            onClick: this.next,
                                            children: this.state.answer
                                        })
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Mi = Object(p.a)(["games"])(Object(A.h)(Yi)),
                Hi = (i(564), i.p + "static/media/call.4d5d73fe.gif"),
                Ji = i.p + "static/media/superhero.ba378799.jpg",
                Di = i.p + "static/media/criminal1.95877373.jpg",
                Vi = i.p + "static/media/criminal2.70dff0e0.jpg",
                Ki = i.p + "static/media/criminal3.d623ce8d.jpg",
                zi = i.p + "static/media/criminal4.a541291d.jpg",
                Ti = i.p + "static/media/criminal5.aca7bb96.jpg",
                Ui = i.p + "static/media/criminal6.9791fea8.jpg",
                Xi = i.p + "static/media/criminal7.16ad6e32.jpg",
                Pi = i.p + "static/media/criminal8.70807d73.jpg",
                Wi = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            opacity: [1, 1, 1, 1, 1, 1, 1, 1],
                            modal1: !1,
                            modal2: !1,
                            text: ""
                        }, s.setSuspect = s.setSuspect.bind(Object(ve.a)(s)), s.send = s.send.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "setSuspect",
                        value: function(e) {
                            var t = [.5, .5, .5, .5, .5, .5, .5, .5];
                            t[e] = 1, this.setState({
                                opacity: t
                            })
                        }
                    }, {
                        key: "send",
                        value: function() {
                            var e = this;
                            this.setState({
                                modal1: !0,
                                text: "Gegevens van dader verzenden..."
                            }), setTimeout((function() {
                                e.setState({
                                    modal1: !0,
                                    text: "Robotfoto verzenden..."
                                })
                            }), 2e3), setTimeout((function() {
                                e.setState({
                                    modal1: !0,
                                    text: "Politie waarschuwen..."
                                })
                            }), 4e3), setTimeout((function() {
                                e.setState({
                                    modal1: !1,
                                    modal2: !0
                                })
                            }), 6e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                className: "Hero_Suspects",
                                children: [Object(s.jsxs)(Rt.a, {
                                    visible: this.state.modal1,
                                    title: "Dader Aangeven",
                                    footer: [],
                                    children: [Object(s.jsx)("img", {
                                        src: Hi,
                                        style: {
                                            width: 300,
                                            marginLeft: 100
                                        }
                                    }), Object(s.jsx)("p", {
                                        id: "title",
                                        style: {
                                            width: "100%",
                                            textAlign: "center",
                                            fontSize: "23px"
                                        },
                                        children: this.state.text
                                    })]
                                }), Object(s.jsxs)(Rt.a, {
                                    visible: this.state.modal2,
                                    title: "Gelukt!",
                                    footer: [Object(s.jsx)(M.a, {
                                        onClick: function() {
                                            return window.location.href = "panel"
                                        },
                                        children: "Open Bedieningspaneel"
                                    })],
                                    children: [Object(s.jsx)("img", {
                                        src: Ji,
                                        style: {
                                            width: 250,
                                            marginLeft: 125
                                        }
                                    }), Object(s.jsxs)("p", {
                                        id: "title",
                                        style: {
                                            width: "100%",
                                            textAlign: "center",
                                            fontSize: "17px"
                                        },
                                        children: ["De dader is doorgegeven aan de politie.", Object(s.jsx)("br", {}), "Jullie hebben een pauze verdiend!", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Om de volledige zaak op te lossen, vinden jullie best ook de locatie van de buit."]
                                    })]
                                }), Object(s.jsx)("h1", {
                                    children: "Overzicht van alle daders"
                                }), Object(s.jsxs)("div", {
                                    class: "container",
                                    children: [Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "1",
                                            src: Di,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(0)
                                            },
                                            style: {
                                                opacity: this.state.opacity[0]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "2",
                                            src: Vi,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(1)
                                            },
                                            style: {
                                                opacity: this.state.opacity[1]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "3",
                                            src: Ki,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(2)
                                            },
                                            style: {
                                                opacity: this.state.opacity[2]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "4",
                                            src: zi,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(3)
                                            },
                                            style: {
                                                opacity: this.state.opacity[3]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "5",
                                            src: Ti,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(4)
                                            },
                                            style: {
                                                opacity: this.state.opacity[4]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "6",
                                            src: Ui,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(5)
                                            },
                                            style: {
                                                opacity: this.state.opacity[5]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "7",
                                            src: Xi,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(6)
                                            },
                                            style: {
                                                opacity: this.state.opacity[6]
                                            }
                                        })
                                    }), Object(s.jsx)("div", {
                                        class: "tilt",
                                        children: Object(s.jsx)("img", {
                                            id: "8",
                                            src: Pi,
                                            className: "profilepic",
                                            onClick: function() {
                                                return e.setSuspect(7)
                                            },
                                            style: {
                                                opacity: this.state.opacity[7]
                                            }
                                        })
                                    }), Object(s.jsx)("button", {
                                        className: "getuigen_knop",
                                        type: "button",
                                        onClick: function() {
                                            return window.location.href = "witness"
                                        },
                                        children: "Terug naar de getuigen"
                                    }), Object(s.jsx)("button", {
                                        className: "knop_daders",
                                        type: "button",
                                        onClick: this.send,
                                        children: "Dader doorgeven aan politie"
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Zi = i(94),
                qi = (i(250), i.p + "static/media/car.e536f8bd.gif"),
                _i = i.p + "static/media/call.03922b7a.png",
                $i = i.p + "static/media/sent.23a7e611.png",
                es = i.p + "static/media/politie.52b29b62.mp3",
                ts = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            route: {
                                r1: !0,
                                r2: !0,
                                r3: !0,
                                r4: !0,
                                r5: !0,
                                r6: !0
                            },
                            location: {
                                lat: -25,
                                lng: 131
                            }
                        }, s.move_location = s.move_location.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this,
                                t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user"));
                            console.log(t), fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "GET",
                                headers: {
                                    Authorization: "Bearer " + i.token
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                e.setState({
                                    loaded: t
                                }), console.log(t)
                            }))
                        }
                    }, {
                        key: "move_location",
                        value: function() {
                            if ("B69A" != document.getElementById("code").value) return document.getElementById("location_text").innerHTML = "Foutieve code", document.getElementById("location_text").style.color = "red", !1;
                            document.getElementById("location_text").innerHTML = "Locatie gevonden.", document.getElementById("location_text").style.color = "black", this.setState({
                                location: this.state.loaded
                            })
                        }
                    }, {
                        key: "call",
                        value: function() {
                            var e = document.getElementById("audio");
                            document.getElementById("telephone").src = Hi, e.play()
                        }
                    }, {
                        key: "quitcall",
                        value: function() {
                            document.getElementById("call").style.display = "none", document.getElementById("telephone").src = _i;
                            var e = document.getElementById("audio");
                            e.pause(), e.currentTime = 0
                        }
                    }, {
                        key: "fotos",
                        value: function() {
                            document.getElementById("fotos").style.display = "block";
                            var e = document.getElementById("foto_text");
                            setTimeout((function() {
                                e.innerHTML = "Foto's verzamelen van vluchtroute..."
                            }), 3e3), setTimeout((function() {
                                e.innerHTML = "Foto's afdrukken en opsturen..."
                            }), 7e3), setTimeout((function() {
                                e.innerHTML = "De foto's zijn afgedrukt en verstuurd. Ze zouden zich moeten bevinden in de postbus van jullie hoofdkwartier.", document.getElementById("loading_foto").src = $i, document.getElementById("backlink").style.display = "block"
                            }), 1e4)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(s.jsxs)("div", {
                                className: "Hero_Panel",
                                style: {
                                    position: "absolute"
                                },
                                children: [Object(s.jsx)("audio", {
                                    id: "audio",
                                    src: es
                                }), Object(s.jsxs)("form", {
                                    style: {
                                        marginTop: "10%"
                                    },
                                    children: [Object(s.jsx)("input", {
                                        className: "knop",
                                        type: "button",
                                        value: "Vluchtroute bekijken",
                                        onClick: function() {
                                            return document.getElementById("route").style.display = "block"
                                        }
                                    }), Object(s.jsx)("input", {
                                        className: "knop",
                                        type: "button",
                                        value: "Politie bellen",
                                        onClick: function() {
                                            return document.getElementById("call").style.display = "block"
                                        }
                                    }), Object(s.jsx)("input", {
                                        className: "knop",
                                        type: "button",
                                        value: "Locatie traceren",
                                        onClick: function() {
                                            return document.getElementById("form").style.display = "block"
                                        }
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "form",
                                    className: "modal",
                                    children: Object(s.jsxs)("form", {
                                        className: "modal-content animate",
                                        children: [Object(s.jsxs)("div", {
                                            className: "imgcontainer",
                                            style: {
                                                height: "100%"
                                            },
                                            children: [Object(s.jsx)("span", {
                                                onClick: function() {
                                                    return document.getElementById("form").style.display = "none"
                                                },
                                                className: "close",
                                                title: "Close Modal",
                                                children: "\xd7"
                                            }), Object(s.jsx)(Zi.Map, {
                                                id: "map",
                                                google: this.props.google,
                                                zoom: 13,
                                                style: {
                                                    width: "70%",
                                                    height: 300,
                                                    marginLeft: "15%"
                                                },
                                                defaultCenter: this.state.location,
                                                center: this.state.location,
                                                children: Object(s.jsx)(Zi.Marker, {
                                                    position: this.state.location,
                                                    text: ""
                                                })
                                            })]
                                        }), Object(s.jsxs)("div", {
                                            class: "container",
                                            style: {
                                                marginTop: "300px"
                                            },
                                            children: [Object(s.jsx)("p", {
                                                id: "location_text",
                                                children: "Voer een locatie code in om deze te ontcijferen."
                                            }), Object(s.jsx)("input", {
                                                type: "text",
                                                id: "code",
                                                placeholder: "Locatie Code",
                                                name: "code",
                                                required: !0
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                onClick: this.move_location,
                                                children: "Vind Locatie"
                                            })]
                                        })]
                                    })
                                }), Object(s.jsx)("div", {
                                    id: "route",
                                    className: "modal",
                                    children: Object(s.jsxs)("form", {
                                        className: "modal-content animate",
                                        style: {
                                            width: "300px"
                                        },
                                        children: [Object(s.jsx)("div", {
                                            className: "imgcontainer",
                                            children: Object(s.jsx)("span", {
                                                onClick: function() {
                                                    return document.getElementById("route").style.display = "none"
                                                },
                                                className: "close",
                                                title: "Close Modal",
                                                children: "\xd7"
                                            })
                                        }), Object(s.jsxs)("div", {
                                            className: "container",
                                            children: [Object(s.jsxs)("div", {
                                                className: "centerbuttons",
                                                children: [Object(s.jsxs)("label", {
                                                    className: "labelcontainer",
                                                    children: ["Route A1", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r1,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                }), Object(s.jsxs)("label", {
                                                    className: "labelcontainer",
                                                    children: ["Route B2", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r2,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                }), Object(s.jsxs)("label", {
                                                    className: "labelcontainer",
                                                    children: ["Route C3", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r3,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                }), Object(s.jsxs)("label", {
                                                    className: "labelcontainer",
                                                    children: ["Route D4", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r4,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                }), Object(s.jsxs)("label", {
                                                    className: "labelcontainer",
                                                    children: ["Route E5", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r5,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                }), Object(s.jsxs)("label", {
                                                    class: "labelcontainer",
                                                    children: ["Route F6", Object(s.jsx)("input", {
                                                        type: "radio",
                                                        value: this.state.route.r6,
                                                        name: "radio"
                                                    }), Object(s.jsx)("span", {
                                                        className: "checkmark"
                                                    })]
                                                })]
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                onClick: this.fotos,
                                                children: "Camerabeelden Opvragen"
                                            })]
                                        })]
                                    })
                                }), Object(s.jsx)("div", {
                                    id: "fotos",
                                    class: "modal",
                                    style: {
                                        paddingTop: "10%"
                                    },
                                    children: Object(s.jsxs)("form", {
                                        class: "modal-content animate",
                                        style: {
                                            width: "500px",
                                            height: "300px"
                                        },
                                        children: [Object(s.jsx)("div", {
                                            class: "imgcontainer",
                                            children: Object(s.jsx)("img", {
                                                src: qi,
                                                alt: "Avatar",
                                                id: "loading_foto",
                                                class: "avatar"
                                            })
                                        }), Object(s.jsx)("p", {
                                            id: "foto_text",
                                            children: "Downloaden van de beelden..."
                                        }), Object(s.jsx)("p", {
                                            style: {
                                                textAlign: "center",
                                                display: "none",
                                                fontSize: "13px"
                                            },
                                            id: "backlink",
                                            children: Object(s.jsx)("a", {
                                                onClick: function() {
                                                    document.getElementById("fotos").style.display = "none", document.getElementById("route").style.display = "none"
                                                },
                                                children: "TERUG"
                                            })
                                        })]
                                    })
                                }), Object(s.jsx)("div", {
                                    id: "call",
                                    class: "modal",
                                    style: {
                                        paddingTop: "10%"
                                    },
                                    children: Object(s.jsx)("form", {
                                        class: "modal-content animate",
                                        style: {
                                            width: "400px",
                                            height: "300px"
                                        },
                                        children: Object(s.jsxs)("div", {
                                            class: "imgcontainer",
                                            children: [Object(s.jsx)("span", {
                                                class: "close",
                                                title: "Close Modal",
                                                onClick: this.quitcall,
                                                children: "\xd7"
                                            }), Object(s.jsx)("img", {
                                                src: _i,
                                                alt: "Avatar",
                                                id: "telephone",
                                                className: "avatar",
                                                onClick: this.call
                                            }), Object(s.jsxs)("p", {
                                                style: {
                                                    fontSize: "13px"
                                                },
                                                children: ["Contacteer de politie wanneer jullie de locatie van een auto willen achterhalen.", Object(s.jsx)("br", {}), " Controleer of het geluid van de computer aanstaat."]
                                            })]
                                        })
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                is = Object(Zi.GoogleApiWrapper)({
                    apiKey: "AIzaSyD1SDzYzeibBlo09ede659H4RPAJXjr5CU"
                })(ts),
                ss = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            location: {
                                lat: -25,
                                lng: 131
                            },
                            lat: "",
                            lng: ""
                        }, s.save = s.save.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this,
                                t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user"));
                            console.log(t), fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "GET",
                                headers: {
                                    Authorization: "Bearer " + i.token
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                t.lat || (t = {
                                    lat: 52.3727598,
                                    lng: 4.8936041
                                }), e.setState({
                                    location: t,
                                    lat: t.lat.toString(),
                                    lng: t.lng.toString()
                                })
                            })).catch((function() {
                                var t = {
                                    lat: 52.3727598,
                                    lng: 4.8936041
                                };
                                e.setState({
                                    location: t,
                                    lat: t.lat.toString(),
                                    lng: t.lng.toString()
                                })
                            }))
                        }
                    }, {
                        key: "save",
                        value: function() {
                            var e = this,
                                t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user")),
                                s = {
                                    lat: this.state.lat,
                                    lng: this.state.lng
                                };
                            console.log(JSON.stringify(s)), fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "POST",
                                headers: {
                                    Authorization: "Bearer " + i.token,
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(s)
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                e.setState({
                                    location: s
                                }), console.log(t)
                            })).catch((function(e) {
                                return console.log(e)
                            }))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                className: "HEROsettings",
                                style: {
                                    width: "100%",
                                    height: "100%"
                                },
                                children: [Object(s.jsxs)("div", {
                                    id: "text",
                                    children: [Object(s.jsx)("h1", {
                                        children: "Locatie van de buit"
                                    }), Object(s.jsxs)("p", {
                                        children: [Object(s.jsx)("b", {
                                            children: "STAP 1:"
                                        }), " Wanneer je een leuke plek hebt ontdekt om de buit te verstoppen, zoek je de exacte coordinaten op via", " ", Object(s.jsx)("a", {
                                            style: {
                                                color: "#ff8400"
                                            },
                                            href: "https://www.gps-coordinaten.nl",
                                            target: "_blank",
                                            children: "deze link."
                                        }), Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), Object(s.jsx)("b", {
                                            children: "STAP 2:"
                                        }), ' Kopieer de coordinaten naar dit scherm, en klik op "opslaan". De locatie van de buit is hier vervolgens zichtbaar. Klaar om het spel te spelen!']
                                    }), Object(s.jsx)(It.a, {
                                        placeholder: "Breedtegraad",
                                        style: {
                                            margin: 10
                                        },
                                        value: this.state.lat,
                                        onChange: function(t) {
                                            return e.setState({
                                                lat: t.target.value
                                            })
                                        }
                                    }), Object(s.jsx)(It.a, {
                                        placeholder: "Lengtegraad",
                                        style: {
                                            margin: 10
                                        },
                                        value: this.state.lng,
                                        onChange: function(t) {
                                            return e.setState({
                                                lng: t.target.value
                                            })
                                        }
                                    }), Object(s.jsx)("a", {
                                        href: "#",
                                        className: "button",
                                        onClick: this.save,
                                        style: {
                                            margin: 10
                                        },
                                        children: "OPSLAAN"
                                    }), Object(s.jsx)("a", {
                                        href: this.props.back,
                                        className: "button",
                                        onclick: "exit()",
                                        style: {
                                            margin: 10
                                        },
                                        children: "TERUG"
                                    })]
                                }), Object(s.jsx)(Zi.Map, {
                                    id: "map",
                                    google: this.props.google,
                                    zoom: 17,
                                    style: {
                                        width: "70%",
                                        height: 300,
                                        marginLeft: "15%"
                                    },
                                    defaultCenter: this.state.location,
                                    center: this.state.location,
                                    children: Object(s.jsx)(Zi.Marker, {
                                        position: this.state.location,
                                        text: ""
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                ns = Object(Zi.GoogleApiWrapper)({
                    apiKey: "AIzaSyD1SDzYzeibBlo09ede659H4RPAJXjr5CU"
                })(ss),
                as = (i(251), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            person: ""
                        }, s.show = s.show.bind(Object(ve.a)(s)), s.chat = s.chat.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            "superman" == document.getElementById("wachtwoord").value && (window.location.href = "welcome")
                        }
                    }, {
                        key: "show",
                        value: function(e, t) {
                            this.props.t;
                            this.setState({
                                person: e
                            }), document.getElementById("avatar").src = t, document.getElementById("form").style.display = "block"
                        }
                    }, {
                        key: "chat",
                        value: function() {
                            var e = this.props.t,
                                t = document.getElementById("password").value;
                            console.log(e("FB_SH01_password_" + this.state.person)), e("FB_SH01_password_" + this.state.person) == t && (window.location.href = "chat?p=" + this.state.person)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Hero_WOverview",
                                children: [Object(s.jsx)("h1", {
                                    children: "Getuigen Contacteren"
                                }), Object(s.jsxs)("div", {
                                    class: "dossiers",
                                    children: [Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("cleaner", Li)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_cleaner")
                                        }), Object(s.jsx)("img", {
                                            src: Li
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("manager", Qi)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_manager")
                                        }), Object(s.jsx)("img", {
                                            src: Qi
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("guard", Fi)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_guard")
                                        }), Object(s.jsx)("img", {
                                            src: Fi
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("taster", Ni)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_taster")
                                        }), Object(s.jsx)("img", {
                                            src: Ni
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("driver", Ri)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_driver")
                                        }), Object(s.jsx)("img", {
                                            src: Ri
                                        })]
                                    }), Object(s.jsx)("form", {
                                        children: Object(s.jsx)("input", {
                                            class: "dader_knop",
                                            type: "button",
                                            onClick: function() {
                                                return window.location.href = "suspects"
                                            },
                                            value: "Robotfoto's bekijken"
                                        })
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "form",
                                    class: "modal",
                                    children: Object(s.jsxs)("form", {
                                        class: "modal-content animate",
                                        children: [Object(s.jsxs)("div", {
                                            class: "imgcontainer",
                                            children: [Object(s.jsx)("span", {
                                                onClick: function() {
                                                    return document.getElementById("form").style.display = "none"
                                                },
                                                class: "close",
                                                title: "Close Modal",
                                                children: "\xd7"
                                            }), Object(s.jsx)("img", {
                                                src: "games/superhelden/imgs/dossier.png",
                                                alt: "Avatar",
                                                class: "avatar",
                                                id: "avatar"
                                            })]
                                        }), Object(s.jsxs)("div", {
                                            class: "container",
                                            children: [Object(s.jsx)("label", {
                                                for: "psw",
                                                id: "dossier",
                                                children: Object(s.jsxs)("b", {
                                                    children: ["Wachtwoord nodig om te praten met de", " ", t("FB_SH01_" + this.state.person)]
                                                })
                                            }), Object(s.jsx)("input", {
                                                type: "text",
                                                id: "password",
                                                placeholder: "Wachtwoord dossier",
                                                name: "psw",
                                                autocomplete: "off",
                                                required: !0
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                onClick: this.chat,
                                                children: "Contacteer Getuige"
                                            })]
                                        })]
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                cs = Object(p.a)(["games"])(as),
                rs = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: yi,
                                escape: !1,
                                settings: !0,
                                next: "access"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: yi,
                                escape: !1,
                                settings: !0,
                                next: "access"
                            }) : "access" == this.props.match.params.phase ? Object(s.jsx)(ki, {
                                next: "welcome"
                            }) : "welcome" == this.props.match.params.phase ? Object(s.jsx)(Bi, {
                                next: "access"
                            }) : "chat" == this.props.match.params.phase ? Object(s.jsx)(Mi, {
                                next: "access"
                            }) : "witness" == this.props.match.params.phase ? Object(s.jsx)(cs, {
                                next: "welcome"
                            }) : "suspects" == this.props.match.params.phase ? Object(s.jsx)(Wi, {
                                next: "welcome"
                            }) : "panel" == this.props.match.params.phase ? Object(s.jsx)(is, {
                                next: ""
                            }) : "testsettings" == this.props.match.params.phase ? Object(s.jsx)(ns, {
                                back: "test"
                            }) : "startsettings" == this.props.match.params.phase ? Object(s.jsx)(ns, {
                                back: "play"
                            }) : Object(s.jsx)(A.a, {
                                to: "/"
                            })
                        }
                    }]), i
                }(a.a.Component),
                os = Object(A.h)(rs),
                ls = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            person: ""
                        }, s.show = s.show.bind(Object(ve.a)(s)), s.chat = s.chat.bind(Object(ve.a)(s)), s
                    }
                    return Object(d.a)(i, [{
                        key: "check",
                        value: function() {
                            "superman" == document.getElementById("wachtwoord").value && (window.location.href = "welcome")
                        }
                    }, {
                        key: "show",
                        value: function(e, t) {
                            this.props.t;
                            this.setState({
                                person: e
                            }), document.getElementById("avatar").src = t, document.getElementById("form").style.display = "block"
                        }
                    }, {
                        key: "chat",
                        value: function() {
                            var e = this.props.t,
                                t = document.getElementById("password").value;
                            console.log(e("FB_SH01_password_" + this.state.person)), e("FB_SH01_password_" + this.state.person) == t && (window.location.href = "chat?p=" + this.state.person)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "Hero_WOverview",
                                children: [Object(s.jsx)("h1", {
                                    children: "Getuigen Contacteren"
                                }), Object(s.jsxs)("div", {
                                    class: "dossiers",
                                    children: [Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("cleaner", Li)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_cleaner")
                                        }), Object(s.jsx)("img", {
                                            src: Li
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("manager", Qi)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_manager")
                                        }), Object(s.jsx)("img", {
                                            src: Qi
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("guard", Fi)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_guard")
                                        }), Object(s.jsx)("img", {
                                            src: Fi
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("taster", Ni)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_taster")
                                        }), Object(s.jsx)("img", {
                                            src: Ni
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        class: "dossier",
                                        onClick: function() {
                                            return e.show("driver2", Ri)
                                        },
                                        children: [Object(s.jsx)("h2", {
                                            children: t("FB_SH01_driver")
                                        }), Object(s.jsx)("img", {
                                            src: Ri
                                        })]
                                    }), Object(s.jsx)("form", {
                                        children: Object(s.jsx)("input", {
                                            class: "dader_knop",
                                            type: "button",
                                            onClick: function() {
                                                return window.location.href = "suspects"
                                            },
                                            value: "Robotfoto's bekijken"
                                        })
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "form",
                                    class: "modal",
                                    children: Object(s.jsxs)("form", {
                                        class: "modal-content animate",
                                        children: [Object(s.jsxs)("div", {
                                            class: "imgcontainer",
                                            children: [Object(s.jsx)("span", {
                                                onClick: function() {
                                                    return document.getElementById("form").style.display = "none"
                                                },
                                                class: "close",
                                                title: "Close Modal",
                                                children: "\xd7"
                                            }), Object(s.jsx)("img", {
                                                src: "games/superhelden/imgs/dossier.png",
                                                alt: "Avatar",
                                                class: "avatar",
                                                id: "avatar"
                                            })]
                                        }), Object(s.jsxs)("div", {
                                            class: "container",
                                            children: [Object(s.jsx)("label", {
                                                for: "psw",
                                                id: "dossier",
                                                children: Object(s.jsxs)("b", {
                                                    children: ["Wachtwoord nodig om te praten met de", " ", t("FB_SH01_" + this.state.person)]
                                                })
                                            }), Object(s.jsx)("input", {
                                                type: "text",
                                                id: "password",
                                                placeholder: "Wachtwoord dossier",
                                                name: "psw",
                                                autocomplete: "off",
                                                required: !0
                                            }), Object(s.jsx)("button", {
                                                type: "button",
                                                onClick: this.chat,
                                                children: "Contacteer Getuige"
                                            })]
                                        })]
                                    })
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                ds = Object(p.a)(["games"])(ls),
                js = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Festiviti Escape Room", z()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: yi,
                                escape: !1,
                                settings: !0,
                                next: "access"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: yi,
                                escape: !1,
                                settings: !0,
                                next: "access"
                            }) : "access" == this.props.match.params.phase ? Object(s.jsx)(ki, {
                                next: "welcome"
                            }) : "welcome" == this.props.match.params.phase ? Object(s.jsx)(Bi, {
                                next: "access"
                            }) : "chat" == this.props.match.params.phase ? Object(s.jsx)(Mi, {
                                next: "access"
                            }) : "witness" == this.props.match.params.phase ? Object(s.jsx)(ds, {
                                next: "welcome"
                            }) : "suspects" == this.props.match.params.phase ? Object(s.jsx)(Wi, {
                                next: "welcome"
                            }) : "panel" == this.props.match.params.phase ? Object(s.jsx)(is, {
                                next: ""
                            }) : "testsettings" == this.props.match.params.phase ? Object(s.jsx)(ns, {
                                back: "test"
                            }) : "startsettings" == this.props.match.params.phase ? Object(s.jsx)(ns, {
                                back: "play"
                            }) : Object(s.jsx)(A.a, {
                                to: "/"
                            })
                        }
                    }]), i
                }(a.a.Component),
                hs = Object(A.h)(js),
                us = i.p + "static/media/background_start.74a88175.jpg",
                bs = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJcAAADJCAYAAAAuG6D+AAAACXBIWXMAAAsSAAALEgHS3X78AAAWCklEQVR4nO2da4xd11XH1z7n3Mc8PJM4TkonJnGo+GClfhDKl1YknkZ8CKhKRkFIQVAMKgVEAdspkRpXiis0RBSwHYSqqh9gqKpGCCI7+RAkqtaOkPIBlWI3cQ00kBi5dmX8mDuv+zx7o7XPPuMzd+55730e9+yfNB7P3HvP2efe/6y19lpr70MYY6DRqMDQ76pGFVpcGmVocWmUocWlUYYWl0YZWlwaZWhxaZShxaVRhhaXRhlaXBplaHFplKHFpVGGFpdGGVpcGmVocWmUocWlUYYWl0YZWlwaZVj6rd3OtXPHDwHAPQBwMOSpFwBgGb/PzS8u5zHWIlP5Hvpr547vAYBDnq+HEx7qihDbefyam1+8IHmopaOS4hKCegYADgPAAUWnQbGdBYClqgqtUuK6du64K6inMz71RQA4jWKrkvushLiunTuOgjqRwuXJoiVEdroKIhtrcYnAfKkAohqmJQR2oljDkstYikvEVCiqJwownCAwLjs8N794vrhDTM7YievaueNHhAucLcBwIkEp+/qt5fbRA8+eul2C4UZmbMRVIms1ktX17kq3b//y/oVT3yrg8BIxFhl6MQu8UFZhIVOT9RnLIP986fVjXynAcKRQest17dxxnH39UQGGkhrKGCyvtNFNvs0Y+VTZ3WRpxXXt3PF7RDZcVRI0FwY2hdZqB0+9AkCe3Ldw8rtlvZZSusVr544fFG5wrISFWKYBO6YawBibAWDfvvzG879dgGElonSWSwjrfNhskJgN/p3RPv6T1fCksdHuw0an51wLMX5n38LJr5XtGkolriBhEbMGhjUJhtUEMIaaPegA6KANdm+tVEJbWetAr2/z/9dq1lf2fuovfj/3QcWgNOISM8KlYWGhhTIbOzYtVRBoxQYbN0sjME+Az38mhLy6b+HUr+Y+sIiUQlxCWGe8vyOGCWbz3kii8sIFtn5D0Ujl0+/b0FrrbB63TAIrfEAvXOGS93dGfQqsyQdiCwu4KGtgNmZkDlEptZoJk8365ikYY8/94I3nF8sw9kKLa1uMRQywJnaC2biH/z8pRm0q3wuLyeREjc8iXQYD+8V3zhz7bNHHXVi3OFJYk7u45QERaxlWnQfvhFjA2IAH7nZvPVJMhbEXs7vKr0MWmP/C+MtL0WeRhRTXcIIUZ4LWxC4uMB7A16cDLBcDu7MMjA4Cz0F7q2B3V1QMXxne9AQ48Rf++3NFTbQW1S2e3SYsDOAbs068FOgSCX/eOILu0TDI5pU5hoF9+4dvvvBTRbzcwolL1Ap5ARpnhCgsYtbBau7k3yMhLFwQkY9VMHZMbr0uzOR3uv03Lr52dGfRxloocYl2ZKcITQwwJ+4DYjXAbMYP4MlwInVMwNljs7H12hhjjxoG/HXRrrAw4hIB/Gn3Zwzejdq0MzMEEvziEaA7DaSEJSGXyYm6iLfugimKS68//0Lug/NQCHGJAH4z+47JUcOa4Jl3VYQF/EXGIAQmGtv/eCilf/bOmWMfK8rQi2K5TrgBPNYGjfq04woTWKyqMBzcw90Af0n8seZO7uISK3R4nOWWdMzmbGphhaYiBuXJcfnhzdy7YPx1a3nj5SKML1dxib+ws+7P3B3Wd/CkaGqoHXgE3opTcjCw92buN6+Nsd/9/pmjv5D31eVtuTbjLKwXYlnGqE1KOXCgeNCqlTig9zI14ZNSYexv8k5P5CYu4Q6dZfWYdqjPgCEtgGeBbpHaPd/HygamJizLHDXq3YYBuRa4cxGXZ3bIwYw6Wiwp7hClFVIzZIN24ONlY6o5Ou2C7jHP2WNeluuIu8Qeg3gUlsxOBToIsEyMAh10/B8vIQHWi88e87qizMUlFq++5P7s5LSaqVpotsBooOUaN2G5TPpbr0fzSq7mYbk2/5LQamENkNQmpB2c9jdCHl+Tdq4iUa+Z2/Jem9dM6fE8gvtMxSWC+M1V0UZ9htcAZcVaGMhT298y4QyS2eVPQfgxKu8ForhtGPD5rMeTteXaYrV4EI8uURKUr+7x70/jj48xmPfys16MsS9cev35j2R59ZmJS3Q8bO6T5QbwRoI++FFgJ2pgPIXLy0Jc5jjQrPsX7Cmlf5LlJWYiLpF6OO39HRameRAvKZCn3dXAx+1e8OPjQrPpH2Jg50SWmfusLNcR73pD3g6DsZbhN32OB1qkoKQpxlpVsFogOiaG+722wFhmuxkqF5ewWke2nNRyZofESN8Nyt1hfz3wOXanlfo8ZaI5oh3Hw8ezsl5ZWK4j21ZJSwvincUYQXCrVqJVPjLAYvaogvYmGVkvpeIaZbVALExNjxBW0OolRsHuVstquRTBeqm2XIdH7e2QnmjLx+zOnbHpfohLvW5ua4X2YhDyUspThKJaXNutlnk32EzWahxxXWJ/Y2xLPVHAwL5R958wUUo/oTrvpUxcw3ktF0LuXjCj8VpfMHgftG+HCgtnh1V1h14ateDKh+q8l0rLtc1qwfCSL8b4vllR4Ptr8RgrxM1hnFVhd+ilFlBvBJH3UrmgVom4RA1x9JaSQ0lTLMmwgOY9fAzFElbaceGWbYzrh3Gph1ivTrf/GVXnVmW5RlotP9CF4b4NaJ2c4nKHi2nQvsUfixqboQirlnYIIzCh6qBst0Lp4hL9WrHvCoaiQEGh67O7q467jOHauHWrSBY+DmE5L+yYULUdkwrLdTjowSAXmBQtrGAaodaL/aGK82YvLskrnbWwwgmbNWK36g/ffOEx2eeVKi6xd2ng7eekxUSM8g3ctLDCwRlj0KwR6fYG0psJZVuuQKsFXBN2aoE5uzLf0MF7DMJmjYyxX5J9TmniihPIp0lw4o6AuBszC1lRrdlK2KxRRWAv03I9E/WJmIfiic4Y4FrDwfqPS7fVZFHAGWNQrdGBRf4MoyBTXKEu0QvGSnb7lrO03g9cY9jf4C7QKftoa5WGoFojONbrKZmrhKQsuxEbt8W+yRMWlvEL1y0ObyOJu9DomEouGHd1usGzddMkmLH/sowTy7JcsazWMCgwdHfeLy0s+VhW+MfNGPu0rBPLEpdUX61RA7bhBHao3l2hLaUVJ7W4hEsMzG1pikNYSgIcgT0rY8AyLFcql6jJllqGrlGGuLRLLBHY4xWGLNeYSlwicapdYsnw327pLpSyJ9NeVVrLpa1WCQkL6h3SJ1S1uCpIPZprfCrtluOJxSVO/ESEp2oKRjTLBXC71U61tjGN5TqU5sSa/MD2m/A6I2chzSDTiEu7xBJjRrBelNKfT3OF2nJVlHqEGSNuN54mJZFIXDoFUX7COlNd0qQkkloubbVKTpQitgNL/FlrcVWUqDNGxljiuEuLq8JEdI2J467Y4hL5LR1vjQGGEe3jNwh8MsnVJrFc2mqNCRFnjDCwaaI1jUnEdTDJiTTlhTG2P8ngteWqMFF6uwQfT/IuaculiUSSW+vFEpcI5mcjPFVTAszolgssk/xM3CuKa7m01RojjGjFa87Apo/EvXItLk0kCCGPx32n4oprj/4oxosoLc/gzBhj5za15dJEgjG2O+47pS2XJjJxN4iLKy5d9qkw7W7/vjhXH1lcYmW1ZsywzOgzRss0YiXQ41iuVCtBNMXEiHEzVdum0ZUYU1w63qo4hJBY22RpcWkiQymN5b2yvju/psQQQmKV/uKISwf0FQc3KInzDuiAXqMM7RYrTm+gbhNjLS5NLOJsTqLFpYlFa60buWkwjrj0jjYa6A/syIlUbbkqjm2ru12zFlfFYRFu7ZwULa4KQxUKC7S4qo09UOcSQYur2qi1W/HElfwmiZpCMiiQ5bqgcByaHBjY8bPzpmH8T9TnardYYSiN7xgfffov/zvqc7W4KsxAYY4LtLiqi2phQUxxnY/8TGLwu7/il6aY9BN0QxBCLsV5vpTbELuYzXvBrE8DMbYelto9YPxusC1gQfe01mRGkrIPYyxWxiCOuD7wfYQYUJv+MBhD96l24b8362A2ZsDurfE782uR5Uuvn8hyxRJXHLfoK67a1Id8hTUMWrb6zE9yK6fJB5wlJpkpxk1HpRaXUd+RKLaymvdAbceD21yoRj1JrBY4lms5zvMji2tufnGkuFAkSUFrhwLTgX+29PrJQhLK2L/HeX7cVMRF7w/ErKe2PMSN1+o7Uh1HE51+wrLPRKMWOYEKCcS1xXoZ1kTMl/tTm9ylBZYB6BKT9HARQlZ++he/HLn0AwnEtSWgkx0vaYGpJ6lLZIy9G/c1ccW1JZFKIs4Q48AFpmMwZXR7iYP578d9TSrLpQpr6kNKhFt1krpEcLZP+l7c18QS19z84vJwUO974NoUWBP3bX6huyNGtP03Mci3Ju/nyVmNPDrdfuJjUQbfifuaJJ9esPXiwtjFs/F8Nim+MHlqTT7AhRZFZJim4ALTSAGTpknzWwBwNU6rzeZnmOBEm3HXqBIOF5VR830xF9rk/dyyhWHWJnWAL4lON3m5jRDyL0lel0RcZ93/DIsLLVKU9AQBwkVoRkjAWhM7dRZfAu0ULhGARO+I8RBbXN64i9ndrUMw483yUIjoQoNiK4y/zIlY+7xqhkCrlWZ9IqXsH5O8LmnEzK3XNreYIABHF2qFFLG5e9TpicRsdHqJX4s9XAeePXU7yWvTiQv7tNjdUkLUzohheBwW4iJ1cJ8MtFoJOyA4hJCvJ31tInHNzS/ijPEK/p8OOknPvXUg1kRgkI9xlw7u45PGaoEjrteSvjZNImkJ/2EecTGaJmgMn2mm6cCoIhjEp7Ral5KkIFxSi4v21zd/IWNTC7Ppv6ertl7RwX0gNtrp/tgByF+leXVicYn+rrcwqMceeZBguUAE+EEC0tYrGiistH/sSWeJLmnrK4716q2J0aQXF/Du1infmSe3XrVJKecZV3DZWJpSDzgu8dWks0SXVOKam19EcbXs3ir/mVEsjKbfwNVNsvqhXWMwa+vdNC8XkJNpjyCjMnwaGOWrekCkJ2SAs0e/GiTmvXTWfjToDiUseH1738LJ76Y9iBxxofXq3OE/0P6GhEM6EMvf/UWpTVYNFFXa1AN/bw3jtIy3LrW4RDloiQf2g45IrMrZ25zHXn6P6bhrCzg7lOMO4epHnzn5DzIOJKthiit903r11sOeHwmMvYhP2YeXg3S/1yYb7Z6U/R8og8/LGpOUT0ekJb6ElgtjLzpoA5O0b11QTVHXGx2wxJOmpcaFAbx98NnTfy9rXDL/9O/GXozKs14BAiJmQ8o5ygxaq/W2nEkUIeSEzLdCmrhE7HUCY69BZ5ln7mWlJfxKQlW3XBhnrax1ZG33/fb+hVPfknEgF6lBy9z8IlqvK3yjEbsHdndFynGJOTrtUOVFHFxYq51UtUMvpml+WtbYXFRExIfxn8HG//GitpSuCeIjrgoH9DgzlLWBGyHk5TQFaj+kfzpz84vYEvsKigrdI9+TS+Gm1FW0Xmsb3TSLLbZAGVxaOHr2i9IG50HVn/4J1z3yGWQ7VYkqkKpZLxSWjJmhi22z33rvg/eV7GGp5JMRwT13j/21647AurF239GMQLaw0B3+7K+88q+q3mtlf/bCPX4J0xJcYP32lt4vTTwUCOvSvoVTL6r8GJT6lLn5RXSPF3Hm2N+4yWePboE7DkF9YlXY/lKBsFYMw3ha2gF9yKK14BBuvUR7q7MoEZ6xYgMwG9Ga/nAywAJmnOMsLjfdIHtbb0LIZ1TMDodRHg2L+AsFBrS3yi0YusjBxs1Inau0u+r/mKTFIUUEBaVIWC/LKkyHkclUS6wW+k3wCszucoFhoO+XyccYLShOk9neUyQwzdBSI6xXVcdZXjKbx4uu1VfAFdjade7SuBVbv+EIDbcRx6/uCgw2boRm+MdxgoDNfhJLOptgAE8pfE7qQcPOqfI2tKO4du44iuw3nLM7WyWZCXqzuADbt9QPOCOwjLOCWfcEd7YIQwjr8bQ98bHPm7W4YFhgovHP2Vop2vwCVxuh5QOm/v41WYBucHW9q+R+04SQq5TCgayFBXmJC7n6nRcxDjtgELL5O1x4gUvHgkSGbpNbrDEQlts9KquUMwymHADIkzL64ZOQ2yqHW3fanzQM+MbMVOOpWs1ZiIGxWK+3yuuFfIGG2Ioc96PAXBk+Pi6pB1wNLWNtoR95CwvytFwu75w5+k3TNJ6bmWqAYZBoLyox/b7Nm/tU3pIurxhr2zjyFhcIgTHGnms2LJhs1sdSZCimtY2ekoDdS1GEBUURFzgC+1PG2Bfw/+MkMrRU3b6cHvcwCCH/RCn8WhGEBUUSF3CBHfssAPtzxhhfbo0ia9QscGOyMsEXTfQGyi2VCyHkq/sWTv1ekd6iQokLHIF9jDF6BgB2u79DCzbRrHGhFdmaOXs0DPhdKmS1H4chAvc/3rdw8muZnDDO2IomLuTia0d3MmDfMAg8NfyYZRrQEBatCEJzBYUWKov7RnvBHBYAWchzRhhEIcXl8u7ZYy/YNv0iITBy5xEUV71mgmkaYBmGcveJeSl7QPldvwa2zb/n9f5hnRDLOUWJr0ZRaHGBcJMAbIkx9miU56NlA0KgbjlCsywDXPtGDOI87kPfk8y0xd1UUVBokSilmbm6INANYstMVp0NaSi8uFxwNkkp+5yfFasChmG8advs14tsrbyURlzI//7b0uMr1987RXtrjxVgOJlhmLU7E7seevEjn/iDr5Zp3IUVV6t1GVtVD4pGw0Pi/3zD1Pbtq3DrB2+B3Y3fMl0mDKsOs488BjMPHfCO+i1x/yX8Oj87u9f3xvZ5UyhxtVqXUUDPiK8DYc9f+9FlWH7/e2MnMhTVjt0fhR0P7QezFrofxhVxXwAU2tmwJ2dJ7uJqtS7vEcvQ8OvhJMdAka1efRd6a6UIRXwxa3WYfjCyqEbREkI7PTu7N5N7YwaRm7iEqE54+7rSgu5y/fp/wvqP38vlmpJSn97JLdX0g3tlHhbd54nZ2b2Jbgolg1zE1WpdRlG9pOr4dr8L69f/A9av/1dhrZnZmIbJ+x+G2Yf3g9n031xYAq+jV5id3Zv5quTMxdVqXV6Saa3CsDsrsH7jfejcvg7dFq7+lrOXVRIasz8BzXvnYPKBR6C+Y1eWp8a7zB3KWmCZiqvVuoxx1d9mdsIR9FZvQufOj2DQXoXe6i3ord0CZsvZP98Lurra9E6wmjPQuPfDMLFzd/QXq+HvZmf3Hs7yhFl3ou7J+HzbQIsxympgvAZ8b4tbQPt3rVtn5Sb2Vm97PlogLygg4Me/P2kwrprM3/usxVXYnIxrWQpgYVRRiZjrQpQclkbu245J6KwTrnlsbnXIXRyryYSLeQgLcs5zHRJ5ridyGcD4c0XkuZbyutIiZOix5HNElHz8b7aoiQrmtZaKUAoqWm3RrSseSloKqiAYT50XZZ+zeSRL/ShyV8SeoY4IPQlwuOJ2RIhide41RD9K1c8l4rSDImdz0NuGM6a8JdI3HwgxXSiSZQqjVOLyQ4gO3E3mPN/3FNi9toQFAvF92fu9TCLyYyzEFQXhZr1Z6kMjXjb8nDgse8Ti5YIngblcZDcmm8qIS5MxAPD/o4pHzoFaSsoAAAAASUVORK5CYII=",
                gs = (i(252), i.p + "static/media/coloregg1.4cee62ae.png"),
                ms = i.p + "static/media/coloregg2.d3a8a903.png",
                ps = i.p + "static/media/coloregg3.aeac0fc1.png",
                xs = i.p + "static/media/coloregg4.84cadf91.png",
                Os = i.p + "static/media/notebook.969ed9f3.png",
                As = (i.p, function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            egg1: !1,
                            egg2: !1,
                            egg3: !1,
                            egg4: !1,
                            egg5: !1,
                            message: !1,
                            code: !1,
                            codeinput: "Code",
                            doce2: !1,
                            codeinput2: "Code"
                        }, s.audio = new Audio(Oe), s
                    }
                    return Object(d.a)(i, [{
                        key: "checkCode",
                        value: function() {
                            "6708" == this.state.codeinput && this.setState({
                                codeinput: "Code",
                                egg4: !0,
                                code: !1
                            })
                        }
                    }, {
                        key: "checkCode2",
                        value: function() {
                            "chocolade!" == this.state.codeinput2.toLowerCase() && this.setState({
                                codeinput2: "Code",
                                egg2: !0,
                                code2: !1
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = {
                                    height: 80,
                                    marginRight: 25
                                },
                                i = !1;
                            return this.state.egg1 && this.state.egg2 && this.state.egg3 && this.state.egg4 && this.state.egg5 && !this.state.message && (i = !0, this.audio.play(), setTimeout((function() {
                                return e.setState({
                                    message: !0
                                })
                            }), 4e3)), Object(s.jsxs)("div", {
                                id: "window",
                                className: "MINI2_Checklist",
                                style: {
                                    fontSize: 23,
                                    backgroundColor: "#FFFFF5",
                                    height: "100%"
                                },
                                children: [Object(s.jsx)(Rt.a, {
                                    title: "Nieuwe helpers gevonden!",
                                    visible: this.state.message,
                                    width: 750,
                                    footer: null,
                                    children: Object(s.jsxs)("p", {
                                        style: {
                                            fontFamily: "Permanent Marker",
                                            fontSize: 20
                                        },
                                        className: "writing",
                                        children: ["WAUW!!", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Ik denk dat ik niet verder moet zoeken naar perfecte helpers!", Object(s.jsx)("br", {}), "k heb nu al een officieel diploma opgestuurd. Vanaf nu mag je dus net als ik paaseieren verstoppen in je huis of tuin. Ga maar snel kijken in de brievenbus, ik heb er nog een verrassing bij gestopt!", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), " Tot snel!"]
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    header: null,
                                    visible: this.state.code && !this.state.egg4,
                                    width: 400,
                                    okText: "Kraak de code",
                                    cancelButtonProps: {
                                        style: {
                                            display: "none"
                                        }
                                    },
                                    onCancel: function() {
                                        return e.setState({
                                            code: !1
                                        })
                                    },
                                    onOk: function() {
                                        return e.checkCode()
                                    },
                                    children: Object(s.jsx)(It.a, {
                                        value: this.state.codeinput,
                                        style: {
                                            marginTop: 20,
                                            fontSize: 30,
                                            fontFamily: "Permanent Marker"
                                        },
                                        onChange: function(t) {
                                            return e.setState({
                                                codeinput: t.target.value
                                            })
                                        }
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    header: null,
                                    visible: this.state.code2 && !this.state.egg2,
                                    width: 400,
                                    okText: "Bewijs je kennis",
                                    cancelButtonProps: {
                                        style: {
                                            display: "none"
                                        }
                                    },
                                    onCancel: function() {
                                        return e.setState({
                                            code2: !1
                                        })
                                    },
                                    onOk: function() {
                                        return e.checkCode2()
                                    },
                                    children: Object(s.jsx)(It.a, {
                                        value: this.state.codeinput2,
                                        style: {
                                            marginTop: 20,
                                            fontSize: 30,
                                            fontFamily: "Permanent Marker"
                                        },
                                        onChange: function(t) {
                                            return e.setState({
                                                codeinput2: t.target.value
                                            })
                                        }
                                    })
                                }), Object(s.jsx)("audio", {
                                    src: Oe,
                                    id: "win"
                                }), Object(s.jsx)("img", {
                                    src: Os,
                                    style: {
                                        position: "absolute",
                                        bottom: 0,
                                        width: 900,
                                        left: "50%",
                                        marginLeft: -450
                                    }
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        visibility: i ? "visible" : "hidden"
                                    },
                                    children: [Object(s.jsx)("div", {
                                        className: "lights",
                                        style: {
                                            width: 100,
                                            height: "100%",
                                            position: "absolute",
                                            left: 0
                                        }
                                    }), Object(s.jsx)("div", {
                                        className: "lights",
                                        style: {
                                            width: 100,
                                            height: "100%",
                                            position: "absolute",
                                            right: 0
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        display: "block",
                                        width: 900,
                                        height: 500,
                                        position: "absolute",
                                        bottom: 0,
                                        left: "50%",
                                        marginLeft: -450
                                    },
                                    children: [Object(s.jsx)("h3", {
                                        style: {
                                            textAlign: "center"
                                        },
                                        children: "Wat moet je kunnen als helper?"
                                    }), Object(s.jsxs)(ht.a, {
                                        span: 16,
                                        offset: 4,
                                        children: [Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg1: !e.state.egg1
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg1 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg1 ? gs : bs,
                                                style: t
                                            }), "1. Goed kunnen luisteren."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    code2: !0
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg2 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg2 ? ms : bs,
                                                style: t
                                            }), "2. Beschikken over Paas-kennis."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg3: !e.state.egg3
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg3 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg3 ? ps : bs,
                                                style: t
                                            }), "3. Voldoende hoog, snel en ver springen."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    code: !0
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg4 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg4 ? xs : bs,
                                                style: t
                                            }), "4. Kraak de Paascode."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg5: !e.state.egg5
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg5 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg5 ? "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJcAAADJCAYAAAAuG6D+AAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4nO2dC5QU1ZnHv6rqd89MzwzDMDwHVFAEEQTByEPERzS6GzDm4WMNijFm8zDnrNkkm2RD9sTEZDcvzbpZVzaYNaInUciquMEIAsYVBIGIO4CIDDA4zAwz0/Psd+35qrpmanqqquveulXVM9TvnIae7q6q21X//n/f/e6tKk4URfDwsAPe26seduGJy8M2PHF52IYnLg/b8MTlYRueuDxswxOXh2144vKwDU9cHrbhicvDNjxxediGJy4P2/DE5WEbnrg8bMMTl4dteOLysA1PXB624YnLwzZ83q4d5A971n06lQvO7ctFP9KViV2YygVD+OapZH2l+nMxX0emXOjqwec1gZYD+H+5EN8U4hMbPzb//kY3v0MpcU7Pod+891f1XdnYd1pT4246nZw8LpELc1bXWRto7q8NNB+u8rU9ecvlq3/OpqUjk3NOXGpBHeufUWfntkJ8v1gfOnZsfPDUtz6+YM2zdm6rFDlnxPXi3seXnElNePRo34WXsnAoUtDRpoXfe/ozC2+71+ltu8WoFxeK6lSifv3hvlnnl0BzpHztoujBJ88FkY1acWH4a02Pe3J/9+VXlUBzhoEim1O292ujOS8bleL63e6nfvhu76UPxjNVvhDfD4lcuARaNYi6TeeFjzRPCx/95M3z73u9NFrHjlElLnSr9/tnvKlO1B+sXwtNycmwoXmNu43LMyF4Er40+UewseU2eKtrsfQiJv4X+ne/sHrZHR8vgSYyY9SIC93q7e5FX1cn67fVrYOFFX+Wnm/vuA42td7mZhMlx/pa/Xeh2t8m/f3Pjd+D08nJ0vNMKgGT+HdbLig7fsUnlj7wgasNZcSoqNCv+98X970RX/4NtbBWjt0wICzkqqpX4HLV306DwkLHUoSF4N/oZIgvEIJTuVm1O1queP+ZnY//nWsNZciIdi4Mgwd6FjS0pOqGJFUootvr1mkus+70l+FgzzynmjjAPRN+CZeUvT3s9fZ0jeRgSg6W6uuBTDIBl9f85YV7V9z11443lCEj1rlwqGZ31+KjhcKaXbZPV1gIvqe4hVNgeNYSFoJOhg6GzoYEImXgC4bgrbY5f/WzPz5/zNGGMmZEigvzqzfjyzZgb1D9OorGSFhImO+TDmaV/6zdzZRYVvXKkPCsxcTgiSHt9ocjwPt8cCh+3rR/fOHV/ud2/mKaI41lzIgT1zO7NzxRmF8hKBYUTVhIAfBlAMKYwQc/tBSBAlsz4dEBt7ALDM+rxm4wtXZ0ttvyAuM4HoLRCuB4Ds70jwnt75j9fyNRYCNKXCisXfGlw2oKEaEfPjd5PYSDYwH80wB84wGE6sGHb5L8OoouD7oFitEuzLhoIehw6HQIx/MQiJRLz1sSY0K72+cfef7Nxz9jW4NtYMSIS0tYPAcQCwrwwPlPw/hICoAL6K+A88mi4ysGXkKB3UYoADMotSwa0OmUXq3gD0j5F9KZLPNtb7r06Wd3PHY78wbbxIgQl5awwj4exkX98MkJL0BtoMX8ynzjhoRJdIuVJkOXGTDUYsjF0EuLutOBCT7mX0giG+TeaJ3/1EhxsJIXV6Gw0K2qwz6oifjg2jF/hFnRA+QrxTxMBasamFYtixZ1DQwFhvkX5AW2r+X8X4+EHKykxVUoLIHnoDbih6ifh4uj++Gy8l1yuONC8sMsXBiACw75MLrF+eHDltqL68BQywJ1p4MXfOAPRQbWijnYSEjyS1ZcWMc60L3gHuXvgMBBXdQHfoGD6ZHDcEPtDgDfhPyjVn74JwEIMXMbUCX3CmsmPkpdAzOqZdGiroH5guGB8Ah5gR3onP1/TDfImJIUF87BwjqWUm5AYY2N+CTnmhI5Cx+t2wPAl8uuNQQegI8BCFXFN1LgXKCqgZGWKMzUsmhR18CwPKEGyxSlXGgtOXHhkM47PZdtKRRWQOBhXDgLf133PxDgUsYrkYRn0HMEqa+v+TKpwEhqWbQoNTAsT2CBVQ0WWp/Y+pv/trUBlJScuE4kpr2qDOkowor4BagNZ+GGsS8VF5YCH6VuA7oF5jvFoKll0YLOiELG3AtFpgaHip7avu7HjjSEgJIS1293/W6jMh0ZQ6AirFiQh6urt0C1j2DIhvNbassFkUOGNTArtSxaUMgosEC0fNga3mqb/eBzf/7lMkcbVITSEVfj9XOXV/1xpdQ74gDGhgeF9ZHYazAu8KHjTUK3+OiYPwx7HduIB9pKLYuWVbUbYHK0WSqwqqkLnOSWhp97zPEGGVAa4mq8Hk863YThaFXt01AZ8kFZgJeEdUnZXjgv/J5rTbthzB+G1MCUWharkgMpSk44tapjYMm6YJMcnkVx1tn9K0pGYKXiXOsBoB6fLKx6F24dvxkqggJMCx+BOYy79wPkzPcI1TUwFL9bwlJAgd0x4ddQFgYI8glprlg43wHJZnNfaNm74jpXG5jH/cmCjdevBICN0nMsD/inSGOAxxIXW3MsMQGQMRgWypwByHWZXl1/LgJH+y5iXsuywsnEZOjoSEKd/1ThWk7lRP7SugVb291sn7viarx+KgDsxzOtpL/99fmxv+EJKzG5OEA2rr9U+gSAmLTpizlHb19WehTC89yGmnnbXB3kdjssrh8QllApz1hgISxENCpZ5EaFsJBwSABO4/zxXE68ze3w6J645HB41UAzpMl9JirrZskZiIcg3yp1sOQVCQt6X/Q/m/esqHbrK7gjLrl3uH7gb9/YfFXdWm1qgFyf7E667/ew2U6JoOdeADDJ74Pvu9VKt5xr7UA4xPFBKRyaHHA2g6hyptYIQLLgl+22uN6rNPEh8xi5l9R7fHvFAqYbNInz4mq8fi4APDDwtzTHPaoxCE2JmAHI9crLoqiemQHwzIWDApN6iAauZje76gAenQvw/AVMN2TgXgBi7hdufFU3nGvwwhsDrlVhuAARolpYFwIkBICWMMDmqfLrBOUH5jSVDYrqtUmy0BhhnHvBla37VnzS6a/rrLiGJPF515Im+zHKtdCRst3yUxRTi+qsn6OVAC9Odi+ZR2E9MhegX+XQv70I4C81zDaB7qWHmMv9lNmGTOK0c6kuF8TnXYt+9sIwsh2ywF6eKoupkO1B2TGcBgX11EVDhaWAAmsaPnGRBnSvUEj3kE5qefvqHzj5zZ0TV+P1X1WGeCSEfCjUmLRHhZiWc6294wAOjhm+hkwOoLtfDksMw5Ep0LH0BISCw/fbCaZpGxCN6LsXgPhFJ0sTzohLLj2sHbrlfO+QZO67Edmzsqi26jhTe/fgc4ZuUZSnTGwLBfYfs7WdjRCcquT362T2IlTwvPigrd9XhTPi+vWsTbCrbrDWIOVZAXbCwqGeFp8cDrXoT8mupcbITViBLrnbpEsqORkDdBP7hADc47O/lvzZfY7M+7JfXP/6+XpoqFo2JHnVODmCGiyYNqflkoMeHRp1LYZuoQmGXtL8DgWGTmeRYIDHscXhK/n9dBCPl/tSJ0LrLW/EBPaLqzXyJCR88jdVwhGXnweuW5gxCeZZfXGAjefLJQct4n2yc2mBeU5hD44F+CP6LaVI0OkY1MDChYn97y8AaJDTrcSh8mlOuJe94lJcS0FJXrtZVKhzAH1nAZ6ZDhDXORkDk3h1rqUFI7cYANdHKywFBjWwIb3GN8YD7Ksd+BNnwiRa/A9Za2Rx7BVXR+jnA66lkA4CbJouFzmpp/vk5LlaL00eWssqpKUTIGdiG+/UsBEYSye0WAPDxD4Q4AHergV4afi5s6mGssXdP11j60m19orrSOXNw17z5yvmWD03nBajA4bC9GmAzRO0a1kKRuFQi90UOZIaO3I4i73aYFs5wHPaIVZMCFyuNfQbC60rin3i+uGXn4B4cPieDudDGArs5SnyjFGzYPKOM0j3jtWuZSmkMgBtFMM8VmpgdvQ+rdTAmsog/O/zgTPIa9MN5YutNdAY+8R1LFZ8FiQKZJuZA4LDOq0A2TaAg1X6tSzpoyJAk4WrBtK4hZlaFi00jqhaJsjrL5dL8FzX2vtt6znaI66ffPGr0BIxd2eBN6sA3snIsxkKwddwSAfDII4J4vQZvVoW5IV1ut1cnmUEiQuR1LJoIamBFbhdRDAet800VNxhV7PtEVdL+EtEn39hPEBDn5ykDzxOy49ct+xcKCyjWhbS3AGQTFtrOxC4BU0tixazvVrMsVQ/DB/HA69z6QIkE/f5un9wny1Ve/bievT+JXComvwmTv+Dsxh4OQeTHionw56lUS0LaYmTJfDFKNbzs1LLoqVYDQzFp+GiQd5ovBEg2xL8Wzuay15cZ8PG02qTGuEP5KEJyZm6CgaylXlZerUsyAurcHiHBegAWr0tFrUsWvRqYPiaTngOFwmNqUPl0+woS7AX17EK4x6IUdhK5B1KPS15q0EtC3OrU2ftEZYCHjB1OLKrqk9CYQ0MhWUg9mKhERE7Asxnq7IV1z9/6Yea5Qc1maxcOdcDhbQx7xaYvOuVHLDcgMk7ixyrGCgwPIB2j0eSoPRq1bNbDSgWGlNHym5k3US2J8V+/cGjpvKt8jBAbZETMib3AJzU6bGhU2Edy2qvkJTqBLN5V0wI51MME2JP5jIQTxvXFMPL2r5W/g+P/wur5rFzLhxHNJvIozhSOrmXgpaw0PHQrTDHclpYAKUlLMiLyqSLYr3LqKAKNiT27MTVFfgO0eex0FlMYAooJJw209jCtkd4jmFUUEXSxyNTJZNgBDtxmanIq1Eq6SgaPRfqTcou9cEZgPbRdSKrG/iLJfUJgetq5b7HqmlsMlOsbbVMIb/XL4oKRYOPoF++yLzyuhOJ+jkGOlc3GF8jI9sSZJbYs3GueND6zSdRTBjy8OEJyxZ4jpPKEkakj0VrWdW82IirsfyjTNbjYTv+IiUJROzyf5dFO6yLSwqJJgepPVwnYEJcrEKjdXGxCIkejlGsxwgMQ6N1cXkhccRRLO8CRqHRmri8kDgiMZN3sQiN1sTV419ttQEezmMm78qcDo212jBr4mqN3GS1AR7O4+NM9BgTAtf70P2WbvliTVxN0XFD/saB1Eus38iSKRN7Bgd4S4ULOl1tiMBxw6fgTBt+Qku6U7jBynboxYXz5AvPSbzlKMCdh+QDWgqgqL6yX36UisAWNsvtueOQq80YktR/4ijAvQeHCSzbHJpuZRv04uoOrBzyN+6sRc2DB9RtgSntwP+xLbjz3AbbgQcSwX2FQnOJgXHGFScBLsvfDOLOBoDxvQMNyrYGQ30/uZf6tH96cTVFFw48x520SLWj8ICig7npFigmtcCnd7rrFtiWQgfFfeSSwHx4pbh5LQDXqO6MG8rK+y002MZMt+8e7TUUh05cOC1DKUHgzrlT46Bp7UynQBFN18hr8Adw43Hn22P0Y0Mnc8HlfdO7AW49OvwNSWDvDggs1+l32Ln6/PdL/6ttXgt8/xaD9+0AxbPIwA3wfSfdolia4EYaMbEHhPve1X8fQ2Pe5TMfhibTboZOXL3+j5h2JjzQToWjhSadCV3EqR7bLSacyck0QpWL6l6BEDmvSzKOXNzvo8276MTV459FtDOcSF5RLFrhWY/PHbTfLZROjhmcSCPUnRzp8mhFro+Gif6KkyD2+O+m2RyduO49WEN8YOxMXrEtnyPsDRbsaOYUdnLMfg8704iCTo7fZ+Lie9echP75p6iu5U4uLrwDBu0BsSN5tSISuwSm18kxg11phEYnx2dGXJjUj++mmiFB41zLaTYkwTp5ZSEO1jWwYp0cM7BOI3Q6OQRXDb2SZrM04rJ2yWGWyWthLYsWVjUwlnkTqzTCoJPjE8wf/s53rrmWdNM04jK4hpFJWBwEvVoWLfjLXj7sdr7msaPHZzWNwGUNwjNPcPRT6dx5pJunEddVJj5THCvJa7FaFi3YHhq3sKtWZWW9yg+4CGZDo8BzxBGLTFzy7ezYgQIhFZjZWhYtNAPvZmpZtNA4In4We88mljGb1GezuUtJvwGpc1kPiYVgKDLrFkVsnhkkbkFSy6LFpAtJKG5XTXCtWRNwHMwmXYZUXGydSwEFU2weGMkOtorZXz5NLYsW/P5mOh13kDlv0UJqHlGEivw9nEzjvnMpGIUjAptnBv7yjTod+GNwwkXVFEsjUFhzyCZrmiqk5mlpy1xOsu7SEZeendtk86bQcwunwrMWemkEvm6zi/r9ZMe/NMKigpZDEdo8c9AJ1AIr5mhOUJhGLKToGFGQzohElXpScTG8hb4O6tyKwuZtQamBuRGe9VDSCAddlOfInMv8lQXlMsQ+ynaRgxdacyMUGlFqbVIu/GZB7L19Welhkjdq579m+q4bJJdQYnGrMfOUmrCgBNvksINyPEcUuUjCorPi8ig5xJw4i6RNJOKyN5n3GHU4d3d+j9EBQSHVE5cHESSFVC8setiGl9B72IYXFs9xcjbeLMIT1zlOJjuCxNXVXct6lZZIJqPSo9TaVGp099QwbxFTce3a/RnY8MzPSmbnYTue3/R92Pn6mhJojUxr2zRY/5vHoeHQilJoDmSzAEfeWwIbN/0TtLVPYbpuZuLCnbX7rU9DKhWRDmgpCAxF1dY2FRoOXQ1/evUrrrdHEvvG70v76E+vfhmamogndzLn0OHFsGPnGkilwrBj572QTEWYbYKJuHAn4c5SwAP60uZvslg1NSgmFJUCPnfTLRQXTakO3oubvyk5mVucaZ0Kb+4avGVT+9nJ8NLL32AmMMviwp3zooaQmk7Pcs0tUERqYSngD8AtgeGPDX90aiSX3+iOy+Nx+/1z35UcSw0KbNcusnuE6WFJXGqb1wIPMOZhToLiUbtoIRgCnHYL/JHhj00LN9II3Ba2KZnUvn/kkfcWSyHSKtTi0rJ5LTAPc8otUDQoHiMUt3BKYPjj0nJRNU6mEcpxw22Kov48LhQYJvpWIBHXkJMFtWxeDyeSVxSLkYuqkRPqr9juFkonxwxOpRFKJwekGpfxjVHxh2pFYFTiMrJ5PexMXhWbNyMsBdzBdoajwk6OGexOIwo7OaJocCP7PJjwq0sUqbQYN7s94rBoxua1sCt5Vds8KbiMHTUwvU6OGexKIwo7OSisXK749GZM+Ddv/saAwCZdsW232W2SiKvTjM0LPoBIOQcVVfKjLMaBP8DlG8o+eVXbPA2sa2DFOjlmYJ1GaHVysjnzN0ylrYGZFteevbf2GNk8XjGlqpaHunpB+r+8Wn7EanioncxD3RReEltHJ7vktdDmaWFVAzPbyTEDqzRCr5OTLZJvFYIlih077ie6ha9pcfX1VZbpvYduVTdFkBxL9zN+ThIbiq+7fza8uu0BknYOQ6+WRQuLGhhJJ6cYLNIIo05ONkd+ckd/orqP5POmxbXszk/9XO+9MXU8mLhX0QAosvaeFbBn313mF1JRrJZFi5UaGE0npxhW0gijTg7mW9ks+X3E/f6k8d3XC7BcoUe38gfNX29AAZ3sxJlb4WjjKqLlzNSyaFHcgnRmB20nxwy0NTCjTg5JvqWmLNp9hOTzROIaO/bYsEv5YcJuhb803A0tHdeh3IquBQ+61WS5GLhuPJhm3YKklkULaQ0MP2sUnovVt/QIBJLvk3yeSFzhUNdZ9d+Ya9G4ViG79n4OOvqWGgoMDzYedDuFpaDUwIpBU8uixWwNbMfra4q6KGkyr+D3J4muTEwmrkj8HfXfPqM7MBCQzoRg11v3QIqbrSsw2loWLbgtI7ewUsuipVgNDN87cOBmw7XnchlT9S0tbrj3rn8h+TyRuELBnu3qv4Pa455U9PVXws43vqgpsGI2bxfoADs0iqxOumgh6JRanY5jxxaZctF0pp9qu1WVZ4ivZUAkLqMeIwvi8Tp4e9/tAP7BexmZsXk7QSdQu4VSy+rutnwLaGoKB97x+SsmczLafKuiouND0mWIe4tVlU100jfJ6eaZsPfA3QC+CaZs3gnQEdAZwEUXVaPudJB0cjLZJHVIjJb1Et8JguQqNxLl5a2nOzonnm/0GUEAiMY4CIYGczKcq51KiNDfI0rPjWg8MQ/SqQfg4P4LsSpD2kRbQGeYdOggHPtgoQtbHw46p9LpMBueaV0LiYa7nyFdhlhcZWVnXwMAXXHh3W0rx/LDLqCPggtHOenR2y1Cf68IRoPy6GBVYwFSySxkS+Baa3gAS0VYCiQOioXTdJou6ASDSfG6e+5+mnQ54rAYDsfXG71fVsEVvTNDtJyDyjE8+IrcCwur/tW13qmVLKBN5JGamqZWmuWIj9yVn/mb15W8K1nQf0DXCkXMlSdQWDETAguEOcuFWg8UF/2F62Kxjl00y1HZQmVV02H8P5Memg+ZvRvDwMZxJsVYvqggK6p4qWDrQQcKizaRl/Z/WZyovqVAJ65Y88P4P+ZC6mnY/iDN2gCiFZyhg2F4rKj2wiMtqXQv9bJY31rx2TU7aJalOmJLbr/t2UCgT7KtZMJ6bw4dDEOkYDC8iAPkwbAXHkmx6lrVY1rfo12W2g7qxh05hv8n+9mUClBgxdwJJxt6kGHFtZDqyraHaZelFteYMSe+BZK4aNcwHAyNRsk7Jveee5kHe4hWXAtDIk0JQoFaXBgay6JnM+mUCNl8Yp8mmkqmDdbBlDn3WnjuZQ6sayVT1lxr/IRTr1hZ3lKWPHHSwRfx/75uWVw5Rtd6KuZeRuLzkMFwaObUMSMqys9amotuSVwV5a1fxf978+LCYZ1iQztmwPBoVJ4oq/TEZQTO10pRVuMVptYf+WDFXZ//wMo6LInrik99tnHK5P3vY0ki1a+ERjbuZXSyRzhSfBTgXCaZtn4jrurqM49ZXYflQ6Qk9j1xWVQCmD4h1xAsS+i5F9a9QlFz7hUI9EmPUsLO9mA4zFIMxpaVDU4yrq1tipNODNTCsrgwsce59TgQfcnFL8DSxY9CwM/mFnaG7mVCXHgQb1n1bbjumkeYtIcFNTXHYfVd98HMi7YxXzfOMqVJ4mfNegVWrfxHqB5zUvq7btzxJ1i0R1i7dq3llbR/sD1ZXdV0w+ULngXBH4WKWBu0nZ0JokhwvpkGGPpwmk5OIy/1BTjojYtgdNO1G67/CUyaeBCqqpqgoqIVjn2wyFJ7rFJe3gqfuvXrEAz2wnnn7YKmpkugm9E1ZDF57092gum70OWZMf3PsOTKJ8EnpGHSpHfgww/npG//+5uWsmiT+VviFaPxepyKcxUEZwLwEehJzYN9+1ZaXm2iT4TuTu02tjfnpKk7Wlx7zaMw86KtQ95hdYY2DYqLjq0ZzJGtXOeikP5kHDIZsloQOtVNNz4MQVWY7k/CDfVXvvZHFt+ZZVosW2D6NICYgbJwI8yYvtPySo3OLgqEtN/DkFMoLJAE94gt4cgMhcICaZ5UL9yy8tuWczAslrIQlijCG6yEBUzFVb8FnetJyMUBcj0A2XYYN+49mDLZ2v0/MbHXG9QOaAyUo3iuNcixli5ZJ+U9ToIuWigsBUlgq+gFhmWHRLKbaJlAoB+WLX1iiLBAulM/bz1HUsG6Q4+Ni0P6pORekI1Dff0+GFdLPfYpoXcKW6BgKAhFg+IxQnELpwS28PJnNV1UDQrv5o/9kHjdmMD3J7uIlkFhfexjD0NN9YmCdcHLtfO3WqrIF8JWXPVb8Ij9HMQUQKZZci+cyzxjxk6IVdDfOd5oOo4yzwvFgqJB8RQDP4PuZneJAl100UJzU88nTjwoOZxZMIFPpLqIq/BXLHp6mLBEEbr9foH52b3sS5H1W9C9GiFzBiDXC5BtkV6++OI/QTTaTrVKwWASIroaigTFYkZYCugWVsJRMSZOeNcwPGuBDodOVwylZ0haz1q2dB3MmP76sNdF4B4aM/dVolP1zWBXnXu19C+Gx2yXFB59vhTMuWQzCAL9GSha+P3De2FmwWVwh7MGXfQmijCHoNMZdTpohYUlBy1hAce9W7dg249o2loMe8QlJ/e/ALEfIHMaINsGICZlgc1hK7AlSzZQCUsB3YIkHBVDKjmYDM96oOOh82mRSHVTCQsTeG241cy+fAF2jtBheDwg5V34UEoU0XaYdfGrTDYw/7LnYfoF/2t5PSgwFiUKpZZlRVgK6HzqTgc6Vl+ig6rksGiR9pSsnMh9o/ayrXssN1YH+8RVv6UzHx7l3mOuS07yxRzEYh8S1cC0pvLUT9knPUCkP6tFDYsaGPb4rLioGnUNbDAUkl1XS6uWpYC9Q7vCoYK9cwvqt+wHAGlaDqSOA2Q75TApJolqYOmCKIqiQtdijZUaGIZW7PGxBAW2cuW3IJP7kDgU6tWyQO4dngKOv5P5DizA/okr9VvWS8VVwPP535cFhiEy12+qBobjiuqTQGKxZqljMPgBdvOsaWtgZmpZNGQyIgjCe3DN1T8lWlqvlgX5sgPH86vqFmyl67oT4MysqPotq6X8SxEYlijyif6M6dsNa2C9XYOn/aOwli1ZB35/PhRiPQ0YzE5UQVoDI6llkZBM5aAjnpZuEzx+/CGiXq1WLUuB47kH7cyz1Dg55W65VP8acLC4/Eg3wsUX/g7CoSEXLZRmtMbbRWngGvH7EjD/sucGhSV9iM3csULM1sBoallm6O3LQrwrM2TGB5YR5s37Q9Gl9WpZILkW96vay7Y9zrzBOjgnLjnBXykl+Ciw9HE5wYcc+LhmuHTmYxBv64PONhHaz+SkRyoxKKylS9fhybhD14klDpsoVgOzUsvSA1OAzq6MJC4t5s/bJJUV9NCtZYFUz9owbsG2L9i2wzRwdrKwnOAvlwWGScUZ2cXElORISxavk3Kownn4WBsbJiyp58m2IFsI5lFLl/znsNdZ1LIKSaVz0N6ZhlTKeDgHk/TxdYeHvY75q14tC2c71F62jc1NFAlwfib6oMBkcAZF8ogklsqKJvjIFUNrMtgrlEoOarBuhsJ0gLmXvjCkRMGylgV5t+ruyUBnPCPlV2a49tpHBmaNQr7koFsk5bh3ReD/ypGdVYA7p8T4LHYAAATDSURBVDnIArs7OfArzcpiSTZATex1mDdHTpAHalkK6FTpJnlYyUEwrzpvmnw/JZa1LMWt+hNkg89YXsD6FfYKce67Xi0LhZXLccuc6BlqwW4mKgUfvnX1p4MBeDxW4asQ+KGD002n58DESccGX8Arnoi2XjHTEJw1ipcGx+nJVkG36unLQIJQVIUodxLT7Bm6LCxwW1xIy9srFgDkXo2GhYpwSBjVp4yhqPoTWejrzxrO/bcK5lgYCt0UFpSCuEAlMA6gIhIWYDSKDEMf9gLN5lXUcNwGN5J3LUpCXMj7O5ePKY9y20EUZ3EcwGgQmeJUKCzbRSUPRD9ct2Cbs3deMKBkxIU071lRzfPiUyCKNyqvhUI8REIC8VUL3SSbEyWXSiZztoY/BXlIByvvzhVIzVBS4lJo3nP113lOHHJdKJ7nIBrhIRDgoTD5LwVQUFijQpfCMUEHwUHoVU4N6ZBQkuJCTr159cJAQHwFRKgofA9dLBjgwY9TnP3uxU0UEZZT8OGwoGQ47uVcjrvT7cRdj5IVF+TDJIi5p3gebjT6HIrMJ3Dg88mXvrRDcCgedCf8H+tT6bSL+42DLo7jHxo7b+uP3WtEcUpaXApn9lz9eY4Xf6zlYnpgp0DJ01B4vCqUYidBENR39xh+yQAUEORFVWK76A1BEO6y44QK1owIccFgb/K/1Mn+OcUIcSs1I+bq7jVz/q0cAH6cjb92NnP2pU9AridcAs1yBD58/hFf7V1Pcv7a3SOp3SXrXPF4w9z8ADc+8Hm9+v1sfCek218GLtvhXiNthgudD8KYW0EID7tQyQEAwDOscIz2tVhsprPXJzBJyYgrHm+ozM/3Wp7/P1ZsGTHbB9munZDp3D6qRIai8lXfDHzkIrOLKGJbH4vN3G9v68zjurji8Ybl+bOEPku7Dqn63fNnSLdvBsiMXJFxZQvAV7GYRFRaNKLI8kJz1dFcE1deVGula3oxJNvXANmuN0DsKbmaoja+KvBVLAKhYjGAr4b12p/Es69isZmdrFdsBlfEFY834O2MLV2GuhgYMsXetyHbewBy5Dc5tRVRqAIhegnwZXNBiMy0e3M463d1LDZzk9Pf03FxxeMN+CU/7uQ2pbDZvw+yvYdBTB4FMXnayc2DyIXk5DwyXRITF5zi6PbzrHJaYI6KK98DtHY1OAZIYkscBkidgGymD8TEUan6zqeOWVo5iogPTgROCAMfnATgnyQJiQ+4d7N1FY2x2ExHb87tdJ1ruYnP2I5UrcekOXKR5jzvXKoVIHPWdDO44GTghGgpfDUj6ukXpcNpcaEt/8zhbRIjOU1puA1Ltju9QUenFOS7xnc7uU0PifjANdMcxPH5KrHYTKzBrMrXYzzsBx1rqhs1LzfrXJX5K+B81Uw13oMYFNXaWGzma27tupIY/onHG1bnh3wcLVGMQhrzeW1JDAOV1MB1wfjicjd6OCOQA3lBbSqlcUUo9flc8XjDVNWsiLmsh4pGIHFlJoQyK8KtoR0zjJjJggr5QuxUleAqR6HoFBEdzz9KXkhajDhx6ZEPqXPzbyvFWkV8UEICbMwLBvIC6sw/pOelFtqsMGrERUI+3BYOhWi9RoMimAHc7LG5yTkpLg8HAID/B/SrjATKSEecAAAAAElFTkSuQmCC" : bs,
                                                style: t
                                            }), "5. Paaseieren eerlijk verdelen."]
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                fs = i(164),
                vs = i(131),
                ys = i.p + "static/media/bunnycorner1.3a471ebe.png",
                ws = i.p + "static/media/bunnycorner2.d0519d8f.png",
                ks = i.p + "static/media/send_email.ac2991f3.gif",
                Cs = i(175),
                Es = Rt.a.confirm,
                Is = It.a.TextArea,
                Bs = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).handleChangeComplete = function(e) {
                            s.setState({
                                color: e.hex
                            })
                        }, s.showConfirm = s.showConfirm.bind(Object(ve.a)(s)), s.state = {
                            drawing: !1,
                            sending: !1,
                            mail: !1,
                            color: "#000000"
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "showConfirm",
                        value: function() {
                            var e = this;
                            Es({
                                title: "Nieuwe Email ontvangen!",
                                icon: Object(s.jsx)(vs.a, {}),
                                content: Object(s.jsxs)("p", {
                                    children: ["Van: De Paashaas", Object(s.jsx)("br", {}), "Onderwerp: Helpers Gezocht!"]
                                }),
                                okText: "BEKIJKEN",
                                cancelButtonProps: {
                                    style: {
                                        display: "none"
                                    }
                                },
                                onOk: function() {
                                    e.setState({
                                        sending: !1,
                                        mail: !0
                                    })
                                }
                            })
                        }
                    }, {
                        key: "send",
                        value: function() {
                            this.setState({
                                sending: !0
                            }), setTimeout(this.showConfirm, 3e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "MINI2_Mail",
                                children: [Object(s.jsx)(Rt.a, {
                                    title: "Nieuwe helpers voor de paashaas",
                                    visible: this.state.mail,
                                    width: 750,
                                    footer: null,
                                    children: Object(s.jsxs)("p", {
                                        style: {
                                            fontFamily: "Permanent Marker",
                                            fontSize: 20
                                        },
                                        className: "writing",
                                        children: ["Beste toekomstige helper,", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Ik heb met veel interesse je email gelezen. Als paashaas heb ik wel hoge verwachtingen van een nieuwe helper:", Object(s.jsx)("br", {}), "Een nieuwe helper moet beschikken over goede ogen. Daarom heb ik alvast wat paaseieren verstopt. Hopelijk worden deze allemaal gevonden! Bij de verstopte eieren zijn puzzels en opdrachten terug te vinden. Deze draaien allemaal rond een eigenschap die ik van goede helpers verwacht. Is een opdracht geslaagd? Vink deze dan af van mijn \u201cstrenge eisen-lijst\u201d.", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Veel succes!", Object(s.jsx)("br", {}), Object(s.jsx)(M.a, {
                                            href: "checklist",
                                            style: {
                                                color: "black",
                                                fontSize: 20
                                            },
                                            children: "Bekijk hier de eisen-lijst"
                                        })]
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    title: "Email versturen...",
                                    visible: this.state.sending,
                                    footer: null,
                                    children: Object(s.jsx)("img", {
                                        style: {
                                            width: 250,
                                            marginLeft: 100
                                        },
                                        src: ks
                                    })
                                }), Object(s.jsx)("h1", {
                                    style: {
                                        color: "white",
                                        paddingLeft: 20
                                    },
                                    children: "Contactformulier"
                                }), Object(s.jsx)("img", {
                                    src: ws,
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        right: 0,
                                        width: 250
                                    }
                                }), Object(s.jsx)("img", {
                                    src: ys,
                                    style: {
                                        position: "absolute",
                                        bottom: 0,
                                        left: 0,
                                        width: 250
                                    }
                                }), Object(s.jsxs)(ht.a, {
                                    span: 14,
                                    offset: 5,
                                    children: [Object(s.jsxs)(jt.a, {
                                        children: [Object(s.jsxs)(ht.a, {
                                            span: 12,
                                            children: [Object(s.jsxs)(jt.a, {
                                                children: [Object(s.jsxs)("p", {
                                                    style: {
                                                        marginBottom: 5
                                                    },
                                                    children: [Object(s.jsx)("b", {
                                                        children: "Aan: "
                                                    }), "help@depaashaas.be"]
                                                }), Object(s.jsxs)("p", {
                                                    style: {
                                                        marginBottom: 5
                                                    },
                                                    children: [Object(s.jsx)("b", {
                                                        children: "Onderwerp:"
                                                    }), '"Nieuwe helpers"']
                                                })]
                                            }), Object(s.jsx)(jt.a, {
                                                children: Object(s.jsx)(M.a, {
                                                    style: {
                                                        margin: 10
                                                    },
                                                    onClick: function() {
                                                        e.setState({
                                                            drawing: !e.state.drawing
                                                        })
                                                    },
                                                    children: this.state.drawing ? "Tekst Schrijven" : "Tekening Bijvoegen"
                                                })
                                            })]
                                        }), Object(s.jsx)(ht.a, {
                                            span: 12,
                                            children: this.state.drawing && Object(s.jsx)(fs.a, {
                                                color: this.state.color,
                                                onChangeComplete: this.handleChangeComplete
                                            })
                                        })]
                                    }), Object(s.jsx)(jt.a, {
                                        children: this.state.drawing ? Object(s.jsx)(Cs.a, {
                                            brushRadius: 5,
                                            brushColor: this.state.color,
                                            canvasWidth: 800,
                                            canvasHeight: 330
                                        }) : Object(s.jsx)(Is, {
                                            rows: 14,
                                            placeholder: "Beste Meneer Paashaas,"
                                        })
                                    }), Object(s.jsx)(jt.a, {
                                        children: Object(s.jsx)(M.a, {
                                            onClick: function() {
                                                return e.send()
                                            },
                                            type: "primary",
                                            style: {
                                                margin: 10
                                            },
                                            children: "Verzenden"
                                        })
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ss = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Help De Paashaas - Festiviti"
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "checklist" == this.props.match.params.phase ? Object(s.jsx)(As, {
                                background: us
                            }) : "mail" == this.props.match.params.phase ? Object(s.jsx)(Bs, {
                                background: us,
                                next: "checklist"
                            }) : "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: us,
                                next: "mail"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: us,
                                next: "mail"
                            }) : Object(s.jsx)(A.a, {
                                to: "/overview"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ls = Object(A.h)(Ss),
                Qs = i.p + "static/media/background_start.c59dfb9c.jpg",
                Fs = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUQAAAE7CAYAAAClnvjSAAAACXBIWXMAAAsSAAALEgHS3X78AAALO0lEQVR4nO3d73HcxhnA4Rc5f5dcga8DsQNfKrA6yKSCuAR3EKUDp4I4HZw7kDo4VRCpgBvkA19aIIgz/93e3i6eZ0YjkiKhHY/npwWwWAzjOAYAEX+pPQCAayGIAEkQAZIgAiRBBEiCCJAEESAJIkASRIAkiABJEAGSIAIkQQRIggiQBBEgCSJAEkSAJIgASRABkiACJEEESIIIkAQRIAkiQBJEgCSIAEkQAZIgAiRBBEiCCJAEESAJIkASRIAkiABJEAGSIAIkQQRIggiQBBEgCSJAEkSAJIgASRABkiACJEEESIIIkAQRIAkiQBJEgCSIAEkQAZIgAiRBBEiCCJAEESAJIkASRIAkiABJEAGSIAIkQQRIqwriZhhuNsOwqz0O4DoN4zjWHkMxm2F4GxE/R8T7iHh34ts+RcSX/PiQvyK/9vHum47juC8xRuB6dBHEzTBs4zZ6u4h4GxE3EfEmIr7m7+c2jei9cEbEfvLx4TiOhwJ/P1BA00HcDMNNRHyIiB9rj+UJvsb9cH6M01H9eBzHLwFcVLNB3AzDh4j4R+1xXMA8pIf4dlofcX9G+uU4jtPvBZ6hySBuhuHXiPhb7XE0YHpqHzGLZ8xC6/SetWsuiGJ4MfOYfozTcXXTiS40FcTNMLyPiP/UHgdP8vvs8/0jn7tuSnWtBfEQET/UHgcXMZ+hHuL+tdP5Kb9ZKq/WTBDNDnmBz3E/ohELM9O4H15hXbHvag/gGXa1B0BzfoiHZxSPLtHaDMP8S0thfRDSeBhbd/0b09IMcR9trDeEP7MU18PC1x5cEgiBLa6lILYxULi8+Q2siOUZ7F1kLbE6QRBhnT5HxG8R8UEcvxFE4F8R8YtlT4II3PoUEbu1R3FV+yECJ72LiH1umbdaggjceRcRv9YeRE2CCEz9lA9BrJJriMDcp+M43tQeRA1miMDcu9x8eXUEEViyytNmQQSW7GoPoAZBBJascvmNmyrAouM4Ptj2p3ctbf9V2r/j9l/Fu38Zt2EzWlgVM8Rv/npqY9BcvT+967abfLzNXxG3MX13/qHB5Zkhsiif79xPvrRf/s77cunCdMa5nfzxbvLxNsxGuS6fag+gBkEs6KWbeW6GYTf5dBv3QzqNrBkppaxykwdBvEIvfafHZhi2cXoWOj/t34ZZKaetcmduQexIbvR5mHxp/9SfnZ3eR9yfiUY8jKuZad/MEFmvhdP7/VN/duGm01M+F9Trtq89gBoEkVdbuOkUcbs9/ZPNrptGPHxSYj5j3YZTfs7MsptvTi674fotzFIjHkZ06Xu8yXHZ92vcPVsQvxFEnhrWiIcz2K4uA6xxDWKEU2a458Tp//zzJ1m46x+xHNelr22j3iWBz5X+3uoEEQpZuOsf8YqbFZPA3kTEP196nCc4FDz2VRNEaMRdYDfDKs9mL8L2X9CebeHj7wsf/2oJIrRnW3sAvRJEgCSIwNy+9gBqEURoz7b2AHoliNCebe0B9EoQgblD7QHUIojAPbnecZUEESA1EcSFraFKOFzg7wCuWBNBvIQ1nybQnPluPOf0teCxr54gQnveFDz2Kt+lckcQAZIgAiRBBEiCCJAEESAJIkASRGDKshuAtLp3MU8JIkASRIAkiABJEAGSIAIkQQRIggiQBBEgCSJAEkSAJIjA1K72AGoSRIAkiABJEKE9n2oPoFeCCO1Z9RZdJQkiQBJEgCSIAEkQgamb2gOoSRChPSVvqrwpeOyrJ4jQnlW/Ga8kQQRIggiQBBG4ZzMM29pjqEUQoT2HwsffFj7+1RJEaM+h9gB6JYgASRCBube1B1CLIEJ7Su92s9qnVQQRGnMcRwuzCxFEgCSIwNy29gBqEURo0+eCx94WPPZVE0Ro06H2AHokiABJEIG5H2sPoBZBhDbtaw+gR4IIkAQReGAzDLvaY6hBEKFNnlYpQBChTaWfZ14lQQSW7GoPoAZBhDY5ZS5AEKFBx3Esfcq8yj0RBRFYsso9EQUR2vWp9gB6I4jQrpKnzduCx75arQRxV/j4/qWF+36oPYAaWgliadZ00aJ97QH0RhCBRWt8fE8QoV3ObM5MEKFdpRdnr24toiACp6xuLaIgQrsOtQfQG0GERh3H8VD4r9gVPv7VEUSAJIjQtt8LHntb8NhXSRCBU1b3tIogQtsOtQfQE0GEth1KHnxtT6sIIkASRGhb6adVVrU4WxChbV4lcEaCCG0rHcRt4eNfFUGEhh3HsfQp87bw8a+KIAIkQYT2lXwFxo8Fj311BBHaZ6PYMxFEaF/RIG6GYTVLbwQR2mfn7DMRROAx29oDuBRBhPZZenMmggjt87TKmQgitK90EN1UAdpwgadVVkMQgcesZnG2IEIfSj6tshqCCH0ovTh7W/L410IQoQ+2ATsDQYQ+eFrlDAQReIpVLL0RROiDpTdnIIjQh9LXEHeFj38VBBH6YE/EMxBE6MAFnlZxDREgvak9gEsQROhH0adVNsPQ/dIbQYR+2PXmlQQRIAki9GNf+PhmiADJNUSgGV4l8EqCCP2wFvGVBBEgCSL041D4+GaIQBuO43go/Fd0/7SKIAJP1vvTKoIIfSn9sqmuT5sFEfpiG7BXEETgOba1B1CSIEJfSq9F3BY+flWCCH1xyvwKggg8h5sqQDMOhY9v2Q3QjEPtAbSslSDuCh/fO23haZwyr4AL0fSi9P/LXT++J4jQkQu8jrRrggg8y2YYuj1tFkTgubq90yyI0J/SGzx0SxChP96t8kKCCDyXa4gAvRNE6I+lNy8kiNCf0tcQt4WPX40gAs+1rT2AUgQRIH1XewBX4v1mGHav+PkfzzWQM/n9FT+7f+L3fYw/PzU7XOC1mCzzbP4LCeKtd7UHcGavCfTZ4r4ZhlN/9DmWt6n6Ess3BA4L3//Fc7snlf7v0u06REGkhh/y15KfnnqQheAuhXY+k51HV1ifr7cJxB8EkZ4shfbRGe8srF9jFszZ54eYRPc4jvvnDZFrJohw35t4GNGTs9ZZTOcz1P3k4+lM9eNxHF3nu0KCCOczn6GenJ1OQjqN6OHExwJ6IcM4jrXH8KjNMOzj+u7kQg2f4ttMc5+/T0/r737/X+FxfN9jpM0QoS3TGxo1Jwk38fQlWs2wMBsgCSJAEkSAJIgASRABkiACpFaCeKg9AOCeLjd4aCWIHr6H69Lli6ZaCeK+9gCA/jURxNye6TWbngI8qokgpg+1BwD0rZkgHsfxtzBLBApqJojpfdxulwRwdk0FMbcbeh+3uxoD9XS39VdEY0GM+OMGy03c7gsH1NHlUrgmNog9ZTMMv0TEz3G77TtwIcdxPPlKxZY1HcSIiM0wvI3b0+j3EbGNh28Ee+qNmP0rhvHYO4ov6W28fNHsc37WDubr9d/jOL6vPYgSmg8i12kzDLs/+eObWH70a5u/lr7fWcD1+GuvbxsURJq0GYZtPIznUmh3s8+3cfqd0Dzu9+M47moPohRBZNUWwvrY52uerX6NiJvjOB5qD6QUQYQXyuvX02uu0xnq/M96uOb69+M4/lp7ECUJIlzY7PrqNKLzj69pJtp9DCMEEa7eLKB3H09noNsod130a0S87/UmypwgQkcm8ZwG827m+TYeLks75WvcbqjyoccX0p8iiLBCm2GYRnK+9vRjbqayOoIIkJp7lhmgFEEESIIIkAQRIAkiQBJEgCSIAEkQAZIgAiRBBEiCCJAEESAJIkASRIAkiABJEAGSIAIkQQRIggiQBBEgCSJAEkSAJIgASRABkiACJEEESIIIkAQRIAkiQBJEgCSIAEkQAZIgAiRBBEiCCJAEESAJIkASRIAkiABJEAGSIAIkQQRIggiQ/g90l1hrd2HSYAAAAABJRU5ErkJggg==",
                Ns = (i(266), "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUQAAAE7CAYAAAClnvjSAAAACXBIWXMAAAsSAAALEgHS3X78AAAYqklEQVR4nO3dQYxbx33H8d8sbVSGI0iKm8C1m4iNgSJFCHgL+Cp4WzS51dqectTqUKA9WQ7Yc9bHAgS8vgXoIdStOnmVo3QoVaE3H3YBupdCLhVBqmFVkbaqoEVU6vXAoc3lcncfyTdv3n/e9wMY1krrx38U4ad5M/+ZcVmWCQAgrcQuAACqgkAEAI9ABACPQAQAj0AEAI9ABACPQAQAj0AEAI9ABACPQAQAj0AEAI9ABFAq12mtuk6rGbuOWRyHOwAIxXVa65LWJa1KeveIb9uVtCNpW1Iva/eflFTeIQQigEK5TuuspCv+nzMLPOKqpK2s3d8ptLAcCEQAhXGd1hVJm1osCKddl3Qla/cHBTwrFwIRwNL8qLAr6WLBj96TtJm1+1sFP3cmAhHAUnwY9nT0HGERrmo0Wgw6v0ggAlhYSWE4titpLWQo0nYDYBldlROG8p/TDfkBBCKAhbhOq6vi5wxPctF1WpuhHs4rM4C5+TC8FLGEPwmx+swIEcBcfGtNzDCUAr06M0IEkJvrtDYk/Tp2HV7ho0RGiAByqVgYSqOdMIUiEAGcyHVaq5JKaY6ew3rRD+SVGcCxfBj2VMx2vKKdK7IvkREigCP5Y7p6qmYYSqNTdApDIAKYye9C2VZ1w1AiEAGEVvKWvGWcLfJhBCKAWbZU/TAsHIEI4IAK7EKJhkAE8A2/T9hSGA6KfBiBCEDSN43Xv4xdx5wGRT6MPkQA48ugPotdx7yydt8V+TxGiEDN+cbrbuw6FrBb9AMJRKDGDDReH6dX9AMJRKCmjDReH6fwvdUEIlBfPdntNbzFAbEACuF7Da2GoTS6+7lwBCJQM67T2pKtXsNpt7J2vxfiwQQiUCO+1/DD2HUsYU/SRqiHE4hATfhewyqdeL2IKyHmDscIRKAGDPcaTvo0a/e7IT+AnSpA4nyv4Y7sttdI0tWs3d8I/SGMEIGEJdBrKJUUhhKBCKRuW7bba3YV4Ha9oxCIQKJ8r+H7setYwq6ktSIvkToJgQgkyHVaV2S717D0MJRYVAGSU8EL5ee1p1EY7pT9wQQikJCK36GcR7QwlAhEIBl+RXkgu2EoSX8eKwwl5hCBJExcG2o5DC/HDEOJQARS0ZXt9prLoXeh5EEgAsb502suxq5jCcG35OXFHCJgWAIryqXtQsmDQASMcp3WmqR/iV3HEq5n7f567CIm8coMGOTba7Zj17GEXQU813BRBCJgjF9R7sruinKUXSh5EIiAPZYPbNiTtFHFMJQIRMAU4wc2RN2FkgeBCBjhV5QtH9iwUeUwlGoWiA3nVhvOrcWuA5iXX1G23F5zOWv3K78I9ErsAkJqOHdWo8Ml1zUx59JwbvLbdiWN5zMG/h/5n/vmb7NhlvWCFQocI4EV5co0Xp8kiT7EhnNNjUJvTdJZSasarcDtKcxK3GSIHghOjfaTjg2GWTYI8PmoiYk9ylYXUSrVeH0S04HYcG5V0pZsTDLv6WBw7ujoUN0ZZlklV+FQLtdpbcvutrzdrN1fjV3EPMy+Mjec25KtC7fP6GBwHxviE6/100E60Lev9dLBEemTYZZVetIa+Rnfo7yr0RubKSZHiA3nurK92laWyVd7aSo8NRW0vN5Xh/E9ynuSVkNeKB+KuUAkDEszHaY7OjpcWXQqkPFTryvfa3gcU4HYcG5d0mex60Aut6a+7p3wNfOmSuLU67+x0F5zFGuBOJB0PnYdKMX0CHWgg3On06/8SYxSXae1I7srypU45HUZZgKR0SEWcFcHQ1SaMTLVweCNFqx+W57V6SBT7TVHsbTKvBa7AJhzXoffKE5s0Zpq3JdmB+uhINXhsM296m98W971FMJQsjVC7MlGvyFwnEPhmv3pd/4n+9vzfx2nnKVV9iivRVgKRBuFAvM496pe/uId6VQjdiWL2JPUTCUMpZod7gBUymsNvdz4oeUwTGZkOEYgApFkH7wpvXUqdhmLqvxRXosgEIEIsgtvKHvvbOwyFvWR5V7D4xCIQMmyd14fjQ5tupq1+1uxiwiFQATK9FpD2cYPYlexqFuptNcchUAESvTy75pWF1F2NTpzNGkEIlCS7OdvW11EqfRNeUUiEIESZO+dtbyIsp7iivIsBCIQ2lunRqNDmy5n7X4vdhFlIRCBkMbN1zaZuRyqKGzdAwJ6+fdN6Uevxy5jfvee/2/26Z3TscsoGyNEIJDsgzdthuGDfa38093vxC4jBkvHf4V2VaMrTMcz301xGC0WlLVOK7vwRuwy5rc/1Mq1+9LzYexKoiAQv9U96mBQf+H95HWKaxM/bvp/pFGYWj3tGEUxvIjiuvekB/uxy4iGQMzB3/XRm/ip3uzvPMjfGz054mxO/PLaxI+bYjSahtcaevnzt002X7tr9+XuPBt/uRuzllgIxIAWvSO54dzaxJdNHQzSyZBlRFoxVk+wcZ8/kfv8QN918k3YsxCIFbTonR4N55o6ehQ6/drfFKPSQpk9webBvty1+9M/W4tG7GkEYkL8RfODiZ/q5f1vp17vpYMjUelwuDIynfTWKZsn2Dx+oZVfDWb9CiNE1NeM1/te3v92xqJTnq/TCVSrzdf7Q610f3vUinKv5GoqgUDE0mYsOknSXAeITs2bSodvWZwesTZVkVf+lxs/kM69GruMubnrX9V6RXkWAhGVMGPedPrrY80YpUqHQ3TW9yx1k2P2s++bbL52tx9NL6JMYw4RsOqIUer01yfKGayStJb95PTZ7KffM/fq7754Kvebr479Hv/7WTsEIjAhb7C6TuusDl9eX32zV5Sn3S2jlCpiLzOwmG1JZ2IXMZf82/IGJVRTSQQiMCfXaW1qybnHGNy1+yyinIBABObgOq11Sb+MXce83M2Hcv2neb+9F7CUSiMQgZxcp9WU1I1cxtzcF0/lbnwduwwTCEQgP3vzhvkWUeARiEAOrtPakrXdNYufbdgLUI0JBCJwAj9v+GHsOubFIsr8CETgGGbnDedbRIFHIALHszdv+OWzZRdRBgVVYg6BCBzB9xvamjd8/EIr3XtLPcIfI1dLBCIwg+u01mSt3/D447yQg4lAnHE0VAiDEj4DBvh9ynMdX1YFHOe1PBOBWIY6vybgEHPzhjPuRFnUXhEPsYpABCaY3KdcbPN1Lc9BHCMQAc/0vCEKQSAC+mbesBu7jnm57j3p8YvYZSSDQARGuqrIHS15uZsPJy+WRwEIRNSe67SuSLoYu465LN98jRkIRNSa67RWJW3GrmMuBTRfYzYCEbU1MW9oqsWG5utwCETU2aasbc2TPgrcfE3bDVA3Ro/0up61+1uBP6OW14+OEYioHaMtNnclbcQuInUEIurI3NY8SetZu1/r0VsZCETUismtedJHWbtf67m9shCIqA3fYmNra14584bwCETUgtEjvZg3LBmBiLrYkrGteWLesHQEIpLnW2wuxa5jTswbRkAgImlGW2yYN4yEQETqrLXYMG8YEYGIZPlTbKy12GwwbxgPgYgk+RabT2LXMaePs3a/F7mGtcifHxWBiFR1Yxcwp1tZu78Zu4i6IxCRHNdpbcnWKTZ7ktZjFwECEYnxF0VZO8Vm3n7D3WCV1ByBiGQYbbH5dIF5QxZdAiEQkZKubO1G2c3a/Suxi8C3CEQkwe9GsXRRFPOGFUQgwjyjr8pXsnZ/ELsIHEQgIgXWdqNczdr9buwijrAau4CYCESYZnA3yl1Jy84bhlxUsfQXS+EIRJjlOq2mrN2pXMyRXpyCEwiBCMu6sjWi+ZgjvaqNQIRJBl+V2ZpnAIEIcwwe3LAnQ0d6NZxrxq4hFgIRFnVjFzCnjYJbbIp81izNwM+vLAIRpvhrRC0d3HA1a/eLvtxqUPDz4BGIMMPgNaJFtNigRAQiLOnGLmBOVk+/Phu7gFgIRJhg8FU55OnXoUO2trtVCERUnsFX5d2QLTbDLKOXMRACERZ0YxcwB06xMYxARKUZfFXeTOAUm2bsAmIhEFFZBl+Vy7xg/m7AZzcDPrvSCERUWTd2AXMoezfKoMTPqg0CEZVk8FXZaosNJhCIqByDr8ohdqPEZOnQjEIRiKiibuwC5hBrN0ovwmcmj0BEpfCqjJgIRFSGwVflRe5UNqHh3FrsGmJ4JXYBFrhOa83/sKnRPs/xToEdRgeF6sYuYA6x71Rmt0oABOIM/q6OdY3aKI59fXOd1l2N5nO2E5tYL5XFV+XIn89fxAEQiBP8/b5bki7N8Z+d999/yXVaexqNcrYS2K1QGoOvynW4G2VNNVy4YQ7Rc53WukbNrvOE4bQzkj6U9J+u09ryAYuTlbW7owhBD26YQ+qBHAWBKCn74E1J+kzF3uD2oaSBD1ocweBlURuxC5CkYZaFfmWu5V/mtQ/E7OdvK7vwRqjHn5H0meu0LI2ASmPwXuWPavCqPFbLMxFrHYjZhTeUvVfKX4Qfuk5rh1foQ7qyc6/yrRIPbshrN3YBqalvIL51avyqXJZ3Je34BYTac53Whuy8Klf1GtGQr83NgM+uLCuBuFb0A19u/LDoR+ZxXlKv7vOKE6v5VqRwxuG8zscuIAYrgVio7Gffl869Guvjx/OKG7EKqICueFUuQi92AampXyC+1lB24buxq5CkX7tOqxu7iLL50fHF2HXkVNVX5VLUcfte7QIx+8lp6VQjdhljl1yntV2XxRZelQvHbpWC1S8Qw7XYLOqiRvOKdQjFTdmZm6ryq/JY6BagOvyZPKBegXjuVemtU7GrmOVdjUKxGbuQUPwBGR/GriOnWr8qT6hdR0StAjF75/XYJRwn9bacqo+2JlX9VXlsELuA1NQqEFXtQJRGK6+91ELR2Ek2Fl6VJUnDLBsE/oi1wM+vnFoFYvbdaK028xiHYhK9in4aIOa5gfPgVbnmahWIFZ0/nCWlXsWu7PQcWnlVnnQr4LObAZ9dSfUKxOq02+T1a8uhaGx7nplX5RJZ6QgoTL0C0SaToWiw59DKa/20QewCUkIg2mAxFLdk51XZ8gnYg5APr9tuFQLRDjOh6HsOlzl5vExVOQEbFVCvQPzyWewKlmUlFLuxC5jDRuwClhR6ZJtUC9hJahWI7ncvYpdQhEqHou85tDIZb/lVeYyrBApUq0DUHfMjxLFKhqKxnsO7ibwqhw7EZuDnV0qtAtF98VTaH8YuoyhVDMWu7CykbMQuoAjDLAs9wm0Gfn6l1CoQ9Xwo138au4oiVSYU/c4aKz2Hn2btfi92EaieegWiJHfj69glFG0r9t5nYz2Hd2Xrpr88Ql42ZeUvuULULhD1+IXczYexqyhSFQ6E2JSdhZQrWbuf2sGqqf3viaZ+gSg/SrTfgjMpWij6z7RyzuH1rN3fjl1EAEEDseFcbVpvahmIkrTSvSc92I9dRpHOSOpGOHnbyqtyyifZcHJ2QWobiHo+1MqvBqOV53SMT94u5Q+wscMbNhN8VS5LM3YBZalvIEqjVefub+X+7Xd3Y5dSoHclBX8tNLaQkvpJNrTeFKTegei57f8aSLqs0WtVCt4v4YrTTdFzWBXsVikIgehl7X5XoyPTUwnFS67TCrJrxNhCyscGD32dV+hAZFGljvy+1qbC9nWV6ZNAjdvdAM8MIZXteccqYbdKbRCIU/zE+5qk65FLKUqhjdt+1GnlwqiN2AUkwsrC2dIIxBmydv9J1u6vS7oau5YCjHsUl54H8s/YXLqiclyt2fa8VN5qoiIQj5G1+xuSPo5dRwGKCsVN2VhI2ZOdU3eKEro5uxny+VVBIJ7Az0Fdjl1HAd7VEm0yxhZSUtyedxKOASsAgZiDX4FOoS1nmZVnK318t/z/X3XDbpUCEIg5JdSW84m/8yQ3YztSNmIXkKhatN4QiHPwbTlrsh+K2/506xMZ25FSh57Do9B6UwACcU6JhOIZjUIxz2vQpmwspNSi5/AYoecQ1wI/vxIIxAUkEoonLrL4UaSVhZSN2AVEVrdFpCAIxAX5UFyV7f6vSyfsZOmWVMeyrtes5/CQEnarMIeI4/n5qjXZDsWZO1kM3ZGS8jmHVWJh2mRpBOKSJrb6WQ3Fow6WtbKQwjmH3wr6Z7DhXPKtNwRiARIIxQPziYYum99N/JzDeXHqzZIIxIL4UFyX3YWWS67T2jB22byVOmEEgVigiTlFq6G4JTuXzdft8IY8eoGfzwgR8zHeknNGdhZSGB2WjzlEzM94KFrAQspsXCWwJAIxEEIxmNQvjFoGvYhLIhAD8qHIq12x+P1EMARiYBNHh2F5n/q/ZDDbIPDzGSFieT4UUzh5O6Y92bm+IIphlg0Cf4SF7oOlEIgl8SexpHBHSywspFRA6rtVCMQS+TtabsWuwyB2pOQXerdU0q/NBGL51mV3i18sLKTkxyh6CQRiyRLY4lc2dqRUSzN2ASERiBEksMWvLOxImV/oVfhm4OdHRSBGQo9iLiykzI/fryUQiBH5dpxPY9dRUXdZSKkkFlUQTtbuX5F0PXYdFbQRuwCjBoGfT9sNgtsQK8+Tan9HyhIGsQuwzEogrgV+ftTtYH6ebEMssowxt1pdvDLXQPSJaBZZvlHny+aLEPrPctLb9wjECvGLLHWeT7wrO5dbVVIJ15EmjUCsng2NgqGOaLMxoOFcsq/NBGLFTMwn1s0tP0JG9SW70kwgVpBfYa3bcWGbsQtICB0LCyIQK8ofF1aXP9jsVy4Wd6ssiECstjocAsHBr/Ywh4jy+faTzchlhLZFmw2qgkCsOL+fN9VWHNpswqD1ZkEEog0bSvPVmTabMEL/njYDPz8aAtGARFtxaLOxqxm7gFAIRCOydn9bab06b8YuAJj2SuwCKmK94dzaEv/9+0UVcpyVc6/q5S/ekU41yvi4kGizCYtpiAURiCPvxi4gl8cv5G48VPbBm7ErWcrKP/7HXzX+wfVm/NITzV4QGOjwsVZP2Ld7pNC/L8n2IRKIxrjbj5S1Tks/ej12KQtxNx9K//37tyW9fcS3XMz7rIZz0z91V4eDc0cHR0zToUuwzs/GAGIBBKJBK9e/0suP3oldxvz2h3K3H4X8hPP+n0knTmdMBeuepgJz6uuBJkJ3mGW9+UpElRGIFj3Yl7v5UNlPvxe7krm4619Jz4exyzjJGR0O0SNHrVNhOj1C7U38eHKkujPMMub5KohANMrdfqTsvbPSuVdjl5LP4xdynyefAdMj1CNHpxNBOhmigyN+TICWxGVZFruGEzWc66mklVxLstZpZZd+GLuMXNyvBnJ3nsUuIwW7+nak2fP/nnytH//7ceA6zqUY0owQDXP9p8q+fFb9BZYvnxGGxZlc0Ig5SFjVwSmBJNCYbdzKP9+PXcKJVq5/FbsEIBcC0brHL0Kv3C7Fff5EerAfuwwgFwIxAe7mQ2m/mqu37sbXsUsAciMQU/B8OGppqRh386H0+EXsMoDcCMREuM+fVCt8wjdhA4UjEBPirlVngcXdeGihCRs4wEogDmIXYIG780z6sgLtLRVf6EEhkjzgwUogsvk+J3fjYewSWEiphyQvmrISiL3YBVjh7jyLu0XuwX4dtughUSYC0R/PdCt2HVa4G19Ha8Nxv6neajeQl4lA9LidLS9/kGzZ3O1HbNGDaWYCcZhl22KUmJu7/ajcV9cvnzE6hHlmAtFb1+i4JOTgrt0vJxQf7Guley/85wCBmQpEf9zQutK8ozgId+1+0BYY9/kTrXxyh57D+kly5czEeYjTGs41JW0r4bsdipa1Tiv74I+KO1B2fzgK2/7TYp4Ha/4ixesTTAbiWMO5TUlXNDr2HSd5raHswhvKLnx38atM94dyt383GnUyKqytYZYduuErBaYDUZIazp3V6DV6XVJTh0eNeRdiekuUMX2zW0xnlaNpNvvLP/xx9menf6w/fu3HesX9wbHf/PuX/+fuPX+if3/6yP3ro/HKCSeY19f1YZatxy4iBPOBiOW5Tqup0V8mk2E6DvlB1u4P5n1mw7m1Y355VbO3fo3rmPX9vAVUR5KvyxKBCKP8PHJz6qdnBe3a1NdNHb6qFPndGmbZWuwiQiEQUWszgvWkr+s8Wt2TtDrMskHsQkIhEIEF+fnryfnayRHq9K+lMOd6eZhl3dhFhEQgAiWbml+dDNHpH1dpJJp8GEoEIlB5UwE6/vHkCLSpcPOie5LWU11EmUYgAgmZCM/JwByPPM8q/2aGPY0OVNlK8UL6oxCIQA01nJsMyem+1R1/mErtEIgA4Jk63AEAQiIQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwCMQAcAjEAHAIxABwPt/qxC/RErij84AAAAASUVORK5CYII="),
                Rs = i.p + "static/media/notebook.969ed9f3.png",
                Gs = (i.p, i.p + "static/media/win.42321c98.wav"),
                Ys = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            egg1: !1,
                            egg2: !1,
                            egg3: !1,
                            egg4: !1,
                            egg5: !1,
                            message: !1,
                            code: !1,
                            codeinput: "Code",
                            doce2: !1,
                            codeinput2: "Code"
                        }, s.audio = new Audio(Gs), s
                    }
                    return Object(d.a)(i, [{
                        key: "checkCode",
                        value: function() {
                            "6708" == this.state.codeinput && this.setState({
                                codeinput: "Code",
                                egg4: !0,
                                code: !1
                            })
                        }
                    }, {
                        key: "checkCode2",
                        value: function() {
                            "bandenspoor" == this.state.codeinput2.toLowerCase() && this.setState({
                                codeinput2: "Code",
                                egg2: !0,
                                code2: !1
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = {
                                    height: 80,
                                    marginRight: 25
                                },
                                i = !1;
                            return this.state.egg1 && this.state.egg2 && this.state.egg3 && this.state.egg4 && this.state.egg5 && !this.state.message && (i = !0, this.audio.play(), setTimeout((function() {
                                return e.setState({
                                    message: !0
                                })
                            }), 4e3)), Object(s.jsxs)("div", {
                                id: "window",
                                className: "MINI2_Checklist",
                                style: {
                                    fontSize: 20,
                                    backgroundColor: "#9B6767",
                                    height: "100%"
                                },
                                children: [Object(s.jsx)(Rt.a, {
                                    title: "Je bent officieel detective!",
                                    visible: this.state.message,
                                    width: 750,
                                    footer: null,
                                    children: Object(s.jsxs)("p", {
                                        style: {
                                            fontFamily: "Permanent Marker",
                                            fontSize: 20
                                        },
                                        className: "writing",
                                        children: ["WAUW!!", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Ik denk dat ik niet verder moet zoeken. Je bent een echte detective.", Object(s.jsx)("br", {}), "Ik heb nu al een officieel diploma opgestuurd. Hopelijk kan je me binnenkort ook helpen met een echt onderzoek. Ga maar snel kijken in de brievenbus, ik heb er nog een verrassing bij gestopt!", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), " Tot snel!"]
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    header: null,
                                    visible: this.state.code && !this.state.egg4,
                                    width: 400,
                                    okText: "Kraak de code",
                                    cancelButtonProps: {
                                        style: {
                                            display: "none"
                                        }
                                    },
                                    onCancel: function() {
                                        return e.setState({
                                            code: !1
                                        })
                                    },
                                    onOk: function() {
                                        return e.checkCode()
                                    },
                                    children: Object(s.jsx)(It.a, {
                                        value: this.state.codeinput,
                                        style: {
                                            marginTop: 20,
                                            fontSize: 30,
                                            fontFamily: "Permanent Marker"
                                        },
                                        onChange: function(t) {
                                            return e.setState({
                                                codeinput: t.target.value
                                            })
                                        }
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    header: null,
                                    visible: this.state.code2 && !this.state.egg2,
                                    width: 400,
                                    okText: "Bewijs je kennis",
                                    cancelButtonProps: {
                                        style: {
                                            display: "none"
                                        }
                                    },
                                    onCancel: function() {
                                        return e.setState({
                                            code2: !1
                                        })
                                    },
                                    onOk: function() {
                                        return e.checkCode2()
                                    },
                                    children: Object(s.jsx)(It.a, {
                                        value: this.state.codeinput2,
                                        style: {
                                            marginTop: 20,
                                            fontSize: 30,
                                            fontFamily: "Permanent Marker"
                                        },
                                        onChange: function(t) {
                                            return e.setState({
                                                codeinput2: t.target.value
                                            })
                                        }
                                    })
                                }), Object(s.jsx)("audio", {
                                    src: Gs,
                                    id: "win"
                                }), Object(s.jsx)("img", {
                                    src: Rs,
                                    style: {
                                        position: "absolute",
                                        bottom: 0,
                                        width: 900,
                                        left: "50%",
                                        marginLeft: -450
                                    }
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        visibility: i ? "visible" : "hidden"
                                    },
                                    children: [Object(s.jsx)("div", {
                                        className: "lights",
                                        style: {
                                            width: 100,
                                            height: "100%",
                                            position: "absolute",
                                            left: 0
                                        }
                                    }), Object(s.jsx)("div", {
                                        className: "lights",
                                        style: {
                                            width: 100,
                                            height: "100%",
                                            position: "absolute",
                                            right: 0
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        display: "block",
                                        width: 900,
                                        height: 500,
                                        position: "absolute",
                                        bottom: 0,
                                        left: "50%",
                                        marginLeft: -450
                                    },
                                    children: [Object(s.jsx)("h3", {
                                        style: {
                                            textAlign: "center"
                                        },
                                        children: "Wat moet je kunnen als detective?"
                                    }), Object(s.jsxs)(ht.a, {
                                        span: 16,
                                        offset: 4,
                                        children: [Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg1: !e.state.egg1
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg1 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg1 ? Ns : Fs,
                                                style: t
                                            }), "1. Een speurneus hebben."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    code2: !0
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg2 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg2 ? Ns : Fs,
                                                style: t
                                            }), "2. Vingerafdrukken lezen."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg3: !e.state.egg3
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg3 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg3 ? Ns : Fs,
                                                style: t
                                            }), "3. Sluipen."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    code: !0
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg4 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg4 ? Ns : Fs,
                                                style: t
                                            }), "4. Code kraken."]
                                        }), Object(s.jsxs)("div", {
                                            onClick: function() {
                                                return e.setState({
                                                    egg5: !e.state.egg5
                                                })
                                            },
                                            style: {
                                                height: 60,
                                                margin: 20,
                                                textDecoration: this.state.egg5 ? "line-through" : "none"
                                            },
                                            children: [Object(s.jsx)("img", {
                                                src: this.state.egg5 ? Ns : Fs,
                                                style: t
                                            }), "5. Onherkenbaar zijn."]
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ms = i.p + "static/media/corner1.b48a9b2a.png",
                Hs = i.p + "static/media/corner2.b2e7c19f.png",
                Js = i.p + "static/media/send_email.ac2991f3.gif",
                Ds = Rt.a.confirm,
                Vs = It.a.TextArea,
                Ks = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).handleChangeComplete = function(e) {
                            s.setState({
                                color: e.hex
                            })
                        }, s.showConfirm = s.showConfirm.bind(Object(ve.a)(s)), s.state = {
                            drawing: !1,
                            sending: !1,
                            mail: !1,
                            color: "#000000"
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "showConfirm",
                        value: function() {
                            var e = this;
                            Ds({
                                title: "Nieuwe Email ontvangen!",
                                icon: Object(s.jsx)(vs.a, {}),
                                content: Object(s.jsxs)("p", {
                                    children: ["Van: Detective James", Object(s.jsx)("br", {}), "Onderwerp: Helpers Gezocht!"]
                                }),
                                okText: "BEKIJKEN",
                                cancelButtonProps: {
                                    style: {
                                        display: "none"
                                    }
                                },
                                onOk: function() {
                                    e.setState({
                                        sending: !1,
                                        mail: !0
                                    })
                                }
                            })
                        }
                    }, {
                        key: "send",
                        value: function() {
                            this.setState({
                                sending: !0
                            }), setTimeout(this.showConfirm, 3e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                id: "window",
                                className: "MINI2_Mail",
                                children: [Object(s.jsx)(Rt.a, {
                                    title: "Detective James zoekt hulp",
                                    visible: this.state.mail,
                                    width: 750,
                                    footer: null,
                                    children: Object(s.jsxs)("p", {
                                        style: {
                                            fontFamily: "Permanent Marker",
                                            fontSize: 20
                                        },
                                        className: "writing",
                                        children: ["Beste toekomstige helper,", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Ik heb met veel interesse je email gelezen. Als detective heb ik wel hoge verwachtingen van een nieuwe helper:", Object(s.jsx)("br", {}), "Een nieuwe detective moet goed kunnen zoeken en goede ogen hebben. Daarom heb ik hier en daar wat raadsels en opdrachten verstopt. Hopelijk worden deze allemaal gevonden! Elk raadsel draait rond een eigenschap die ik van een goede detective verwacht.", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Is een opdracht geslaagd? Vink deze dan af van mijn \u201cdetective eisen-lijst\u201d.", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), "Veel succes!", Object(s.jsx)("br", {}), Object(s.jsx)(M.a, {
                                            href: "checklist",
                                            style: {
                                                color: "black",
                                                fontSize: 20
                                            },
                                            children: "Bekijk hier de eisen-lijst"
                                        })]
                                    })
                                }), Object(s.jsx)(Rt.a, {
                                    title: "Email versturen...",
                                    visible: this.state.sending,
                                    footer: null,
                                    children: Object(s.jsx)("img", {
                                        style: {
                                            width: 250,
                                            marginLeft: 100
                                        },
                                        src: Js
                                    })
                                }), Object(s.jsx)("h1", {
                                    style: {
                                        color: "white",
                                        paddingLeft: 20
                                    },
                                    children: "Contactformulier"
                                }), Object(s.jsx)("img", {
                                    src: Hs,
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        right: 0,
                                        width: 250
                                    }
                                }), Object(s.jsx)("img", {
                                    src: Ms,
                                    style: {
                                        position: "absolute",
                                        bottom: 0,
                                        left: 0,
                                        width: 250
                                    }
                                }), Object(s.jsxs)(ht.a, {
                                    span: 14,
                                    offset: 5,
                                    children: [Object(s.jsxs)(jt.a, {
                                        children: [Object(s.jsxs)(ht.a, {
                                            span: 12,
                                            children: [Object(s.jsxs)(jt.a, {
                                                children: [Object(s.jsxs)("p", {
                                                    style: {
                                                        marginBottom: 5
                                                    },
                                                    children: [Object(s.jsx)("b", {
                                                        children: "Aan: "
                                                    }), "help@detective_james.com"]
                                                }), Object(s.jsxs)("p", {
                                                    style: {
                                                        marginBottom: 5
                                                    },
                                                    children: [Object(s.jsx)("b", {
                                                        children: "Onderwerp:"
                                                    }), '"Detective hulp gezocht"']
                                                })]
                                            }), Object(s.jsx)(jt.a, {
                                                children: Object(s.jsx)(M.a, {
                                                    style: {
                                                        margin: 10
                                                    },
                                                    onClick: function() {
                                                        e.setState({
                                                            drawing: !e.state.drawing
                                                        })
                                                    },
                                                    children: this.state.drawing ? "Tekst Schrijven" : "Tekening Bijvoegen"
                                                })
                                            })]
                                        }), Object(s.jsx)(ht.a, {
                                            span: 12,
                                            children: this.state.drawing && Object(s.jsx)(fs.a, {
                                                color: this.state.color,
                                                onChangeComplete: this.handleChangeComplete
                                            })
                                        })]
                                    }), Object(s.jsx)(jt.a, {
                                        children: this.state.drawing ? Object(s.jsx)(Cs.a, {
                                            brushRadius: 5,
                                            brushColor: this.state.color,
                                            canvasWidth: 800,
                                            canvasHeight: 330
                                        }) : Object(s.jsx)(Vs, {
                                            rows: 14,
                                            placeholder: "Beste James,"
                                        })
                                    }), Object(s.jsx)(jt.a, {
                                        children: Object(s.jsx)(M.a, {
                                            onClick: function() {
                                                return e.send()
                                            },
                                            type: "primary",
                                            style: {
                                                margin: 10
                                            },
                                            children: "Verzenden"
                                        })
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                zs = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Detective Speurtocht - Festiviti"
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "checklist" == this.props.match.params.phase ? Object(s.jsx)(Ys, {
                                background: Qs
                            }) : "mail" == this.props.match.params.phase ? Object(s.jsx)(Ks, {
                                background: Qs,
                                next: "checklist"
                            }) : "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: Qs,
                                next: "mail"
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: Qs,
                                next: "mail"
                            }) : Object(s.jsx)(A.a, {
                                to: "/overview"
                            })
                        }
                    }]), i
                }(a.a.Component),
                Ts = Object(A.h)(zs),
                Us = i.p + "static/media/background_start.b8d6c36a.jpg",
                Xs = (i(639), "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARYAAAESCAYAAAA43PpZAAAACXBIWXMAABYlAAAWJQFJUiTwAAAfuklEQVR4nO3de4xcZ3kG8OfMnLntzN59X29210lsU2/qDSGQxIANKYirCIWWUqQ2SFSqqqpNaaUq/QMQVRVUhRaprdqqqA3/FKqiJq0ppUCaBAiJCASH4GAnttfr9SVee29zv5/qPTNnd2b2nNm5fGf2Ms9PWq3XHs+ZObvn2e/yft/RDMMAEZFKHp5NIlKNwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLldJ5SWnFs5ASAKQADAE5U/MsSgKcBPIFnr1zkCaP1aIZh8CR1s2MjU+mi9vlAuOd+bc/+HvQPAj3htSckmQBmLwDzc3+EZ698qdtPG9XHYOlip46OfWYynP+crkHDez4K6L61JyO2BOSypT8P7QKe/C8glfgknr3yWLefP3LGYOlSJw9PSFfnKZ8GHAnnMbpvBzB5F9A7UDohC3PAD590OjnLAMbx7JWlbj+PZI9jLN3rQXnnOQM4Fdex48YNhH74XeDt7wVC4VK3x1k/gAdOHp6Q8ZbPATg+Fcljt78Y14C/82n4AkOnu3FWqHtNVb7zs0kvkMsBp54v/YXur3tiLmc8vystHgkV+frVpBd+DRGfhj8FMINjIw91+wnuZgyW7nW08p3PZjxm6wXzczKGAtxyoO6JCXmMt1R+rVf/JPUB+GscG3kCx0YGuv1EdyN2hbapC3fd8rHTCe8bAEh35ekPnpled5p4NuPFgWABeP0yMHEI8PlKrZgG9Httx+o+JGPEODbyAJ69cqrbvyfdhC2W7ebYyInsfSOxaF77GoDPAvgXANMnD088ffLwxFS9dzuf00p/uHC29Llv0PGxOUOr+no0UHB66JhZA3NspO6xaXthsGwnx0ZkQPYpGevIrW1AyFjIT08enrBqUJ6pfcDr2fKPg3SFnnuy1C1yEC2sBsuwr4hhX93ZRRnsfYzdou7BYNkupLtRap2Y9viLTm/sD08enpBuScLuH1daLT4/cOiOhk7OoZBja6WSjOlwQLdLMFi2g1I34zGMTsAsdJs4hNFA0WxJODhaOytkmc+XfySkAnd4l+PJuVkOIAmwdVorlR7s1m9Rt2GwbHWl7sVj2LO/H0fvKVXPHnmjGS53RgrwaY7vb5/dXy7nnf9DJRljkeeeDDfUWrGMbc9vAtVisGx9D8HnO4qpe6rfyMKcTAnjvr5cvXBZI1ksP1hmhk6/6Pi4aF7DwZ6CeQyiWgyWrezYyLg583Pg8Oo6HynFf+l5YHnR/LJPby5colaLRf5/+TnsHiPdLHNqujkvde33qsswWLa2h8xaE6k5EZenS+t7Zqer3lSz4bIygOsgVtDMblYLuHCxSzBYtrYp7Nlfaq3IFLFVjm+jmXBZ6Q7Vea4WukAvcbuF7sHK261tCj2R0huoEyoWCYTjAzn8KKavdnlspNYJll77KltHy3ktfiHt/dvLpRXV5qv94JlpLlLcxrhtwlZ2bORpDO86blbITp9t+I1YK5pXCuJqyPjJfX1523+Tn5b1Gj3S4pHnlg+nblXQY3x1PFh8+PYXL81sp28JlbDFsrWdwvzc8XoVsnakO3R3bx6nE15cSHvXPCJVcI4Op3+RsJIgkeer1xqyFAzt4/vDhQfweOR95vv4cJwtmG2ELZatrDQrdKpcMt8SWdUsrZdaHxzONvR08zmP+Rzy0YxDPQUclIrd96SASfNYM+X3cqq8vy7DZgtjsGx1pVL+x1HuglitDZ9mmGMqjfhZXMdMTTAc7885/n+rdSJ7uKw3HmNHpqmPlAvrij0GPL8XXfuoZQ+w6LmO13xLSGuvI2w8Ab/xOL54k12nLYDBsoWdPDwhLZaHvBreWzBw0OmdyAxOj7ccNl4DPk9pm4OQ10CPxzAD6cnF6v1uZQaptlRfFgi8lvRiOu2FzSLHdcnYzWRPAX1H7wRGDwDRxdL0+AeSgHSf5jzADS8w5wUyDoEVKeYxULyJsHGWYbN5MVi2qOffOvoXN27qf6bi1UuAJAoa0hVLi1a6KhV+Gtdl57imnlvGc2RLhQOhIkI7d8KsEA5V3AWgtDl36y8+YAAT+TjemfoeeowX2I3aHBgsm93jkRPl+/xMIandjeeDR5IvBMZeiNefMm7XXb157KtYIS0tlG8t1N+u0iKtIGtxornKWhYzykpp2eVfQkQK+eTv5GtZNtDojFZfEdhVAHaVP+8sAP2OCy05ZrOBGCybweORgfJq4ylz9/vVz7aL9uL/1If4DS9eiLkzqffmIQ27d/SXNnry+4FLF5BLJvD9ZZ/ZsrFjBckOvVg9NiMFfG96W2mpwdmXV/d4kdXTb3sPcP0y8ML31z5jZYiM5kt/DrT9s8qw6RAGSyc9HqkNjnFrM+qmPNoP2SIhevkKLsSK5kBqK2MedmS7ham73gDcPln613wOOP0Tc5nANxf8KJSPI+MlO3wGhvUGtk2Qro9dd0e2eLDGWSQ8RgsqQ6RRDBsXsI5FterWh3WrUsfWR9NkYFMu1KP3oO8oMCXdiumziM4vmYOw1s5uyYKGpGMvwdlK10VIa0IqenM5c1pZQuVIT94cL2mK0xjK/PXVPXXvy5RCpfPGyh8fKm/lKd9Dhk2b2GJpVan1URkcVkuk5ZqShszqwHcngHvvr360tCzkt/98ucvRDlnUKF0VeZ5yKFjFdDJN3MKqZnuVLZmPJTYqWBpSLOJ6bAFn+n8nfkLB0217bLGspzR4agWHNZB6tL0nbVO+zs75IZv7Ljfp9bOvVW1tKa0Vq0K3zpaXzatsyXSu69OQfBbXUwlkk1FEkjEMJpaxG8Bud39rbB8MFhvZr0Se9/fil6EhtOleHLB2nxS5v/KPvtfetG0FWd/zQsxvjp0kC6uLEs16GDc2drIGajdIoYDFZBTxihARuzfsBW0DDBYb8aulm3H5egA9rGX8EcS8AezYVC9SwsS6z7Ls9qYoVMTuvhzmNWA+Vb2O6M29LnVV7mps+YAKEiKZJOLJGPyxBexOJ4BCHnKfE+d7nVDTGCx15JLyYQRSNxBAOWi8QcAX1pb1HgQ1rfT3HSEl7lEPMF3+liXjq8Gi6v16DLzcl8b5gQzuuN2Dtx81EL2mQw8amDsHXH5Jx46Ujl0ZhT8243lrrZByDJGNw2BpQilogPSCYXa1zZDpkQ8tp/cAmgc+JQeSAVoJknol7jfngN37S3+us5t+IyRQzkQyONubwcBuA+97i4ZwuNTl6dtbaqWM3w1kpwp48cU0vnsRGMx5sTutI1zwYDDrNb/2tbBuCBd14G/6SsVu0h0aLX9usmtkGEhl01iILyGfWMZYOg5kMwyRjcJgaUMhXfpILxhmoFhBo/do8jmvedY5vxIWEhpmkJT/fGPtNga2Fiq2SpAKVpnFcdij1klloBgBA/e+RcP+Eedw8PuAe96i4Y5J4MyrBZyfLqy5A2s470GksFr2vyu9egoSehFDWS8Oxm0aejfK7/10+WsZzLWCpqa2xSFEZDxspKkTQK7hdLONhUfCSk5KVdDkPUXtNZ8HsvHR7DoL7Rp1/L2r3SEJGik0a4Bc4GcjGVwIZ5H1GDh0ELhjUjODo1mXrwDX5wwsLgJzN9b+Z59Xmgwe7E/4MbroN4OnUWZdTl7DUhD5mxlNGzyYNgK3JvW0uuGkpk0+GndvHcU2whaLi6wWDRYM+OY1T+9zQRh+A/Ab0NqcBMn4iwjITNCd95RaLPLhVOFabp3MhnKYDmdxPVDq3hwYLwVKuI0Z6v0jWNPKyZZbMatBJTmdAZZzpdaZdPHkc0XrrDZEYkmPN2+thYqVfk6NqIbBDQwVahyDpcO0rAZkVy/ElaBJa6WtA+xY4w/W4rvRPLS4hte+msPt0kqRMRZZ15OvHgSVlomEyOVQzvywqAiUehxbPrJgsH/1Neaj2lzuNd3zg2/0DafTntKbj/FncjvgN3GD2QWNsa8AbTwPbXfBsRrVHzGw49fS+M5TGQzPp+CbvwRzlCFUCpRFfwGLvtVmkdWy2L+/zoXvIpuCM3m3u4Ac0mneLGK7YbBsMhI0aX8eqUganizgu7YyGAxPTSAMDgDv+rCBy1eyWFw0zC6IjHVEwsD+MDDh18zH7G5v0qhptdO8LDjrPgyWTayYAzLL8lEaS5ZgqZh1Wgkau3GOTmGtCNlhsGwhjQaNW6xp3tgidIYI1cNgsfdJAF9yfaVym9wMGtaKUDsYLDaGHk48tvBI+IlcHn+VyeFjoQB6vFtgfHGdoCl6fM631M2mMZOMQo8uYKTTIeLvyyMb5Y/idsLvpoOhhxNLlz4T/mE8pX0ymgS8HhhBP+JBv4GAD72b8kXXqAkajxU03pCWS2cxl4hiKBVHqFxwpmYjqhZ41tuBriwbbbAqWZFUDkhlkTAMxIYj+EdZgNDRF7CFMVjqiIRwLhIykMwA6aymJdLoTaQ1SMVFwI+sXzfi0prxaAhu2jdRYSVobhq++ai25bo0xZx7zUYJkWQW8+mcEUrn4E9kVq6NcMiH3PF/SHzOtYNvQwyWBvQE5MNA0QBSGSCZ0eSzP5XRhpYTpbqQoM+IBf1I6F7s2fRvqMsZ4Z68FgoWggM9emQw7L1+JYrXfnRVTspwt58bVRgsTZCWSjgoHwZy+VLApLOlEvZsTuuNJtErYzF9I0H0HggnipeiqWI0u7n2cekyqSyWUjl40jmjT1olRd2He+4e1XWfZ+Vnf994ab3V6VK4kAIMlhb5dKBfN9Afhhku6axmdpnCt/Viz/tH4A14w7h3TzhxPobkyzfz3hsZ2YyZIeOeTCqLbCqHUDpn6BIiiYx5rOpNazI5PP/t8zh6bBS9A6s9WAmXUNiPUz+YRT63cbvZbRcMFgWCfvkwsOvOQUROVA9deHt9uHkxowfj2g7ul6rMcioHbzqLSCpnoBwishdDQxtvpRI5/PipGbzpHWNV4TK4s8f8O/k3hkt7GCyKBCeH0XPv3qoni/9iCbMnr6Bg7j/NU92ubB44f8OQEGk7oyU4JEAm37wPO0dWJ/kkaCRcpFsUW0pv4Lvd2rj6S4Hw8f1rQiXz6hKyP7iM3YMGdvYbCDZTrFZEUu7qs8ne5obLF1e6N0pIuJx6dhZXL1bfMqgULuNVrRlqDoOlDZrfa4ZK4GB1Nz714hwSz1xe+VrGY2TaulHJnNaTSGN3YfVOG7MAmtsebnMzmwLShVlMlFoijZAL3Y2LXVonteGi+zxmuAzucmlviW2O7fMWSaj0fWAC3uHqH/TEM1eQebW9DCgUgOWEBpnKllmmoB+j4WEf9LS5l0lKdrwtDwRvztuTrJIAMU+QhIi8/PKYSLCy5dFTABopfTPymnmx//ipi2u6KdIilHMVKn/2ezUz0Ncjs3vZgoGbZ66iEEti9I59K//DDJcTYzj306uN3Q2fVs8dT0XzWgkVfb61U222WnaFMfyRUcj65cT5WCh/LTFanI1CKw0wygHjcttl1994fXnr56kiRIIVszNtS17Lmxf73e8cx+ypWTMI/F7A385PsTnca+1Ut4zoOaDvtn1VDxk7ONS5+5NsEwyWJkmYSKhIuFiMbAHRb0yjMK9msE9+00rNjBTkDd4xgJH3r8409f7SAAq39uLKfxeQuhCTwr1Bv47Bit/OMjbjdXFqO1/5c1MIBKEFA9DDQV26E3Nz7g94enUPxt80hui5q0jNLSt9bnm+QiaHgcOj0LbCArFNisHShE6EClCeuh404L11EIP3V09fFzIFTP/rRaSvl463XN7OstxlQsBn7A5WN9yvlL/PbW+0VG6J6NKdKfp8OHriVrMFYdk5PmQ7XlGPvO5Wr1+rZaE6XLLLSSz8fAZDk2MMlxYxWBoUODiI8PGai3w+jdh3LqEYU99Sjty315zCrlSsCZWq1yIzJmn5KK1lMpcZ+A0JmxHP6h5Q1viM7J8SqXzq2oH8mjERm+5MzhzrkDGPynA58ubSxW4XLmb4+YBIQMZCNPPP0o25NlMezW2AUShWXewSLno4iNi02km0fCJthsvA4f1Kn7dbMFga4BQq0lKRFotq/rE+eGtCxTpeb7oAb9Bcq2R2lezI31vVwCh3rWStk19HyKdjtFhzX3ez5L1uiNiTAVSncOkdDOLyK6+bg6mRwGqItMuuJdGzdwia12t2jVSScJl/aRqR0R1qm0RdgMGyDqlPqW055K8lEPv2JVdCBeUuV6XKEKtdSmCtV6pHZj4qu0weD3B1qbkQcSLhIiXyd751FOH+1dd9y+1D2NnvzsV+4yfnMHTkFrOlYgnt6odH92D53DUYeXXfF3mu2PR1bpfQJHYg6+i5b+9UbahI4ZtbLRU72Zmo4/FkLGWo18CeIQMDEaOh6VXpMknQ3Iy3HioSTuGA3DweOLBTw4H+PBJnL5kXfSW52KWroulq91GRi33h9NrjBYZ6zcBRfTxqHlssTZBQqSx82yzHkzEUa2sHCY5kurQgslC0f7weljLgxseFZKxagsTs0vhLtSK1rIu9/7a95gVukXDxhQPmvzm1JGQHufR8c/toOh1PWjESLktnLpuzO7Qx2GJpkNSodDJU0j+fb+l40pro7THMpQTDfYYZOBWDt/D3+zD6wfHyuIj9b3YJkR0RYHxYw5F9Gg7v1TA6pGEwbB8qFrnY5YKunaWxLnanlkSjO8g1c7zhqQNVXSXqLLZYGqCimrYZhR9EkYw3PmXrJOAzp5/Nf5UWjNEfwr5fH0cx5cHgTt1cbPfTZ2ago2DO1IQDmvm5Xda4irRWLObFfnTCDILaLkwzZG9caeFUkuMZhYI5iGuRwV0Z5JXB3naOR61hi6UOI5mPx79zqaOhIoxUg4tnmtC7L4j9HxuXfWJW/pOsu7nvV8ZwaDyE3X1qQsUiF3vtwK034DMv9nZaEsWc/f2TZLq59nhWuFQGHHUGg6WO1Kkb57IXo5v29TVKpsv7f/W2qsI+i9lNafNidyJdFKeLvXJcxO3jyQAyw6WzGCzbnF0NDozqUV3rYncrXKT7Y1SMJMvxpPDMjYtdjrd4eqbqeCgX0kVGdyo/HtljsGxjobt2rQkVmbZe/s50eVyi+mKXMRA3LvbMQswc67C72N04nlWSX3u88OiONQsMyR0Mlg6RatpOkn1iQm+svhu8FNot/8d55G6mzd/snbzYrRL52ilgOV5gKOL4/1Qfz6qtIXcxWFzmtMWCm+w2n7KqdyvXNVkXn1249E60vWZxDatEvnaWxufStLDT8SRcpHXGQjr3MFhcZIWKvrczu5DJ8WSQtjZUZAmCU/WuefGdurDm4pOpWzd+sztVzbrF6Xjr1dZQexgsLrG2WOhUS8WpZdTIEgTpLthdfG6X5Kve7qDZ41m1NSykU4/B4oJOh4ocp/8jt9mGSqPVu9bFJwOtlSRc3PjNLsdrZaOmVm+z6nQ8FbU1tBaDRTG7zaBEbsadehjreJ5Ida198rlrTS8JaLUkvx1ysediqYafIRNtr1hcjpe8tlD1d27W1nQrBotCdoVo0gWRJQF5hTvMWXx7w7YhJseTtUatsvvNLuGy867bXPnNnllKKH/OepyqdN2qrelGDBZF7ArRrG0r3VgSIMfrtdkmU9USBLuSfDcL6TrNrkoXLk63dxsGiwKyGZRTqKjcC9dSL8RULkHodEl+p8n7k+lou+l21rq0h8HSJqkZqd0MyipEcyNU5HidDDG7Evnt1G1wquVhIV17GCwtcroLol0hmvC1eF+hSk7HW/rqq66EisWpRF4uvMqtCjrBzSpdu+n2wckxeHxebi/SJAZLC6yakWYK0do9XuTdtziGWCe2yXQqkZcK3XZ/swf6Gt8mQqp03WhJmO/PppbH39eD/oP7Dyk/4DbHYGlSO4Vo7Ryvdq1Rp/fexTol8u1c7B6fwx6aDtwqyXeq0tV0D1ssTWKwNEFFIVoz6oWYHK+ToWJxuvisbkOnSuTdqq2R9yfh2amq4O2KwdIgp0I0t/bCleMNfPzgmlBpdS9clZwuPuk2uL3+JnFttdvkZkm+G7dv7SYMlgb4x/scC9Fc2bZS9zgeTypqNwunQrrae/6olF2svmeJmyX58v4Sszc3zfneShgs65Cakci7bnGtEM2OPhzsXIi1ye7ic3O7y0I271hb4+/vUX68+OwNRF+9elb5E29zDJb6TvlGI88UE7mV9rcbhWhrVNyvQ44Xc6l6VxXz4utgla5VuFdbWzN4xJ2Ns/OpDLf5bxJHu+sYejgh9+A4IY/IPHvwy96BwCcSz14NulkzUsnNwjfVrC5R78SelfsqW9tdujFeIc+XS2TW3MfZmp3i+MjGYoulQYFjr35KP/JyqDCffgeAZ9w+nlWj4kr17l3urIfZqO0uXd4B7yUAj6l6sm6hGUZrd6HrdguPhKcAPATgtxs5FX3PRaA3WH1rHPJh6ciCK9PJUr3r2dWPpZ8Zrs18WGMslS0JIdsVyMriWnJ71WvPDdg/WY3gcA57762+mZvMQtkNGDstNFyHnJCnATwhnycfjfOG8C1gsLRp4ZHweDlgHgTg+Gu5mWDJ7yggek+sgUc2TgaDZbGkVO/mlgwzWFDnYm+XzNbIeqJGLvZ2gwV1wkU2rlo+d83xvtFlM+UgeWLy0fjTyk9GF2KwKLLwSHigImDGap+1qWAZziN6b1zZa6sttKsMFrT+m33949ZpScQuXl+52FUEi3W82pvEo6JcvyZc/tNqmbBVoh6DxQULj4QfLIfMUevZNypY7Kp3a4MFjf9mb/74DVzszQSLHipg9P6Fuo+xG9PJLsWTi6/M/ntFF6f9m2OTIwaLixYeCcuM0ucAHN+IYJEw6X332NptK88sY+EMGv3NroTdxW4dL3Xd03CwiIkP3Fj3MTJ46x+IpPLJ9I+Kmfzfj/3++X9T/qbIEYOlA2QcJvJK+KT/gm+ykaOpCBanvXel0C56ehHzUc3xYpd9b2tXMatgdzyZ0bnyf5dx+anGi9vqBMuy1SIpd3HYKtkgDJYOyj069lHPTc+j3p/kx5B0XtHbbrDIXriyzYJT9a5khgQLyr/Za/dUkYvdbn8SFexWQi+fy+AX/9z4YHVNsLxUESQceN0kWCDXQb4/mfk6gK9nvzh+B17JP6pfxDs9abVL8p22rZRQsasWlhkhCZDKi92qmnUjXKzp7arjeZoup+LA6ybHFssGy/zGzi/ri/pveuOekPVKWm2x1NsLt7LQrrLFYrFrSUjLJTb9uiu1LrKuZ+DwqBli0Qs5vPJl52N4g8V8oD//c2+w8K0T//v6w8pfDCnHYNkk0p/Y8ZC+qH9WX/YOtBIsdttWOi0JsAsW1FzsldwupCvkNPz489W3K/H355f8kfzT3oDxtbd/83UOvG4xDJZNJv1bO95q6MYXUrenjzX6yurtvWtXvesULKhTNSsrmGWxoWpyPCmke/ELUfSOacv+fuOFQL/x6am/nX55y33zaAWDZZOqKLh7yKmi19zQ+8TImm0r19sLt16woHyxS+2JohL5eqyB18cmH42f2pzfCWoFg2WTKwfMA+V6mJWK3nrbVspmUPXWGa0XLGiiarZJXIfTJRgsW0i5ovdBT6//eO+7bml5791GggXlcJFuimw5WanJQrqZiiB5Yot/C6hBDJYtKPU/45/yjUb+XN8T3mO9etkLt9FtKxsNFku9qlmHcHmmYlEfWyVdiMGyhaWfPPBW73Dosez55Vub2WGu2WBBnarZcq3LTE0XhxWvXY7Bsg00MtBbqZVgQU2tSz6VNdfh5KKpvzzwx5e+2cWnn2wwWLYRp4HeWi0GiznwGto18KI36PvK+B9Mz3T7+SZnDJZtauGR8APlFszx2nfYRLBwHQ61hMGyzZW3bniwcgvNdYKF63CobQyWLlHeQlO6SA9kcuivCJaZiiDhdDApwWDpMjIOk83h0zej2kJ5BocVr6Qcg4WIlON9hYhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiJRjsBCRcgwWIlKOwUJEyjFYiEg5BgsRKcdgISLlGCxEpByDhYiUY7AQkXIMFiJSjsFCRMoxWIhIOQYLESnHYCEi5RgsRKQcg4WIlGOwEJFyDBYiUo7BQkTKMViISDkGCxEpx2AhIuUYLESkHIOFiNQC8P9a3D90eqHrVwAAAABJRU5ErkJggg=="),
                Ps = i.p + "static/media/g2.fcb2bd7c.png",
                Ws = i.p + "static/media/g4.06590f45.png",
                Zs = i.p + "static/media/g5.14421c93.png",
                qs = i.p + "static/media/g5-grey.3f42755a.png",
                _s = i.p + "static/media/top.9c5d9035.png",
                $s = i.p + "static/media/bottom.efd43880.png",
                en = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).showGiftHint = s.showGiftHint.bind(Object(ve.a)(s)), s.submit = s.submit.bind(Object(ve.a)(s)), s.state = {
                            start: !0,
                            answer: "",
                            showHint: !0,
                            showAnswer: !1,
                            hints: ["Heb je zeker je hints goed ingesteld?", "Heb je zeker je hints goed ingesteld?", "Heb je zeker je hints goed ingesteld?", "Heb je zeker je hints goed ingesteld?", "Heb je zeker je hints goed ingesteld?"],
                            counter: 0
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "showGiftHint",
                        value: function(e, t) {
                            e.stopPropagation(), this.state.counter == t && this.setState({
                                showHint: !0
                            })
                        }
                    }, {
                        key: "submit",
                        value: function(e) {
                            e.stopPropagation(), this.state.answer.toUpperCase() === ["RENDIER", "DENNENBOMEN", "MUTS", "POPPEN"][this.state.counter] && this.setState({
                                counter: this.state.counter + 1,
                                showHint: !1,
                                showAnswer: !1,
                                answer: ""
                            })
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            console.log("mount");
                            var t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user"));
                            console.log(t), fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "GET",
                                headers: {
                                    Authorization: "Bearer " + i.token
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                console.log(t), t.hints && e.setState({
                                    hints: t.hints
                                })
                            }))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                className: "CHRISTMAS",
                                onClick: function() {
                                    console.log("hide"), e.setState({
                                        showHint: !1,
                                        showAnswer: !1,
                                        start: !1
                                    })
                                },
                                children: [Object(s.jsx)("img", {
                                    id: "cross",
                                    src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAACJCAYAAAD+DdCNAAAACXBIWXMAAAsSAAALEgHS3X78AAAD20lEQVR4nO3dzY3TUBSG4QNiiUQ6IFMBQwVkKgAqYKYCwoI1mTWbUAGhg1ABmQrIVEDoIEiwDoo41kTMXz7HP+fe+z4SSyRjvdjX9nH8YLPZGLCvh+wpKAgGEoKBhGAgIRhICAYSgoGEYCAhGEgIBhKCgYRgICEYSAgGEoKBhGAgIRhICAYSgoGEYCAhGEgIBhKCgYRgICEYSAgGEoKBhGAgIRhICAYSgoGEYCAhGM0wpY1tA8HsZxvKzP8UjWDuNzGzpZm9ib6hXXiU/z+xtldmNjWzp4lufysI5rpjD+VFtA2LgFPSlYGH8p1Ybkcw/4zNbGVmbyNsTGSln5JGfuXDOmVPpQZTXSZz6hGVdkoa+GXyD2Kpp6QjzKkvap8E2JZklRDMyEN5FmBbkpdzMEMP5WWAbclGjsEM/DJ5zOmnebkFc+qLWi6TW5JLMNzO70jqwVS383mS3JGU78NM/HY+sXQoxSMMYwc9SikYbucHkMIpqVqncDs/gOhflR37WiXK/ZS1mV0G2I4mjH30VBL1lBR17GCQ0VFuUOcvRTslbdcpczP7xqI2pihHmOp2/ocA24I7RAiGsYOE9HlK2q5TFmb2mVjS0ccRZuhXPtyhTVCXwTB2kIGuguF2fibaDoaxg8y0FQxjB5lq4yqJsYOMNXmE4S3CAjQRDGMHBTn0lPSRsYNkPa6z4YceYd6b2R/urSTpd52NbmLRO/HT0pf09yHu09RV0tofIj43swv2er6avqxe+tXSazP7WfrOzVFbT6vnfpf33Mx+lb2L89LmeMPa1zfHrG/y0cU8zMrXNycZDVAXq8sBqoUfbc44TaWrj4m7mV+Gn+eyE0vS14hmtb45MrOvZe76NPX9msnKh6tOuAxPQ5T3khZ+mnrH+ia2aC+yTT2cTwG2BTeI+DL+2h9mHvGYIZ7oL+NbsAHyS485B0v/zylJIZjKJMAYxYU/KytWSj9ZxhhFAKn9xt165zED65sepPqjiAs/NZxx/6ZbqX/NZMYYRbdy+PzN7hgFjxlaltP3knYfMzBG0ZIcP7DFGEWLcv4iG2MULcj9E367YxRchjeglG8+rvwynDGKA5X2kVDGKA5U6ofOpzxmqKfkL+PztmYNJQdT4W1NAcFcme9chrO+uQXBXMfbmncgmJutGKO4GcHcjTGK/6Q0otm37U/JjnytUyyCgYRTEiQEAwnBQEIwkBAMJAQDCcFAQjCQEAwkBAMJwUBCMJAQDCQEAwnBQEIwkBAMJAQDCcFAQjCQEAwkBAMJwUBCMJAQDCQEAwnBQEIwkBAMJAQDCcFAQjDYn5n9BbGDilyU2MrdAAAAAElFTkSuQmCC",
                                    onClick: function() {
                                        return window.location.href = e.props.back
                                    }
                                }), Object(s.jsx)("img", {
                                    id: "top",
                                    src: _s
                                }), Object(s.jsx)("img", {
                                    id: "bottom",
                                    src: $s
                                }), Object(s.jsxs)("div", {
                                    id: "gifts",
                                    children: [Object(s.jsx)("img", {
                                        id: "gift1",
                                        className: 0 == this.state.counter ? "gift movinggift" : "gift",
                                        src: Xs,
                                        onClick: function(t) {
                                            return e.showGiftHint(t, 0)
                                        }
                                    }), Object(s.jsx)("img", {
                                        id: "gift2",
                                        className: 1 == this.state.counter ? "gift movinggift" : "gift",
                                        src: this.state.counter > 0 ? Ps : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARcAAAESCAYAAADXHpFnAAAACXBIWXMAABYlAAAWJQFJUiTwAAAgAElEQVR4nO2d3Y8c1ZmHz4zt2MZ2bIzNhwnYJEACiYKJVsNG68U21sIqSoRXgwR38UrZ212k/gOWSHs7Crnbi0hLLnclRybhgqwUbGOkhJaS2AtJCCHEJBBCYmLjz7HHM149Tb2jcrmruj7OW909/j1Saez+qDrVM+fX79d5z8SVK1eCEELEZlKfqBDCA4mLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMIFiYsQwgWJixDCBYmLEMKF5fpYlyadTmdbCMGOU8lxdGZm5tT1/tmIdpi4cuWKPuolRKfT2RVCeCaEsDPnro6FEJ6dmZl57nr/rIQvEpclQqfT2ZCIyr+VvKN3eL1ERnghcVkCJMJyKITwQI27ORxC2DsK7lJide3q8xTu3IEhDEk0QOIy5vQRlu8mbs9Ru7PkNTZx94YQtmbu+iOeS7+nLTqdDuPZF0J4fMAlGeOzyb0pbjQGSFzGnE6ncyiJr3yUWCCHBt1Rp9PZl7hQaZFpVWByxhCSmJCJx7ac53dJYEYficsY0+l0mJz/ntzB7jLCkqbT6TydTPD1ycPuApO4Ps9lROOdZBwHsqLR6XS2JxZLOkAtgRkDJC5jSpJqPpoIw7dnZmaernMnyXkOpNwqJvr22BM3cc0Qia+nHi4dVE6E8Fuph745MzPzTMwxirioiG58eTplcdSeZDMzM8dnZma2J7GakFgUUYOnifVxKCMs305ErFS2amZmBmF6PvVQLTEV7SFxGV/2JSN/PoaVMTMzsy8lMDsTS6ExKWExywjX65+wtGqMOz2m9YmLJUYUicsYkkxYs1qiWRkZgXkmcWVqkwRtD6XGeiyxVmqNGSsrOYcYA1T+P56kJ/3xunfQ7XZtecAiTz755PHvf//7H1y4cOGWTZs2Hep2u1cJwbvvvrtrcnJydsuWLT/JnO6qYPLhw4dvDSH8V+ohRKuOtZKlkeCJ9pC4jCfbU6O+Rly63e6G5DUbUq81F6Jfevcq9uzZE374wx+GEydOPHDu3LkH1qxZs/j06dOnez+3bNnyWOZtlrUKp06dCh9++OHiE3feeefZL3/5y73AcbfbNRE6auudpqamSglOEnxOj731uhxRHonLeLI4qe655569iZiYFZK3pqg0iMlDDz0UXnnllfD666/3/l2Wubm58NJLL/V+wrZt23j/2tS4rhlft9sNSaXw8eQ4lCM6z6b+/V2lokcbicsY0e12e1W2u3fv3nnw4MHewG+88cZvedzB7bffHjZv3hyOHz8evvCFL4S09VLEkSNHssJS9pI7U8LTs4K63e47iZAePXLkyKpUFe9HyhaNPhKXEabb7W5PyvV3pb/xb7755rBixYreJP7d734X7rrrrsKbWL78418zNU3z8/OlbxhheOGFF/paL+fOnbtGcHjdX/7yl96/KwpLHrhAW998883H//jHPy6+5Itf/OKL99133/ZsnEeMFhKXEaPb7e5NBGVvKstyDQjKm2++2ZvMf/7zn8Mdd9yxKCKTk5O9ox+XLl0KFy5cKHXTiAcigfXypS99qSdoeRBn+cUvftF7dsOGDTGEpSdgr7766qJgwdTUFPf+JLHnbrf7UZIt4zhUNnYj2kEVuiPAIEFBNEwwli1b1jvOnj0b9u/f3xOLT3ziE+FrX/tauOmmmwbeDNbO+fPnS980Exzr5fOf/3zPPfrlL3/Ze3zr1q1XWS4EgBEYHnvssccKhajMNbGCELU0ibDkvW1RaKamprSCegSQuAyJJAj7dFIMt5gBQUAQExMRjjxee+218OMf/7j3LALz6KOPhltvvTUsLCwsvuPy5cu9nzyGS5R+rixmPXz1q18Nv/nNb3oCtWXLlp6FAlhQP//5z3v/Rljs8arkiQpChSVEHKgk7yTrl56VNTM8JC4tk9SWPJO2UhAUJhBHkZgYJhQcZHTefvvtxefuvffenoXRxHLIYtbLjh07Fi0fgr0c/P8HP/hB76dZN3XO309UgGsgLGUDyn2gvuaZqamp2vVAoh4Sl5ZIWSqL9SBYKCtXrlyMleSBmDB5ERMskezvDMsiPTERFkQGF6LBpLwK0stYR5/61KeuEhdEgVgL1gpWSxWKRIVxP/jgg1WslUF8U5ZMu0hcWiCJqTxnlsrExERYvXp1oXVhgmKiMgjcEtyTLExOjkEZpUGQlaIeZfv27b3xICwIilktVdwhAtCM9b333rvmOUQFC6jpeHMgLrNPMZl2kLg4klgrV7UZwEq54YYbegLTDywTgrRWK1IFJisig0WQBSFDZD772c/Wjol873vfC+vXrw+33XZb7x4IKmO1YCVhZQwCgeJIZ38ME8CIlkoRvaUIsmJ8kbg4kQjLVX1tcSuwWPqBqFy8eHExANsEczX6iUxIrAMEgYlcxW0y6wiBWrduXTh27OM1hGSq8qwwxsB7EJWsYFqqO6b7VoFewykJjB8SFwf6CQtBWyZkFj7/2dnZnrUSGywZJnU/98PAimFyU5g3yKIh1UzKedOmTeGTn/xkL5DcL4iLiLz77rs9UeE9aRAhrsdR14KKiATGERXR+fBcthN/v6AtVgoFbXXSw2WweAuTnTiHHekJz78tjYz1QCwFoeHIWhOIAQHokydPLoqhxUY4D+dGVLJuj7lkBINbcnvK8kBSG6O+MA7IcolMt9vdl2k10GPVqlW9iWlgreAGDQPEBoFIi02/GA+igKDceOONvX8jOL/61a/Cn/70p97ziA/P8/6sC8bjvH5ELJRB/PPU1JT2b4qMxCUy3W73eF5LAyuQsxqVUQJxQCQQHROLrEtTBG4SB1XCHAR8i8BaQ2BjwedZ93yTk5Pnn3jiidaDPksdiUtEXnjhhR0TExNH6pyRiRFTcDhfDHcLkcG6ITPUD7Je9913X6niv1gMEq4yYEmmx7x58+YHp6am1B8mIoq5RGRhYeFv/vrXv0Y7IZYOk6AO6ffVzcQQO/n9739/VQaLCcn51q5dG1ipzJcTDaSofxkE7617Py2gDneRkbhEZPXq1Qss6AtJ2jlmCX7bkGVi7ZJBoJcUdHrhI9YMwkIQl0WF43y/58+fv1stHOKiBt1xOc+3Ose4C0vSHa4XjN29e3d45JFHrsn00ObB+NnPfjaMoUajTtGiKEbiEpHTp0+/FaMIbpikhYVCO8r6yfr0I52upmiP2Mw4wu+M391Y/+JGEIlLZKyB9TiCOJiw4OYMKuknmJt+De8dRwtgnH9no4zEJTJkV4ZVv9IERIH2DWFwU6arwFUygeHe0825xwHGmrdMQjRDAV0HTpw4sdjnNotVy1oRWxqL11iFbJsQM2FsttanDJY6x30KydojamMQGHq/lM1S2fojPhODtprexXf2uxA+SFwcoL6EP9q0wBS1GTCsbJ6VxlYyX6Xzfl0YGzETrsmkLku6aA2BYZz0lrE1SGW6x6VbRZCRss8AgSKI7CUwJixeSy+ExMUNExhqO+g7a5Mmvc6mn3Vj5fgEVpnwHFgTdUTGKm7TZj8pcivNN2xy4940yXJxXwSArS0mbhaCwdj7WWI8j9hyf9YAnPtn2xRb/OghLqznoh5JwuKLxMURW5UcUt3hqBUpmsDmEvFaJpq1T+BcTFJzQfKw7m68flDsg0nNtXitrVYeBAJX1OCb57E4rLcMIoNY8LgtpOTftlrbhNPWOZllZ4/HBDEheHvmzJnh/3FcB6j8PyL79+9ndW1vt7K33npr0Z9nMlEiT/PsOi4OEw5rwGIi/bbt4DniJv1aRpahbMMnxMKsMCqIP/e5zxW+vqhBVD+wVBCV2Kunba1UgbWye3p6WkV0EZHl4kBWWOh5woJFTHG+OVngV0VkmGg0ZCIOgXgwSbAOzALi/7gY5v7weuvPYkFinrPnbWFiuv0C/0agqrhFZdwK691i1zPrhGsxLlsnxHhxFWO7QVyXz3zc64/GEYlLZBCQfsJi8EduIsP6HF6Tt4FZGiY9goLAIAhsm8r/LTvDZC3qlG8iE5KJbNDV377VsY7I8njAtU1obI8jD9cnJKLHPbE8QaIyPCQuETl79uxa9vUx7r777tzO/vzRM8FsIzHaX+a1wDTSAoObYYHTIndpELYtq+0LbVmuslS1dkJiOXlAoJZDdSujgYroIvL2228/YbUfrLupUudBbQzuAlZN0XarJjD8tD65ZrHUBdfEsjUWgC6LR3vOKljmh8+Oz1DCMjrIcolEp9PZMDEx8URIWgvQIb8qZs7bBMGSoXsdbQrS1oHtQGgVtTH2ZbYUednA67DAUrIufhxKJ48uEpd47L1y5UrPVGGr00EbnZXBzPyQZGYQGupU+Jn+hsaVqbvPD1aPgaVVN9tUhzLuEQKCddSCmGxXy4W4SFzisdfOVMdqGQSTKi02v/3tbxffQd8VBM22ha0C/XGtS38dYaHmpW4FcdqlIgaFS2liwv/VBmG8kbjE4/GQZGJiWC2DINuE+0W/WiwXYiU2yREYhAYrxwSHn/3EB1cIcSGDEzKWTEwQCgSSY+PGjb04CS4Yzb5HRETUciEyEpcIdDqdxa0pvCZnGnOJEBMmKuKC2Ji42GQtWp2NAFoPWVLipG157NOf/nRhCwKCpukKV9ou2K4GWBvp1K/tbZ2FXRutHahly0aA/k2CRW0kLnHoicvk5OT769evj+8TZbAJa+ISUoJT5Rx2nvvvvz/84Q9/6GW4EJyPPvoo932sVeK1Bu9BnKrAmC0rlRbFYaLq3PgoFR2HXnfqhYWF/23zomn3q8k2HZyHgHAb7hxg6VClDDT5HgGeH4VBLDUkLnHYlpzlQJt/qFk3ZJyw7Bau2wj0VDkwRh/d2CC3KA62deuhZIuKx9u46Pvvv78YVxnhLTv6giuES4WLZcHoPPcIASX4++GHH14VD+L1ZOaaNNaam5u7/NRTT2m3RQdkucThRlbVzszMnJqenn7u8uXLrpVdaSGxwKi5GeME4sK4CfzSJiIbN0JUrGE4Py0+Y4FoXs8i0apVxWlOnDiRXw4tGiHLJQKISroA6+TJk2c2b9683ut6xCw4zGphsllgd9ygZcMbb7zRE45jx471rBBEB2Hhce6Re+Uxs1AIONOtz6h776TBL126NFr76i4hJC4ObNy48fUzZ8783bp169yuwWpiJh/f3m0GY2PDuLkX3CMOa8tgIJyICiLD8/zEPTKwfEhtV4V0OoJmaXTh8LvVZxqfZcuWXaaAjT9gL4FhUtDOAZdiKUwQs0xMMA3uL536NprEW/i9EK8SvkhcnLAJ7ykwfOu3bbEU1cA0hXQ6woK1cs899/R+pgO45g4iLHXvO90gS/gicXGEiUDJPROyjul+PWExlpCkqS2OEutz4/fApvpF/X9FXJQtcoa1PFguH3zwgRbiFcCiSVygdOA2FmbhSVjaReLSAnxrsuaI0vn0xl/iY7DscFes9iUWuFWICk3o1felfSQuLYHA8I3MHzl1GUXd5q43LGBLq84YICpWC2O7W1iHQNEeirm0DC0S6DBHW0aK4eh2X3Xh31KC1LLtiNA0vsIK7bxm52rU3T6yXIYAPWtpbcC3Kgv3sGRwl65H090qjGl2VRdiKezOWJRByls1TtmAz50JWS5Dgm9Y4guICkVhrJ3ZtGlTT3DsuB6wLW+rVtmmd0+wBlRF4tyvNzDZvNtuu+3X18UHPQQkLkOGNpO4RZj0ITHt7d/Xg9BgUZTNDpmgUDuUzbzxOeaBeGVjLrakYHJyUpaLExKXEcCqTYk/YMlYfACRwdSnDSU/idXgUg3a32hcsIK8vNXQCAKBb7rkcRRZJnwueXGVAmFZEp/jqCJxGTKWpuanbSXCN7NNPFwmGlZzEFuwdTUmMla1WrUx9yhhW7pyj1Tpcp+ISpW6oCLhSVfkEjhmz27hj8RliGCN4BKwDslAZMia8G1O4V3eGhgmYLoojPeRfUJozMpBcCwlO0rYmCwdz31y1AWxyBMXPhc+Q37yuus5M9c2EpchgLtDjIAgJCKC2Y5QZGMrmPmUwmebJPWDyZUVHAOR4SAjg/hYXIfrmmsQY+dExmAuiG0NgqVg17BYUvr+Qs0tYdMUxVv4TBFahGWcrbtxROIyBJgMLAmwWAPf5LgGaYEhu8FkZUIwMaiPKSMy/WDycj2EJfsNjxhwfeI6/TCLyMjuKMCY8goCscgYd55VEcuK6BewDcnYGW/Mql9RHkW0WoaJyjcpxXNpmCA2iRGQbMNtExksGSZslWAkkxyrJW+SEyzNI20RcVSpxWGsRa+3upQma64QzX7CwuO4nAraDg9ZLi3Dt3VeTQcCghVQtP6I1yAuHIgQgd9BSwnuvvvu3PJ3RK3KTotl0+JMbsSjSFzMcmtSPZtNY3NOYlZcO91USrSPxKVFsCAGfZtixpedwMQzOPjmx/pAbLJuC+t1is5XZLX0o6wQbN26deB6HlutTLyHMWZjMmXACuS95maaNYSoVb03EReJS0tYyrkoqIg4MHmJv1TZ5IxzEsfhSAuNddTPsx6qWi1lwX0rs1CQ6zN27hlRrLqDAdYb7mW/OpmqLpyIj8SlBRAWiuTSKecs1oUtJHUfVXdQNExomHi33HJLb5Jzblyn7GTzchtYxlBGXHgNgsLYEAPLZBWBpYJrieuDWOcV4Km1xfCRuDiDoDDJixbVYW2k20fa/stFez0PgmuaJWATEPeDayE2/Nujj+xnPvOZ0u0NqG0x64VxITJWUGfwnFUmIypplzL7WgPLTaugh4/ExRGEBYulKMaCNYGwZK0K3ltXXPhG7+dicE4OxIaWD/fee2/PYuA6TEZEh3/XdSc4N9ct835ExVZEIxpYGowFwcDqGlR5zOvyBFtWy2ggcXGCCVMmZYyw9EvF1m1AzXUH1Y/wzW5Fc0zSfhaAFeOZ2HAM2o+arNSg1LNV53JePh/Eg8cRPNomIAy4VYPuIa/3i6yW0UHi4sD69etvLdNCgImQN2HrVJNiNWC1FMHkLxNrMcHJCk92mw8EgiI1ro2VVgbGwHl4r3HnnXf2BA1rhkbdnDOv+A0xygv+eu5OIKqhCiMHli9fPjDtQXyBBYqxsNjOIDyaUlkmrCx5K5yxfCw+hPj89Kc/7btJfV65v8WSxGggcWkZajJwg+qU8edh2ahBLhgTL+Z1DStaK0uedcE52OjNCuNwndgL+tVXX+1168Oq4R7zXCbFWkYLuUUtwwS37mkxKCssIacbW1OIoWSXMhQxKCaCwJgFwz5DZJ44yGxZdot1ULbo06wY3LdBMSHRLhKXFkFQLEMSgzL1MwYWi4fLkJcOzqOsdcF94WohKLhG6cxZdj/pNEWxGtEuEpeWQFiYKHzbxlr6X1ZYsBS8XIYq/WKqZnKwYkwsKCq0JlKIJPejTeZGG4lLS1hHubyK0qrwrV5GWEKqfcOwaSJwrB26//77+7p/iHZdl+iGG24o79OJSiig2wJM7piL6BCWsr1Q+rVvGAbEmZrUnxA07ics3FuT+1u3bp16XjohcXGmrrDkWRpVhMXch2FjVch1QVRY/d2PJvdHrczy5ctXDv0DWqJIXBxpYrH0W59TRViCgztUdzkC1lOTcThaLbXfKwYjcXFimK5QSMV4YlLnfE2DyQR181LdTVd1V810iWoooOvAqVOn3p2fn98a48xV0s0GWRWPYrkq9SxGU7csrxo3vT6qDgiLWmD6InFxYH5+PsrKuTrCgqXgUSxHzKNqQBaXpYn1htXiVY0rl8gfSfeIQv1IVWEJSY+U2Gln6+JflaZuS941m658RrTlEvkjy2UEociOIOagxttZsFhix1mYiGUWRGZp6raQyckTgKZWizZGawdZLiMGVgLrZqo2q7b9lGNDILlqb5mybR2KKIq1NO3XIpeoHWS5tEzRRE3vZ1R2B4CQZHG84ix13AeEpYlrhmWR16+lqdVi3fiEPxKXlsmzSBAVxMUou2aHb3GPXrhM7jpxlqZB3CCrZckgcRkyxDSYTHW+TbEOPAK4WFd14iwhQlsHPgvP3riKt7SHxKVFstaIbQNSZWVxGoTFK4Bbpwak6fqhojJ/29OpCdndA4QvEpcWSYtIv/2is+RtsB4SC8FjQSKuUB0rKsY6pryG5lhmMayWWCvSRTkkLi1CvMW+ndPxlarEXlpgMK66bkNTdwhBy7t207VJIXH1VNvSLhKXFuGPmzRz2WZR/YK/TDQPYbH9guqAO9TUPcu7dtMV1YYCue0jB7QlsArYQ7lKF7psLAZR8diCFauhSvf+NLhtMYra8lLPMayWoEDuUJC4OIM5Thl/mQ3SsqQtF4TFo5alSoPvftjmaU2un5d6JoAbw2pBWOpuMifqo0/cEawVJo5N3Kp/4Pa+URGWfhZK2X2h8yjaliTWHktyiYaDxMWBVatWrUVU0qZ+nXQz7/ESllCxD2+o2c+liKJeLVgtMWJLRbszCl/kFjmwZs2aTdk/6DpuB6nmEydOuIwRYRl29qQozhMrtpTncgl/JC4tUdVyYUU0WZhY25CkaZJyjgXClmdRIKpNYzlBrRWGjtyilqgiLoiKtVtAXGK6I4hK3ZRzLAbtLR2rqXiZitzLly/XawwsBiLLpSXKiktaWEIiLrHgW7xuyjkkcZAYpIPcWZo23U5DsHgQs7Ozp2J9vuJqZLm0QBlhsRL3rJUSK4XapJYlJMLCrocxxpG3fihE3M8aIS3z2Z09e9YnqCUkLm0wyDS3QrR+25PyXupdqvR3ycKEblLLYquvm4zBKBK4GC0VjJJWS7R+x+Ja5Ba1QNGkRlDICBXte9ykuVFTYQkRtykpai0Ro3udQaC4TPo5hiUm8pG4tEDexCa2grAMKhSr6xo1aZ9gxFrLxD0UuUOxyvxDhaK5Udjmdikjt6gF+i1AzAZui6gT1LXq2yYxGyZfLGsCdyhP5GKV+YcB25Fkrxm7KFBkfhf6PNqlKL6SR9Vm3XX2O8rCxCPOEoOihYkhYpl/qFA0F6OORhQjcWkRLAG+oatOpCqWSwxhidk+k/EU1dXE6LlrlLVaguItrSBxaQliCt5/0LGEhYbfsbI2Re5QiFgwFypYLdyj4i3+SFycwb1AWOr2yS1LjKxQiLyBPbUmReX3WCyxJnmVUn+5RO2gbJEjBG3fe+8992/JWMISs33moBL/WH1xDepayt6/XKJ2kOXiwMWLF88iKmYBXLx4sVFz6CIXhUBp03RzSIRwkLBUmZSD3KEY3fyNol0DsiBqslzaQeLiQLaknEnEH3VdAcibhAQvm5T0G4hKGSuirBgMcodipp7DgLVKWSQs7SG3qCWqbiqfBssnCxmYWMISsxnVIHcoRNjuNc2g4rwsconaQ+LSEnxj1lmbwyRMi4tlhKpMqDw8utwNctFi9WoxqjSDkkvULhKXlkBYiDNU5cyZM4vvIHB7++23R2nb6CEsCN6gscW8ZpW6liCXqHUkLi2CBVJFYPiWN6uFiYuwxGjB4CEsjGuQFREziBsK9jrKQy5Ru0hcfDied1YEg8zMoJgDMRomY3prkhh4Nfwe5A7FTj1jIVVpYVngEqlZlBPKFvlwNITw9bwzk6JmNbS1BmBSIiKsN2LtEd+w/MxuTdIUL2Eps780140VxA01Gm8XpNmPxhiPuBaJiw8HQgjfGnTmvJaOCA67MzYp48/iJSxlsjWxg7hFzb3zSMeuMhyINjBxFXKLHJiensYtOlz1zExU0rhN1wdl8dz7qExxYOxrV3URC9orHJ6enpbl4oQsFz+eCSEcLHN2C4Z6bPdBfCdmrCPLoHYQXD9mEJfPqWpQu6Bg75kYYxL9keXixPT09KEQwvNFZ8e0x1K54447XIQFi8FTWAaBqMS8ftWCOSPHJXs++R0JJ2S5+LIvhMAf8AN2FQRl9erVrpujWz/aWIsQ6+LhDlUNbiMsfSynY8nvRjgicXFkenr61P79+/fedNNNb6xatWplzDhKHtaPZdgtHGO2Uwg1Us9Gn9oWfKR9/G6iDU70RW6RMwR3z58//w8TExPusx1B8RSWslZDzE7+oeR6pbxxZKw3hGWXgrjtIHFpga985StHzp07dy+tGLyu1oawlG236VHTUseFzAgLrtA2CUt7yC1qiUceeeQddr14+eWXf7J27dqHYl7VM9UcUoslX3nllYGvJcYRs6YFd6juIs1Ulujb09PTT0cblCiFLJeWefjhh//25MmT/zI3NxfFxGhLWMrEi0bFHQpJ4d7ly5cR9N0SluEgy2UI7Nmz5zshhO8cPnz4xTVr1jw6OTlZbe+QhFESlpA02x52TUv4WOSuXLhw4X+mp6efijYYURlZLkNk586d/3j69Om7zp07d5gJUWUkoyYsWAp1WkrkQWaojjs0Ozt7bHZ2dvuePXskLENGlsuQSWIxu1566aWtK1as+O7KlSv/fvny5YWi7y0sWAusci4rLLhDsfu0VHGHEkvl5YmJiX/dsWPH/0UbiGiExGVEMJFhNIcPH/7OihUrHl+1atWm7OgIlnoKS52dBGK7Q2Ubjs/NzZ2dnZ397507d34j2sVFNCQuI0gyWb5x8ODBHcuWLeusXLnysRUrVqxmAnsKS52G34wppjvE9Ysspvn5+UsXL148ODc39x+7d+8enL4SQ0PiMsIkk6c3gRCa8+fPP7qwsPAw+ldHqDsAAAJRSURBVBNz1Lblap31TVhSVXur5EGMpd8YLl26dOrSpUuH5ufnZyQo44PEZUxICw2wrCBxo7Y3ERtbPFl3nVOsYjlExVopzM3NXZibm/v1/Pz8i/Pz8/+ZuIxizJC4jCnT09MH0o2O9u/fb0JjxwNFd4a1gsURYxeBhlA5e3TNmjW3nj59+sVdu3Y9uxR/X9cjEpclQtI+4KoWAvv370dktiVis8F+rl279oE6K4wbcCzpVXs8OSjBP65S/KXNRJ29dMTS4Ec/+tE3li1b1gtyTE5O7pyYmMgGT25esWLFbfafgwcP9l67sLCwMDs7e5IfGzduPLpt2zYTiVPpnrTql3J9I3ERQrigCl0hhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyGECxIXIYQLEhchhAsSFyFEfEII/w+ZM3xVQ2oGcgAAAABJRU5ErkJggg==",
                                        onClick: function(t) {
                                            return e.showGiftHint(t, 1)
                                        }
                                    }), Object(s.jsx)("img", {
                                        id: "gift3",
                                        className: 2 == this.state.counter ? "gift movinggift" : "gift",
                                        src: this.state.counter > 1 ? "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARcAAAESCAYAAADXHpFnAAAACXBIWXMAABYlAAAWJQFJUiTwAAAgAElEQVR4nO2dC4wcd33Hf/u4fdwjPttnO07iJw55O85DtGdoYrtBDRLFFi1S1RglNBKlEiVOhUpTkBJaIlq1kNCHhFArEnCrthRwKJRAUp+hqYNCSOw42A5x/EziZ+w93+3dvman+s7O3M2t9zW785+Z3fl+pNGtz7e7s3s3n/39fv/f//+P6LouhBDiNlG+o4QQFVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlUC6EECVQLoQQJVAuhBAlxPm2kiCRHRvdICIbbKe0a2Dj87v4S+o+Irquh/09ID5jCuU+EdkiIvOqzyZ9ZWRaRL4R7ZM/k1W7M/x9dQeUC/GN7NjoOhF5XETubHQOqcsjEksZNy+KyGOyavcj/K0FH8qF+EJ2bBSCeLiV504MR6RveM639hqRzqrde/jbCy6UC/GU7NgoNIEays2tPm8NuYBxEdkmq3Y/wd9gMOFoEfEMMw1yJBag5Wp+AKI283U5sv4+/gaDCSOXLiE7NrrSLHjiKy5SpAQobh41R1SOBvmVmOe/p1bBthmot6Du0oCPMYIJHpRL0Dmyfjh3Wv9HbVp+v8mZHhORHSiQBk007aRCdlqQi1AwwYNyCTJH1m/QNfmv0oQMFjKOfk9PisgjQZFMdmx0V7MRoUbEB0WSI03lAm5hkTc4UC5BpVJL+DrOrpgRcSgXi8+bkYxvvSHZsVEMNT/QyWPUKejW4piRMrIXJhCwoBtEbGLpEAz17jILqZ5jNsd1JBYQab2PfAUitm74FYcBRi5Bo4ZYtJxI7lTHv6ePDWx83rOahFlnOdpOAbea9BURiSYc3WWjrNrNKQM+w8glSBxZv65WxBJx57f0dTNF8YpH3BALXrtDsQAWdgMA5RIUjqwfNkd7LgEXl0uCeSA7Nqr8wnMrHQKx/rbutoL9L/5DuQSHR8yaQaXI0LdMpG+VSKxSyYymXDvPez0QjGsRUizV0ihRLVh78RnKJQgcWb9y5pM+OiiSHhVJrBFJrBRJ3WIIJt7f9kVWC2WCyY6Nbmu3n6UaRGsYhm4TRi8+Q7kEg8qFjoglddOlwyN9y9pNDxrhumDMIq5rEYMLr5ly8RHKxW8qRdxKg1l8mUikRv4TG+n0U7we95qzk91imxtFXAv0t3TInWZUSHyAcvGfbTNn0Hd5/ZOJpKXvMldTI4uHs2OjHX/Cm1HLthZ+tCUgUgf9LY1w7ZyIMygXP6mMEN1rnAFqLbWiFhsYNVKQHok5TN1po13QohaLLW49EHEG5eIvs3/4sUX1T0QviejTxs3kAiXRi5idvK012VcR4KhFzMIuUyMfoFz8xSaXBtd16eTMTVx0Ln6q25lnzlxuB9eiFtSWFLw+Ri8+QLn4y+aZZ4/WqdbmD4oUDs35FibxtdG12go3t9nF69qoDOpKLkYtFhta+zHiJpSLXxxZP/sHj6up1hUFsdiiFjtYgsClrt1qHjA7bFvCLAavcOOJjd7BthKzplAuPkC5+MfsH3ytqKV4oq5YxCzutrjGSTvscFB/cS1qUfh65plD/sRDKBf/sH2aVkUtKOAWm6/zhJEjhfWXpg125tKVbS8CZafvMrG2D1EF5eIxlIt/zI5gRIfmngQiFgimBZBGKGiuA5uzY6PNCqGujBAhCkuoGwWzoFw8hnLxj/p1itIpRyeFdELRp/7jTdKjjkdhUDdSmA7ZoVw8hnLxg+q+i+opz+VJxyeVXOx4QaVWWFEvOjGb7jou5CJiUTTyVY0r6RtpHcrFH+bKxd6Zq7W3/CsiAKyQr+BCfdisrVTTcSEXdRZFKV1t2EznKZRLD2EJRkGKVKv3paOUCFLxoM5SDeXiIZSLP9T/Iy9PdHRClmBcjgg223tfzEim7ZTIowJuLVh38RDKxR/qy0XXXDkhFEldHqa2L83QdtQCsUB+tRoAWxwg6wQ1LXqkJpRLD4Nh6tRi1zp577RFL211vDYSC/Zlwi4HpHegXIJGh2lRNWi0c7HQa0UvjuVSTyx6ubJtSumisuUkiE9QLoHAng+4nxtYFzZGZzrkzm+++MQJpzOg64mlXBCZfrsSsfQNK5srZYdbvXoI5RIESucqJ4GiQ5tD0c0wljJYEKlc5B3MOr41/9xVTn7e2kS+WhylyUrEgpeM4rML4mvGk7Jqd82tW4ga3J/cTpyDdv/ogOPO3HbAxY4dDIsZXYoXW38ApCzY5uPaxH6oyvheOSdSmtKNCKQWtTaQRxpUOK8bchFnm8y3TUni8lZ55eazhz6za1Ifen5aBn7wgasffE7pkxJu5+oLR9ZjtOW7bjy1tUF936DziARSwIXeqJAKqWD1u0hinkjqBpG+5bYnf10k96roxbzkz819HERJ1dEIng8/Z8mo1s94xbT062fKV4yf1ZfupXDUQLn4QWUtlzE3nlmbEsmdqfwOEZXEByOGEJzULxBFQFLVQ8EzUUXyBpHBD9S+s54XyXxDpDwuxYxI8aJuTEWwN/IhWsH3i7aMD4/raXduE97RF8vr5RsK3y/+3ssn9WVPm/WZPf98/XDz6emkJpSLH1TLBRugxZeKFN8UKR5xfEKIGBAR2OWACxcbqTkZgbFLBkVYpE8GC/5YJJKsf8eL/yFSPG7chEjsYoP88udnz63RNAX8TGmqcltlRAORHC+vlhP6u+SgdpPxdUofqPfj46ZodlE4zqBc/KBaLgMbZ08i93LbRV1IpjQ5W88Q82KGYJyIBvePxERiaVN8Q1U9c4U3RLTTlduGEI/P+W8IBlJBtGKvxyCaSVb13eBn8Xw4bzFTpeqoRzrYjN+hSFqFwmkBysUj7t+fGTbbz1cuiJy99m9S935m5pnnyGWfiHauo5OyLm4UW7Wpuf+HCxeTsGOJSo2mOoLAfSGEmc3v07eJ9NvOb/KHIvlfNnx+1HGqi8Vo6LM6hqvPD8+DoWgrWoEktalKDcfJinsnDImsNmSC47Xy2pbu5xIUThWUi8vcvz+z0mzv32C2m68zjzm9If+Q+oikI9nKP9LvqYwWSWeRSy0MWZijOrhYW2mxjyVFomnbKneouQxsEsnubCoWALFAMGLKzFpWwRKKPbLC/2NR7nJpVihiGzpvVJfRJC4HyjfL/xQ/KK+Uf83hO+MJoRYO5dIm9+/PbDAlstKKSJxswH5/4suyPvZs5R+xkcoe0eWsyPQLrpyfNRJU6/tWqlEPiAA/g5qL03QE8kKB2UqHrBSnlee1MGZMD9cf/ZrWB+QZbYs8U9riRorjNaERDuXSAFsUss729ZIopB36I1n508RnZFn0cOXeEEw54+rsPatAqpd1I3oBiBCaPQWEAhE47UGxWvnFlIlTmkkF9ZOnivfIy+X13SiVRswRTmF84vA3R5e9EtzTbQ3KZTYKsacww16tXLa571/k/bEdsymSRxiRBFKRQkU89SKLVgVjj1iifSLlYmuvA1EShs/j/fV3Wdyt3SXPle7yuobiHbo+reWL5wsTk6XixNSKcqn0lW9vWdf1e1yHpkPXVlC15GGlNa7sudMu+CRGeP/++A55b+wZWRg548nzGoVcY+/pWXHYayW40I3IZxIFVt2oi9QSQK06ijT4vML9kSqh2xdf6wnlZe3X5WVttPeilCqRaNM50QpFjMtdafspNXNAPKbn5XLfzzP7Yv2yRiKiduOKDsDFA8nggGDeG39Wronu8+z5Z4aOM7NWsKdOuA3pFM638GCRSupljERZo1HRikxmRqBq8Ja+Ug5oN8vB8lpDKr2Cli8cK2Wn48XJqQWlqVy6NJ2rFknP0vNyKU3IjaWJSt8G/rijKTkd6ZP+SFSGWri75/yf9n7jGImcNqKZW2LPO4pmIIFyqcl2r+XZmoherl8fiUTwQdv6O2CM8CyMSLyNQOPKyFFJxaaMWhReO1IgDCd3EzVEIn5Hxn7S8zWXrTszNV/gjGySMhlJSDQSlcCuJrI8eliuib4i7409O1sAbgC6bMsOF16yIgyAHhjcRuSBoWEIq9lIj5ZKSN+CuKQT085fYANeK980Ixr0sZzTl7j6+O1SLpZOl6ZzheLk1GDxYna+KRK3+PxT94w+4vY5e01oZ0VjNUlt2jiMTgpLNpGKcHKRqL9pFD69F0ZOy7WxfbIs8oaMRM60JBbgxvKWmsTkvL5QDqbXyr7Ft8tA9rzcUPi5DOkZuaJwWCZi843jV/G1si85Kq8n1uJOMpI7bYiwIsR9LZ9zPfAY9hTR6ri1hONFkdcuklJ2en5x0uhMDIblAgyXXDCxZCOVD97UHNkkpBSJqXuvcCFCIMbX6GFZHjns2ehRXlKS1YfkbX25nCkvlRe198k7+pJLI4R+kV39zZfOxf3OGamdebdI1pDNtdFXXJENUsSFsTNyS+xnM99DdIOoBvWaTqMbXStf0HL5yWJ2OlEYn1hCkbQP5VKHKtnEq2RTjsScL7SFCw0SQTSCyGRZ5HDHF5sT/GiPR7HaGPUxi7T29+AaUzidYkU3d8lTxiO1Gt1Ui6Q0nRdd0+aLyHzlb0wIoFxapEo20SrZGGmVHSsaGYmeqaQJHkYjYvs0x6e4D/Ns6gLZvKavNc/nHuPHjMjGRdnUim6OFVaXx7J3XfzxxTvyFIk3UC5tUiWbmZrNJ1N/Ie8efE3mxS94di6WSKzZv902ygLR2GVjFbAr6dQ+x1Iu6EnJFvu1wlREn1d4J47RsJHSG9HoxJrh7MQ1il4FqYZycQlLNktyb0g8c16mopXZxxPpEUmky67JpttF0gpW2vaMuT2SXTa4XT00/05hYUnPa5HB6QuxSudxThKSiyWMwjTxC8rFZRZK5Q/fakzrn6osn+BUNpicd1xfHchhWK+xywa9JAvzR5OfKP/tkqv0ExHIJCXnjL/jZiJZFGulC5C4BeXiEY1kU0ql5WJsPkVSBYaAixPZUnVTGrQ8PpKQKxzuxbQoTrl4CeXiE3bZ/Epuki9F/rrS1GcViEP2m3HaSzJVTnt6fsQ5lEtQMBd1mumsjUrPygZDwMXs1GQnTWlHi1fKbalXlZ0j6RzKJaj0iGzYSxJeKJduoZ5s4rO9Nn5DkRA7YZDLV0TkgQCch7tYsrE96ExU44Vsaq9LQpGQGXpeLts3DW/bujPzuIjg2ByAU1IGhmXtyye4JpvWFjgiZA6hSIu2bzIWQN7yu989sKdcyl8bTw4V4unLhqKxvgCcnci7Rc3CUO3KJswLHBH3CFXNJRKJHS0X8zfnC9PJ/MQZgVxiycGJvtSQxJIDgVw8yk3qyaZUGD9TnJwa6vUFjvoj7q410ym6XpZysSBaYTob7Uvujyf7/9tcpLsndgMIlVySly3ek7xs8ebi9LiUchPGUZ66MFScuiCRSFTiqSEtlkiPx1OX9UeiscAui+kWlmwmTr69uDdeUWNW9L3t23NXRJIvaIVcUSvlI2Wt2K9rM2uJDsSTA1M/+IPf7PoFouyEcrSoLz3POMpa0RAMZFMu5vA1VpweXyDjpySW6Jd4anAqnhoaj8YSSwNw2qRLMEUyrhVy8bJWSGulQtQUibksejgI9VA00qLEwALjMOVSiWa0omiFKRz9+Ytn+vFzcSN1GrwQTw5gCstIAE6fBABdL+fLxXxOK+ZS5VIhqZUKYoqk472tuh32uZhE+1KSxHHZkpmUCbIBkE0he14ke36+mT6hRiPx5OBJM33i8GsI0PXyhXIxH9WKuXnlUkFMkSSRcYf9vakF5VIDyAOHIZr8pBSnMkYkI2bIC+mY4llaSZ+Mn89FY31nRWRZsF4NaYO8rpdz5WKhXytO99lEwg8RB1AuDYhEY3PqM5BMCfUZbXY7QTN9kvzF06lorG8ZV1vtOnK6XtbLxUJaK06LKZKkGZGQDqBcWgR1l+TQIuNAfQZpElIn3bbnhl06JJjMDP/OiiRlG7UhLkK5tAHqM6nhK4w7WrUZfCXBJ3v2GH9LHkG5dIhVn9HL2kwBuE1OiBh7KDGvJz2B4+0xepEVgzG5Y2ln7Qeoz2BIu12K0+PL9LJmieWCKZtgtZT6y0xvMVKbdlOZ1emzPfFmdAOhjVw+vColK4ZicmxCM24/ts+7bT9qkctUukeRcvWl582PJ/rn47YJZDMV1vk9WiGH+khCK+WNOgmODFwz7PyxBmJ1NsZuQGz29yDRvoTRzV3rHGuBc9Wb7YXbo4RWLlMlXW4b6TMOcG46GH8AKBbncZhFZKOnJtE/P54asqdL58z1qLt9bKpU/TdoikTsIqnFkelFrp1ENF4RRiyRwvyzyr+jUeNry7S4+X5ZK81EXUZxuZQ35RPJuPaCAkJo5bIoNffT58G1A/LYK1k5NhmczShszXuVP3407qHGkxwcQRpmoyvrNUZ7fAsicZNYIi2JgWGJ9aUlEotLNBaXwVRSJnN5T14znk9itssu2W/d2uPJCXhIKOWC+spvLZttY0AUc+BC58ORC+V02/eFPBqFz/g/q3NYZtMniSf6cdveuDdtRjaYohCYVaxbjUhUkxiYJ4l4xcGbbrxGCiXNkMvTe37py/n0MqGUC+osj748KXcvSxpp0aMvTboSsXQil8HLr3E0rF0nfcLXdFWXMOo1k152DgdFJM1IxOOyfGSBIZjLhy+TU5mLgTzPbiWccjFFgjpLfzwSmFTIPqyNaQdIiSCRZjRInzCKVb305Gmz1uFKcdhLkaCwioJqNJ6U5GBnaQykAqGAyVzOEA1xl1C/o2dzZfna/qkAnMkskN1Uqfm0g3o0SZ+kRhH4rVZF45dIYvHEJcXVaKyzP93j587LE7uel/esWWncVhG1LBgcMGo5hVI4O4BDr2sIJkjcbdaCvnOkErHYpx1gDpMhmqppB41okD5Z96opFi9FEjXlEYsnK18T3q3T9cIh9xd9W3P5IiMSWrdymex89WBo063QyyVooPcGdSCMZr14rmg0+A3EI/LN16cNKeCQStPdnAilFeqlT1ohbwyJeiESa8jXkEhfum7fiCq8WOoSNZz3XbvGuI2v+988aRxhg3IJGNYQ+W8sTRgH+NqBS1O3eqvptYo9fSpMna/bBNYpViRipDdIdRykMyqGiLHU5Yu5m9x9kVXY0yCcP9KuMEK5BITr5sflo1enZfngnP4VOZcry09P1o8kaq2mh9TJj67Q6qik3fQGxdZ1K68yLsznDr7ha82inVEkpETPHTwkay5fbNzXqx6aoEG5tMkfXtdv1EXcqtng8UZSnaUHjVbTU0EnUUkjIBMUQ8WMXs5P+iMXPPfd626Q7734ipyfbH16iBWpHDp1NtSjUJRLGyB1QcqC5jvUQtxg2+6LctuiPiN6sUsGtzH3ySrwtkqj1fTaBQKBTFTXSvBJ/6/P/dyIGpxc1G5j1U1QoH3hUHvnEdaRIqFc2mPruyuNrxDMt4/kDMm4wS/OVgq4kAke8+kTeaOYiyJvu7Syml4trBTHSm8czbPpECuN8LNWAaFYfTBIb1SMKvU6lEsLIFL5+PWVUZrrhmffMvSkfO7WQSM1Qtfvm29FRTpcjA4NfRCLW13Dduqtpgcwz6YSmaRdTXG6BfS7IBXDkYjPlTn+jSjG6ocJczTiBMqlBSCP4xPanPlIFijA4oB0tp+SjuWC51Ehlmrsq+lh8emwyaQaDBV/6PabLxGLBSIZHACpGgrNfqZs3QAXi2oR1Fb+t86ozfFJzaiZnHJh2QYjCnJZLNUzwKupJxYUI8NSkEQqhsmL6FFpBP4fIqJYmkO5OKBeURXicavuogLUiDDU7RR8UmPmsPWJ3etAGHuOnqj7Ki0BYRSINIdpkQOWd1BY9QPUhCAVdPyiUIx+mWZ9MxYYhr3+qqXG1yB2l2bL7a0msbLvrbafc+errzFicQDl4gBcoNYoDlIkzANCHQb1FjfWg3EbFJutpjxrSBtLTbQCPqUtqQSxgHms2N6k7v5o49YBa4SoFvXqMaQ2lIsDjpm1FSsFQjoE0Yykg5ld/vkLE8YKe9ZSngcyJUcSDON8GHQHA4wKHTp1xhiGbiScVkHtKmyjTJSLA9CHUg0KsEGbWW0Ha9YYK+1lSnOG0cmlYBjammRo9dqgvoL0EDOc2y1u43ExnQGPFaZ5Rvxr63EQbX3bjLaajRq5AS7Ebo14UE+p1YmL1wMxLBjsr3m/ZiDyQUSE+lWY+mQolx7HXrz1IsKyPuEbjbp0IxBCu+uyIArac/RNY8W7MKVGlAtxDXw6o+iJFADhP0dWKuC9COOyC5QL6RjUFBD6IyWy+NDta2duozeEi1+HD8qFdASiFcy7qTdMi3SAYgkn7NB1kZEOthbpVhDuIzKplQI163j1g0WxcK4K5weUi4ssjHgjl7trTKD0E0jk6T37LzmDwZS7C21j5nKnUxFGYhdcOx/SGKZFXQSkYrXzoxkuSFvP2kdBkAZh2BUH0iY3i5lIwTAiZURKDEICDeXSRVib54PP3jooj+3LBmraAWYMY+1YSyaV3QzdOz8r9bLERbkEG8qly4BgMCExaGIB33tx75zFqMO66j2pQLmY9JvLSQZxAqIFzu3jPx03UqOpYvCWeFC5yj2Gu9+zZpWyxyfuw4Kuye2L+uTBmwYMyQQVq8M2aPUW1Vir8HNWcncR+sgFyyhg1X0USyGWr90xz0g9PvvCRKAnJIaJym4AL8zMTt5047UUTRfAyEVE7liamBOxuLkfEXEPjELhCErvDEatSH1CLxekF1j3xA7FEmzsSyJ4DfpsMM0BQ+L26Q7kUkIvF4C9gZAKYU/mH53Iy/Vc9yTwYBfEA4V3tXWa1ycPtf3yIDWrmc/acsTaHZLMhVcR1mMt6XNWmCPBx6+lC85Pzt21EnUgzgCvDeVi9o4Q0gqIWKyUDKNY//mzl/i+1YFyIcQB1jKYWBDr7nXX861rQNhqLntEZDwA50G6HKRlqPuQ+oRKLts3De/A1jUi8iAGigJwSoT0LKEbLdq+aTizfdPw49s3DUMyHxORnwTgtAjpOUI9FL190/AT2zcNbxCRjSLyVABOiYSTY2bK3lOwoFuRzC4R2bV1ZwbRzCMicm8ATisQoIcDW2p4uT8yRmH8apLzEETMSNN3PHXP6NFefIGUi43tm4bxS75v687MNhGxjnmBOUEfsBrFxNwgTDWQGSYpYi6RKnxajW7ckgk+yJ66ZzTj1+/UKyiXGqAugwhm687M4yKyxYxmVgTuRD3A6j61OlERVeAr5vhgYah2QfMZohN7hIIeEktkKvFwHd29tuik59KeZlAuDTAl8wSOrTsz9yGqEZE7A3vCLoNeDvs+yfa5NJ1OHrSWUcDqdacy44ZkemCuDqKTXTah9Hx00gjKpUVQ/DUls8FMlzYH8TyN5S9fyXbUdQyp4ELHUWtpA6RHndZEjp+7YIgFj29t/m4HUuuSLUmO2WSyKwDnExgoF4fUKP5uCUpdxljAezhuLHxl38bVKYgqcHGrXDMFTWjodMXujLXA5MAXDh0NqmCesiKUXi3GugHl0ia24u+wVfxdKKd9kwzWo/nwqspWHpBMJ3KpbBXyS0MwuMirZ/2iNoK0qPPo5XxduViFXfwMJOPz6NExm0x2+Hki3QTl0iFW8RfHjrF5f5eRhX80LO948r5ikautV6cvWZpz+WDMSI+s5TCPT2htrVFTWZjpTdl04zUz/xYzsoF0dr76Wkfn38oeRJcPzzPSMwjGY/aa9bZdYSzGugHl4iJbNn76UyKf/tQPx77wxZXy2ieWy6Fhlc/34tmiEaVAJtUgPcKB2sujL022/RxWxIA6SyejQ9UgMmlUwEX0hLTJw/4aa6h4F4ux7kC5KOADGz/3kIg89P2xL25bIm9+8np5qb1VjZoAcXzhpUn53K2DNQVzfFIz/r+T4i4uchxuikXMmko9IDSPJgXuNWXyBKMT96FcFPLBjQ+hT+bx74x9+X3L5I0nVsvB1SmZcnV7AYgD6U8tuXQqFgu3L3SkVYhKULfBiBHkhSjGEk6rCy/tz6+R6xJvOHrug4XVp4p6/EkR+SqLsWqhXDzgwxv/5DmUGL419pUVS+StJ2+QX9zhpmSwj1EtgroIVnXznJjrpCBVQh3GzRGi89q80pHiVa9e0OY9vfmDX3roNhHBcb9rz0DqQbl4yEc2PoBRB/TJyI/HHv6nG+QX93Za/EUxF1ELUqCnT+RnRo2CvP9SPZB6IarpdMnII8WrMm+Vluy6qA3+20d++6/+nWv0+0NE17nEo5+gLvMu2f/wo/rft1X8XZSKykg6OmenSIjlo1en5aenCi3tIDlx8kBg3g808LW6Pu7vDP3IOKb1lP56YcXhM6WF35os93/1ng/9JdfqCQCUS0DYujOzzuyX8XxGdpDk4oC9m/qf33NF/MwPEZ10zVmHCMolYJidv9vMeUyeNOV1iVzs83Z2sRgbfCiXgGLr/L1P9YzsAMuF83a6GMqlCzBnZCtb9iFgcuG8nR6BcukizBnZj7i97IPPcjlWle6wM7ZHoFy6ELeLvz7IhfN2QgDl0sWYxd/7Ol2O0wO5cN5OCKFcegCz+GtJxnFdRpFc9tpkwmJsCKFcegyz+AvJ3NzqK3NRLizGkhkolx7FSfG3A7kcsxViuYgSmQPl0uO0sheTQ7n8xCYUFmNJXSiXkNCo+NtELizGkragXEJGreJvDbmEer8d4rCw2asAAAFcSURBVA6US4ix9mKaOHnwdhH9Wc7bIW5CuRBClBDl20oIUQHlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCFEC5UIIUQLlQghRAuVCCHEfEfl/3IkiXpGZRv4AAAAASUVORK5CYII=" : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARcAAAESCAYAAADXHpFnAAAACXBIWXMAABYlAAAWJQFJUiTwAAAes0lEQVR4nO2d348cV5XHb890T8/YE9uxQ6yNQfYmIBhEsBMegrQRzIJWApPIWQkI6hcHKY8rxf4LYrTaxxXWLtK+rBbnZSRgHxyRjPYh0XYikJKVyM8VDSKBWCEkDvGveNzTv3v1LerMXperf1TVPVXVXd+P1Jof9nRV/6hPn3PuveeWhsOhIYQQ1yzwGSWEaEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUoFwIISpQLoQQFSgXQogKlAshRAXKhRCiAuVCCFGBciGEqEC5EEJUKPNpJXmhXq8fMcY84t/2GWOOGmNeqFQqr+3evfs/jh079gZfrNmhNBwOi/4ckIyp1+uPGWNw+2rYmSwtLZnbb7/dDAaD+sLCwg/W1tbqfM3yD+VCMqNerx8zxpwdJRWbgwcP2j8+ZYw5tba2dpWvXn5hzYVkQr1eP2WMeXUasYB+v2//eNIY806j0Vjnq5dfKBeSOvV6/Zwx5odRjhuQC9hrjPnvRqPxGF/BfMK0iKRGvV5HkbbuF2ojgZoLai8j+P7a2to5vpL5gqNFM0K9XkcKgFRi3f/UFl5HiuBftOfX19ffyfEjOh9HLFPw40ajYSiYfMHIJec0Go193W73p9euXfu7kNQgjBeMMefW19dzdaH5qdDJuH8/IXIR/n5tbe183GMQt1AuOabRaBwbDof/VSqVDl68eDHqiV7A8O76+nrmw7Z+8TZSjSXIlHK5Zow5tra2luforTBQLjkFYvFTHS8FunTpkun1enFO9mlfMpkM2/rDza8mvZ/AUPQ4Xl9bWzuW9HgkORwtyiFBsYCFhdgv1QnUZPyaTar4BdzEaUqpVIry3482Go0zaT9WciuUS84IE4uJfoEF8YZt/ZmwaYKL/HDS402RDgV5stFoHEn5sZIAlEuOQPEWxdigWEClUnFxoj/2C6vq+JHSEy6OE0MuxhcbyRDKJV+cGTVU60gu4GRKgnF2jGq1GufPTnIGb7ZQLjnBT4e8T3qkQCsrK+a2224zq6urplwue5/eCVMjG1XB1Ot1J+kQwGNfXFyM++ecvZshlEt+wAI+TyC7du3yIhV8j0IuRIOvy8vLLk9WRTB+EfeUq/vDY0/ASdZesoNyyQF++O4t4EOEEvykhmTwCR4zPRiHhmDOhNWM4iARXEIYvWQE5ZIPvOIjLqZRxUuRS4IUYRQnXY0i+c2enBRxASI1B6kg5ZIRlEvG+GG7F7VIKjSO3bt3a5wwRpEecXA/TkdoHD3Ww41Gw8VjIxGhXLJnpz4xTVSCNEEhegHn/Nm0sfCjlthrh4Kg7uTwcXLUKAMol+zZ+VQdN9xsT/3fs2ePxkmjTnLeL8jGwVnUgugNo2QOYeSSAZRLhvjDz96Q7bhP6W63690E1GUUirvGP5fIBV5fSM4uYKRDDofdjZ8acb1RylAu2bJzQY5aOwSpbG9vm+AC071792qlRyf8VcxROOVqhAiPSamuxNQoZSiXbNl5w4fJRcQSBj7Z9+2Lm8FM5IcR6y/ORmSUUj5DuaQP5ZItO82pg3IZDAam1WqNPTkMTytejFOlR/4ok5PZuCjixlxHNA1Mi1KGcsmIYA0gWGNot9u3pEJhYPTIwUSzMI760/gn4SRqQTrkuIgb5LC/MJSkBOWSHTe90YORS5TGUIhelATz5Lj0yC/knnBxIKR4jou4YTB6SRHKJTtuqgHYcoFYonYIxCJHpEkKnB1zl05GiBTPPQjrLilCueSQKRtx3wQ+9ffv369xkX51zPKAxHJBxIVaS0pwEWOKUC7ZMTJERzE3DoqCORucXOciJcJ5ImpJEcolRSiX7Ni5WMNGiuIignFcg9kb0kYhUdSCAi7OM4U6i81UW8cSN1AuOcD1BYb7UyjyngpEL7HrFzJHJ2WxkJShXHKIq+1eIBiHacfewPqhWHIZl7qhkB2n3hQFtr5MD27nmkOSpEVBUCzFhXz16lUX0nrCn/tyJM7EuXFiwUzkGzdumDvuuCPpOZKcQLnkAO1Pa8x6/cQnPuEJptPpJLqv4XB4ZjAYtKKuaxolFgjv+vXrnlwUZxvbcDfGlKBccgIuMlyAMXdVnAjuG1uiIjrY2tpKcldPRI2ARokFUoXw8JghQKWJgDYvcKvX9KBccgIWKeICSxpZTAIrjtGu4dq1a7FEBlFIu4dpIi4IBcXbYKSD5Q04B4hK/o8mw+HwT6VSiX1dUoR7RWdEo9GoB4dGcQHGSZHwN3HaLzSbTS+KmfQegFBEShCBNLWCECEopDRhbSEgy7BRIaRBOLbx9yRC+4i0Ro663e52r9f7U7/ff3MwGLzwwAMPjJuBTBJAuWREmFzi8uGHH3oXPBpaR21qbdc8woBMJKVBTSTYpAoRyMcff+xJxr4fpDjBGgr+jx0xhf2fLKBwdKBcMiIoF4k84kQuuKBxgRs/yhDJRGlfIHKw0zJbLBjFGSUt/M3ly5e97xGRBLcEwXsMtR7cBERCo1ZB4/9jxEypGVbo+eMGUeKr3+ridWPMa3I7fvx4PZWTmSMol4xoNBpnZRsOu/sa3uC4RQVSwsVrRyC4X0QauNCnXRKAiwv3g68oAENQOLdx82WQWo0qEssQs0gT4kEaFNamUx679NDVSJVGiGRaKJwIUC4Z0Wg0MF/kSePXHeyLTaKQOOD1lBqIXbAV0Uzbfxf1FKmtIGqx5YQLU4QxKtKSFMl+f4UVd3GOiHZwkeP3kJgdcYlo4/QMxn2KSHCciCKZFgpnBJRLCmxubq77a4mO+bcje/bsOXrgwAHv4LiI7TQiiVxscOHjwgqKxvgXOo4r65rkgpa0SIq4xu/XK+eH+0LdZBKXLl266Zh2GiRFYJwbzlEiFUz4EwlAbjiXUUXhINISVCIS7VG3CRReOIZyccfm5uYRf+bqscDX0JmsuGgOHTrkfW+nAeP65kYFF6pdu0CEgItumiFoSYdEOviK2zRzZHAMHMtOcSAziVLsaEfqM/gd/k7ej7ZwRoG/gYgxV2YGKJxwKJeIbG5u2vI45kcksUZ9IBe5eGW0J3jxJSFY74iCnBfqLlG5cuWK9xdxowfIBmIbVdCFpHCMhJMB88BcC4dyCWFzc3NfQB7rcdfTjAMpycGDBz2paGLXRuSCl0WCo6IYiTSiDhcjkoDU5O+nRSKYcTstIl1CSiZzZOaRwWDwdrPZfOu73/3uN2b94RV6hq4fhdjyOJJmzw+kLO+//74nF0QIWpLBxSoXbNjwtKRKUquQoWDjRz/4HoXWcUPDkqKIvKZZfCnD5sGCtg3OCxEKCsRaSyOyZDAYXGm321utVmtpa2vrYKvVumcwGNwzD49t7uViRSEiDymuHs3B6XngE1kkg+Jpim0fPaSegsgB81WkVoPICl9liFhm6IqgICHUiGQ0RoA0wuQiRWS5j1HD41KzkSHxeSFEJPgd8s7ouecMMPdyuX79+oOLi4s/rVQqH5fL5eVSqeRkZ0AN8GbDDRedSEa7cbWIREaV7DQ5mDKLZOzJcGGIRCAZSASSGvc4cBwZQcJ9Kw0Zp8pwONzudruXb9y40Ws2m4fxvHW73bkVSRhzL5d+v7/V7/dXOp2ON5Yqb/RKpXK5XC4vlUol1c1y4oALDUO5uEEwKG7i66gtXwOP96b0JAkQBMSjvc0JJIRj4Ya/xzFlghuEg+9d9rhxzQiR4Ek4lNuTToHC1VzkjdvpdPYbSzblcrlTLpcHCwsLutXViCA9wA3niIsWw7MSDYSBugjqN/4bfOLBJMIQ7PqMgOdrUs1DWkbgmPj7JDsn4rHJEgZZLS31IJFNlulSp9O50Gq1ys1mc3+r1Vppt9uFF0kYhW+5YMnGuxos2eC2vbCwoN5kJIjUQGRG7TiZjGJckXQSMooEUch6IzxPkAfEYcsIv8dNUigZyRFBQIhR1zmNe05kIl5a0U2ISIzrUcN5pfByCWLJBv+yggvJkk1/0eFqOlyAUkiVIqfiXsm3IMPRMoM3bCavjdRGpgHPo0Rdgi2bpCNjYdGNzO6FAGTqf8Tn42K73e40m83VGzdu3E6RJINymYCMiPgpxmJANlOv3BVxyGS5ONFIXGxhZjk9XgrWQjCySfp84PVAZGOvtpZjinAkurFF0mq1bvcleDDRCZCbXw8+HdEIyMYEZQN5hKU1aWGnCyKSvM4PCcoGz5MtHBfyxf1UKpVhtVodrKyslN5+++2FixcvGopEH8olIUHZYFQHw8gQDeQiK4s1mCWRTINEVLJwU2SD5xFfpxmW7/f7w06nM+h2u6V+v7+A12U4HKJI5IWYk4bRiTsoF8fISmSZDyJzPZLKxp5BK7WReZyxahNM3/AcBiObbrfbb7fboSIh2UK5KIPIJqpsgiLJ+zyPNMBckmazefnPf/7zzlySL3zhC4YiyS+US8qMko20gkTkU3SRGGsI+Pr164c4KW02oVwyRmSD+SS4GT/8t2/zDueSzCeUSw4J1lPmSTYYAm42mz2KZP6hXGaAWZUN55IUG8plBsmjbNBOYHt7eyvvIkFfmjnoYDcTzL1carVafWNj4/vGGGzlkdt2C0lIWzZF60tC4lGIyKVWq53b2Ng4b4w51ev1ngwuvps3XMqGIiFxKUxaVKvV0CL+zI9+9KMnut3uvmq12qlUKu3l5eXb0trZLyvCZIPH7MumVyqVvPcBGxzlhtfn4UEUruaysrLyXqlU2tdut5dwQ/7trwnaWllZGVQqlew3L1ZGZOOP1JQxrwbbc3AuSXr4TdO73W631e12K/1+f/nAgQP3nT59+rV5eYxFlMtHsk8OLi4UHv2LbRWzYZEuVavVfrVavbK0tLQatXnULEZB0ruF6OD3x7na6/UqvV6v2uv1yn7/m4p/85gnsZgijxZBAlhkKLv8yRaoeNFbrdZiq9W6w/hNlyqVSnN5efna4uIiGoeMbR417ykWGU+/3+/0er1Wr9db7PV6u/He8kWyr2hPHYei/RoEhihxk0bVskexP1V/19bW1i5p6LS8vHypUqm0mEJkC1Jau3dL2vT7/SuQSL/f34PIzxcJ+muk12Mjx1AuAaQ9pB/B7KRNxqpVNJvNA/aeO5VK5f2FvzQf4QSx+aTd7/dxW0FqY4mEhe4xUC4jkB0ApT4jex/LzoWQj6RSxpi/ksZQq6urPT6v+WWKxl3N/l+4TWpRqJMMh8N4DYkLDC+CKUAdRdImac6Em72vj6x0Xl1dLUfZ/pSkS0AuV/v9/j67IXmv19vFLY7dQLlERNpWQiBSm5H6DMk/0jjcF8k+ikQPyiUBdtokhWCSbyTFJfpQLg6wh7Wj7jYYwrvGmFXOip0IRutytYEduZl09rbIKXfffbd3Ytih8Jvf/KaTk4zbsR5d6NCYut1uf8oahdj2ZVP0kGhn7QIiD3+j+uV57yE86xQ6crn33nvNl770Je/7LLcHFazRJ9mWZKVarX7Kmph3BdM7jDGfyvhUtRjYH3j+FHnURsrW8O/OoTXrJZjThBFDfFjI8x+luXrwXMN+N++zogstF0QL2OTd+HJBoTYPkjHW6BNaX8rkvZWVldvL5bKdLl30G1TfkeGpOsEXyYI1aqMqD+NHmRCH7JeN59mWSRKiiGhe+yYXVi4HDx40d955587PkMyJEyfM5uZm7va2sSbvGXvy3tLS0sFA64j3sHVSzuo1MMRNJyl7PaUpEgHiwPavsrE/IkWZOiD7JaVN2Ob/80Ah5QKRfOUrX7npd6+88op59913MxOLzAyeNKwdmLy3s6sjvi4uLtrLEfAfPsq6OIx9hGyJ4JblpzQiE+lpA6k8+OCD3s94/bOSy7xSSLlAID/72c+87xGtYHvP3/zmN5meE97g+ES15TFNwXJE+oTvVwK1GanX3DFp8WVcZKP6NESCiC1Owy97LRLOU0TzxS9+0fzqV78yly9fdnqeRabwQ9F4Q+UpDcIFE1ytbS87GMeY9Ak/B5s+XfRHYWItvkxbJLIPtzS6kmZXSYCE33vvPXPo0CHz8ssvM3JxTOHl8sc//jEHZ3EzqAchmgqu1sYtuOxgFMH0SVInP30y9iLLSeJKUyTGL4YGRaIBxIIbpKIhFjyGT3/606bRaKicf94pvFzyyNe//nXz29/+1ouqBBEDRCNrm6KMbMn2sEifcLHK/UE69sWbtkgkIrHabqodaxTvvPOO0/tDRIQ0S2Zw4/6LOHubcskpn/3sZ73JfQCjWs8//7wXzQRXa0s3vWnSJkGmwEv6hAsbn9zaIpFiqggl7qb8eQciwfO5f/9+70zX19fNL3/5y8KlXZRLzsDEPkGGylETgliCBLvpQRbTpk2CRCoa83sktZHIJEp6A3ni4kTaMosgtRXq9TojFxINl5PuMCz6ta99bWdSn82bb745+YUsl737wC3YTS8NJCqxhZKEz3zmM16hFRcphonDwGPU7kQHyR05ciRy3QQFYkh7bW2tsAtaC722KAl407taj2T8YdGw6MRYa6CmBbUUDGsj8oFsNOoYMgkNFzfSN0QZOBZ+5yLdkWL0uMglSioYF9ROPvnJT8Y6f7ymb7zxhvo55hVGLjFB+oIoAxf+73//+8T3hzfjSy+95EUpmHtjA0ngDR51ZGtSN70oSI1EIhPtTeV+97vfeYXQLNffIHKSuomM4JHpoVwiAJngkxpfpR4CuVy5csW7uQD1FdwXooEXX3zR+x7HTBoNTNNNT4A4gjLJAi2xhKWzeJx4bmw+//nP7/wE0VAu0aBcpuRzn/ucuf/++2/5z5CMpEcffvihee215FvPQCgYipZIxfUkP+mmJ8PauH+/0Ximm9mnxahamQwfh4HIBaM+mMF76dIl7yubg42HNZcpwfKAcekPPmWnKbxOAwqYLlKtSUjahFoJRIMZvfMullHg9cPzPm7JBZ4rRDCQEArOZDyUSwRQEwmre+CN+dxzzzkLmzWGheMUJY2fDhQFzEOxJy6OAiNHRS7UTgvlEpGwFAWbc7mquWiAkB6rwMOGuceBv8MnNFYOF2VHA6Q7oxYvIqrBELPrGb3zCmsuEZFZsyIZXLDyu7who1kylI1RKImyppEhPsmRCsgCyqIwSqR4Prhqenool4jggkV6JDURXLholYnf563JFESC6MOOWHDe00ZZEAo+qbEeqSgE5wVBrPLzvC5X0IJyicjTTz990x/gYs3jymrj124QpdRqtZ3fRU3fivZJDRlDKKifyYJDrGzGLN3gUHWc+y7ScDbl4oC89N0dBSIYFCoxBBu17lI0kPpgLZA9xwYFXEgBo0RxkFXSiIogLEwQLAKUSwFAtJWWAHEhYT3NqPVAeWDcAspRkQUiOEgnDrIUAOlVkVZGc7SoAKQZWSH0l1tewSrytHnrrbcK13aBkQtxisynQRpgD9lmvU4oa4rYQpNyIYnBRLsDBw540YqMrOArCqHGbydZZLEUFaZFJDEYXbHFYoNhbM5mLSaUy4yCkZ+8gCIoip1h82H+8Ic/ODvLeW6NOY9QLjMIVmhHbSClzahmVy4Lu4iMsDIZo1EYlZrHXQrnCdZcZgjMUTl+/Lj36S01jKw3cwsDkkGdBWJBPcY+3yTIkC4mtOGGUTBOx88vlMsMgeUF2HIWUQsu2LxN3sOFjwlnMkoEybjes0fWO5H8Q7nkBDS4nhY0knLVXtMlYauFXY4SQagYlSKzAeVigQWIURb2uWTaQiUWTZqcpkOa4Pl54IEHnDSzYuSTDizoWiAa+PKXv5z7GaZGofVl3kGNBVGQixoLC8HpwMjFGE8oMvqC3izYThURDBsy5wd7sR8iD4wakXzDyMXfdMxOhfC9pB8kf8h+RmnsWzQOdOlDREXCYeTipxjoySId5fDV5W6KxD0YhTp8+HDiHitRkdoPUjTsacSWl6OhXHzwZpEOc1h8l8ehXvL/4PX64IMPUpeLTBaUdVOIXGTL2SIuThwH5eJjj74k6SzHYmGxQIqGtVMUy62w5uIYymX+wXA40jKspRq3W0DRYeRCSERk1jGKymmnZbNEESOXs8aYF3JwHiQjXEWXrubdzCuFk0utVjtfq9UwSeJv0V42B6dEUoYzdNOhsDWXWq1Wr9Vqjxhj/toY85Qx5loOTouQuaHwBd1arfZOrVZ7DKOKxpgfUDK3wgZNqlzzI+jvz9sDKw2HwxycRr7Y2NiAbM4YYw5HPbG77ror1mPBnJqPPvook+cBxx63WBPNmTDUigJmGkBmKJROqmesrq56s2Tj8Oqrr6byWEbwujEG+5ScP336dLz9SmYAjhaFUKvVzhljzm1sbCBtOmWM+WruTjJFsJmXTHOHYFCzwO8gHNd7SON+sXMAJqpNksuM7V/9tCWUQkzrpVzGgOIv3gwbGxsoACOaOZnbk1VE0iJc9LLrIJpyx90kTLj//vt35olAVBCLtFVoNpsT/z7rtUUTuGDJ5HyeT1QLymUKUPzFG2VjY+OMny4hotmb1/N1tScxpIJp7mFzOVzsQwRBIeWS740/Qc3Mbp0HUxwgkvrp06dfy8H5ZArlEgEUfxHBbGxs7PPTpVN5kwyad2NtVFK5IA1CPWNUcyYXC/bQRgE9do0lFUE6/ed8v6NrIhM/Qrmag3PKDZRLDGq12lU/gjmTpPjrGqzkvvfee72LEiu7k3TUg5xQW4GowgQDKSQVDGomSImwujgIoiX0bIGAcrbyWIqx5xidjIejRY7w6zJn7rrrrljF3zijRZCJtInAzgBoeHXnnXd6P2PxJVZ5T7Oye9xokbQYCKZGUnNJGlmghiPRyyhkY7WwxYH33XdfrONioWqEgvDTVrrDHgtTwsjFEX5dZv2ZZ555tFKp/FO1Wr1H+5iQAiIVEYoNIo5vf/vbnjSSNL+CPFBchVxwkf/617/2Cq+QDiKOJOkX7meSWCAAbKzmemRowhKAC5ZMClmMdQHl4piHHnroJ8aYnzzzzDMPlsvlf61Wq0dLpVJJ63gvvvii15ZTIpggmAuCTntJgFR27dplXn75ZafraaSYGwaOgZQoxbU7UowtzFCxNpSLEg899NAvELX//Oc/P1wul59aWlr6m8XFRefPN6KX559/3pw4ceKWERaI4Lnnnku8mwGiE9xcFlcRsSDyEXngvu2m6NPMc0lCqVRCh/P/tCIUFmMdQ7ko8/DDDyPE9rpJb25u/nu1Wj2pIZmwoVvUFVxsk6LRCAmT8YIzfhHJyGQ9DbG02+3t7e3t/+l0Ov/2+OOP/8T5AchNUC4pcvz48ceNMY8/++yzp5aWlp6sVCr7XBzdrrlAJnaRd5ZAnxRIElGNC6H1+/3h9vb2xXa7/Wy32/3H733vexdm6gmZcSiXDPjWt76FnjJnXRV/kU5gdAg7MSKdwM/YLgX1llkDgklSvO12u71ms/m/nU7nqe985ztnZ+4JmCM4FJ0DUPwdDAb/sLW19Q2Xk/IwYjRNP+BJCxfzDIait7a2Puh0Oi91u91/fvTRR38xkw9kDqFccoQ/8/cxf+ZvapPyZlAuhV+3MwtQLjnFn/kLyRzVPsMZkQtmxp7jup3ZgXLJOTLzV7PtQ07lwnU7Mw7lMiNsbGwc8SXjvO1DjuRSiCZKRYFymTF8yTzmckV2xnLhup05hXKZUVwWf1OWC9ftFATKZQ7wi7+Pxa3LpCAXNlEqIJTLHOEXfxHJnIjyqBTkIsVYrtspMJTLHBK1+OtILq9bq4oZnRDKZZ6Zth1nTLlck5EdFmNJGJRLAfAl88iodpwR5HLBik44VEzGQrkUjLDi7wS5FG6/HeIGyqWg2MXfgFwuBNIdFmNJLCiXgoPib6fT+ZcrV668wmIscQnlQghRYYFPKyFEA8qFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiAqUCyFEBcqFEKIC5UIIUYFyIYSoQLkQQlSgXAghKlAuhBAVKBdCiHuMMf8HpnLg+db7/o4AAAAASUVORK5CYII=",
                                        onClick: function(t) {
                                            return e.showGiftHint(t, 2)
                                        }
                                    }), Object(s.jsx)("img", {
                                        id: "gift4",
                                        className: 3 == this.state.counter ? "gift movinggift" : "gift",
                                        src: this.state.counter > 2 ? Ws : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARcAAAESCAYAAADXHpFnAAAACXBIWXMAABYlAAAWJQFJUiTwAAAgAElEQVR4nO2deWwc133HZw+uqBUvnbHUGJJjp0H6R0QDbpsUjb2u/2hhpLACFmh9IKKbowXbwrKRAD7ikJKlREWKlkwg2s4BSy3cImi3kdMDSYvGK6RNk6KGJf9jGHIcMoIVy5YiUiRFrrTLLX70G/Zx+N6bNzPvzbH7/QCExL1mZpfvu7/r/X65VqvlAACAafJ4RwEANoC4AACsAHEBAFgB4gIAsALEBQBgBYgLAMAKEBcAgBUgLgAAK0BcAABWgLgAAKwAcQEAWAHiAgCwAsQFAGAFiAsAwAoQFwCAFSAuAAArQFwAAFaAuAAArABxAQBYAeICALACxAUAYAWICwDAChAXAIAVIC4AACtAXAAAVoC4AACsAHEBAFgB4gIAsALEBQBgBYgLAMAKEBcAgBUgLgAAK0BcAABWgLgAAKwAcQEAWAHiAgCwQhFva7LUarWK4ziDjuMMsBOZop9KpVLr1PcEtAe5VquFjzJmarXaHsdxxhzH2ec4Tr/i6C84jnOSfiqVykxbvhmgbYG4xEytViNRGQ1x1BOO44xXKpXTmX4DQMcAcYmJWq1Gbg+5OnsjHvGU4zjHK5XK8cxcPOhIIC4xYFBYeKbJtYLIgLQCcbGMhrDMsvtPs39dKMhLsZmKjyiRyAwjAAzSBsTFMrVajSyL/YKjkKiMsziKMljLBGof+7lH8jBylw60W0yGXfsgl1Hbw354Zpg4r/wLoU0HEBeL1Go1EoNvC45whiySMBkglmkaJiGRZJommLuUyewSu74K97M75Eu9wLJscBsTAuJikVqtNiVYHC9UKpV9UY/KWTNjgmNkylXiruWA4biUE8RCBGaBuFiiVquRdfGc59Vp0Q+a/iNnxxKJTKqtGCYqBxRWmEmmmdt4Mt6r7FwgLpao1WqnBd/CD9o005nIjHsWKi2qfWmKxQQoIrTBC8yqgxVjGYiLBdji+annlWcrlcpADMd2rQFvod7DlUpl3PbxVbBzG5cEuGWc4rJpUzKRZO/5IIvV7POJ1ZxhAoOCRItAXCwgcYlOUQQ3xnMYZAv5Du7mE8w1iPVbO6D7M81teQgdM2LXf0AhZLMsqA6BsQTExQKSEv9YxcWlVqvRAvsr7qbQmaoIxx/TEJUTTFCMxkSYRXPcI7IuEBiLQFwsIKltOVOpVAYTOp9BtsDcGJD1RcV2ex/3cU9iy+QIRJY/hz2IwZgH/Vzs4C3yIvayb9HYYSJSYdaBw6yIGhMdo9A11mo1sj5eVAgLLeiDbFHHks1i8aYHBXf1eyqjgSEgLnaQ/bEOJ3VCtIArlQod/2F2k3GBYdbBaUUVscPS47GJCg/L1IkEZi9zZYFB4BZZwMcEpzqXqYTPjw84R3aRfOIaLqnJ0Cg+n1sRfzEHLBc7yCwXshZOsuxJYrBv8FuZsESyYJhQnfYRloMUb0rLwmUu0inBXYmm6tsNWC6WoNWqWHCxZmxkMEGpMYEJZMFo1qzMsgK+1MU0JLVIxJ3Y+GgGWC72OKB4ZcranGYZlcRgQuKep7ZVxRZmzUdYTrHYSioXKnNNTwjuUn1uIACwXCwiKabzcort/0lsEXrOU2lVeawdGROVSiX1i5Rdy8uCu25KOi7WDsBysQiXnZhVHIVcpxdpLxIFGpNIV7PzdL/F98piDxrCMsv2T2Xi259ZbtOCuyLvWgcQF+uwhTvINsyp2MsyGD9lQjMWs9t0gFktxH5valZTWCoZ7J8ishgTdVfbBbhFMcLtdwmyG9htg0mFaTWb5rrATfg4leOzOMxpRVHcGRa4zZwrIZvGUKlUcsmcUfsAcUkAzbaVMtyNfTUmNqZ7w/CLbZZ9i6s2AGa6hYFi1AtqXiICcUmYiELjsICwa9VEXgzsfKY4y+pVx3E+KHn4CVb1m1kU4oKUdEQgLinCgNDMeqyaUG6KZpbLauOruFA0UE+8/03WgbikGNbge58TvlH1GU5oArUykPT/JRYdx/mNdnEZFNdJVcXYbxQBDKJPMUwQVkSBBVvdLmuqUnueveznoXcLhlfiIzVNF+q4xF1oMLcp87BsXNjpAsAHiEtGYGJAP+PMfeLHb+h2zL/Hdbdqtdq0KzSSQfcycellAnec1eTwdTkzGbNoVJYJ+rtEBG5RGxBBbHjOcIHhFTPnxRdffC2Xy/1yxHfojGehnvb8viZoGlcQVRFrcUFANyIQlzaEm1Lois1gwC77FBj+r1ar9Tu5XC7pQkvv7mXvgg8kTszaGtcImG9Gd7poQFw6BBaz4X904zZZhxenAU2rLvMp9jQAcelguHEcg9zgey2Xanl52VlaWnKKxeLLpVLpO9xdU5KArzvr2aXC3R737CIV6KlrCIhLh+OJ1wwHWejT09POwsIC/ffWkZGRSIFclrnh3bkkRCd1A+SyDMSlTfFkctxF62LEaiDL5Y033nDcbQJRBcaLx7KqWHTlME/aAhCXNoCrgXG/8Y3XbpAblM+vj+2+8847Kz+2BMaLIHYUViBnuTR85iuN0wjEJaMwd2aYbSq0Wgh27do1Z35+3unu7nbK5fK6+8l6ISvGbTQ1MjKSxETHQYGFtofdxgueciwsMAfEJYNoDhyLDFkrV69eder1+spLkchs3LjRGRhY2wmTHnf27Fmn2Ww6SQkMSB+o0M0YmpsKvUwLMjjr4heNRsOhLxv6l4SE/uUplUrO+fPnV6yUG264YfUecpd27969EuBtNpt7WTEeGi51OLBcMgSzWF7UOOMzzLLx3UNUrVZ1X3OFCxcurPxL1gsJDB+HIdFhAkO/nhgZGUGtSAcDcckQPuNKHCYqB3TL1qvVqrd3iy8XL16cbjabK+4YxWD27NmzRmBmZmZWrBsGBKaDQQ/djMDSsiphOcEGjwXZD3MyaKYll8ututJkqUxNTTnXr19fvZ8sml27drm/7h8dHf3bLL3PwBwQl+ygmgoQuFy9Wq0eCFM3UiqV1gRi3FoXli1awRWYubk5CvbeOzk5CeulA4G4ZJ/ZoIO8qtXqoGRWsi/5fL7P+xiKsVCsxWvBUJC3q6uLfn0OAtN5QFyyz/EgVaUszhK6aKyrq2uz6HYSmHPnzq2kpV0o4HvLLbe4v45PTk6GmkcNsgnEJTvIur8F7TkyHrLfywqiKl0Xco1IYHjIPWJ1MSsD7yEwnQPEJSOwZtui6YBBrJZ9Pg2SfCkW1aVRtJGRbQdYhQSGMkucwPjOowbZB+KSLUTujNZC/frXv373O++88/cmrjaXyy2q7idxuXz58prbbrzxRqdQKDgQmM4B4pItxgVzp33djImJiYF6vf7ter1e/MUvfhH5gvP5/Nt+j3nllVfW/E6B3e3bt7u/7j137tzUwYMH0Ry7jYG4ZAgWuPXO0vEdmt7V1fWjZrNZov/TXiHWgyU0xWJR+XdDWaNLly6tVvO6bNmyxdm0adPKbwsLC/31ev0HbfpRdTwOxCWTjHtiL3tZgZ2QZ5999uj169c/wN9HLou7GTEMhUJhWfU0EjDizTffXHcfWS/u/fPz8zc+9thjr3fQZ9dRQFwyBrNevCMxhHUuTz/99Efr9frnRPeRZcGnjYNQLBZ3qB7uFtTR61MhHQ+1bNiwYcPqLQsLCzc//vjjL8teC2QXiEsGYc2N+MbTw6ynyRqWl5f/qdVqCT9jWvjerI4uhUJho+qhrmVCQkJ7jbyQe8QzPz8/+OSTT36jAz66jgLikl1466Xfa70888wzpxqNhnLfEMVGRIvfD5b1kUIul1sP47VcHIG4ELOzs5+EwLQXEJeMwjYovsCd/QHXenn22Wcfrtfrt+tcGXWYCxp/UYmLa7WwupY1t7lQwym2LWANJDCjo6OBtjKA9AJxyTb8QiQrZWxiYmJPvV7/cpCrChN/yefzF0S3u/EWT1xl3eO83excZmdn/3JsbOz3A50MSCUQlwzDqnZPcFfwULlc/u9Wq6X2WzyQsHiL3vzI5XJLooe4VhBv3fAbGjXOJTczM/N3EJjsA3HJPmvqXnbu3HlDmCtaXFxccZF06erqEu4DcC0XvpF3EHFxmMAsLCz8NYrssg3EJeOwNparmaOenh6nvz/cKKIrV66s65srI5/PCx/oWi58TIW1vVzDtm3blK9fr9dLc3Nzr0JgsgvEpT1YY71w+3gCEcQ9KpVK6xY93zCKFxf+dhcda+batWsbc7ncD9vu0+oQIC5twKVLlwb5gCwJCwlMGMjy0HGPcrncuttcq4UP5sqYnfVukRLT39+/a3JyEkPLMgjEJeOwrnKj3nQyuUbkIoVBxz2iMSNeXGtElGYOA10De639EJjsAXHJMKyrHDXZFroeYa2XMNkj/hz4GpcoeGJHJDDebQ8gxUBcss24O3WRBEE0xExUDasDWUKUQVJRKBTWNK9yLRcdt8gPslgEo2NH0Ys3O0BcMkq1Wh32dpUTuTLvec97Ql8gWS+q4jp+zIgjqXEJiyLj9dzY2NhXIh8AWAfikkGq1eoeQV8XobiQ9RI2NU3CQvEXGfyYET77IxpWHxTVOc/MzPwpiuzSD8QlmwiHmcmsjL6+ddNAtKHMkSxtzI8ZUQVz3QZRupBbpQoKo4o3G0BcMka1Wh0L2r2fNgpGQdYakx8zYjJTpLJauF4xKwJz8ODB34x8QGAFiEuGYEPjR4OeMYlLlDgICYeo9oUfM2IymNvb2yu9j7fOSGDm5ub+DVW86QTikhH4tLMM2UyhVqvlW27vB8VevG4XP2bElOXi5xJ5oSpebBNIJxCX7HDcb2i8bFFSoJfuk7U50EEW3HXHjLjiolvjIhM7ldUigwRmcXHxf0NfHLACxCUDsKHx96jOlKwWmUty7dq1lX+pYjdK/EUU3HXHjLibE0XnEMRV8qsqFhULOu82pNqGZt/pAuKScnSHxqsyMq64EJs3b44Uf/G2xXTHjKhqXHSPRwLpZ/mo6m6o2ffY2Nj/aB0MWAfikmJ0h8aTZSDa6+Owb3p+QdICjhJ/8Vbu8mNGota3mKiP2bhx46+iijcdQFzSjW/amYRF5kqQqHj71zosNhMl/kLWiytYNGYkTDCXm764SlRxIeFkMZvnIDDJA3FJKceOHft+vV5/SHV2KmFxWOd9yhSJiBJ/ofiKm5qmMSN+4qLbiU5HXERi6eIJBpPA+E6jBPaAuKSQp59++jONRuNO1dhVirGohIUWv1/bhCjxF3p9sl7458sCtyJx8QqRTrzFD8H7cXxyctJ3ljawA8QlZVD3/uvXrx9z2Le0SCBoEakWou64kCjxFxIWco94cQniFnmrcE20aRCksekgNQhMMkBcUkahUPhRq9VarU7j3QDq/kaLUpXaDTqHiAQh7N4jV/yuXr26YmLJBILPVvHwblDUeIvCiutvNpvfQZFd/EBcUsSxY8eeaTaba3ok8GX35ArxVbFewgw4c9jGxrBl+6ypVENltchiLnxQV1dcZDEX1fPr9fqNqOKNH4hLSjh27NjHGo3GH3nPhtwPir2QVaASAHpMGGFxofiLbPuACjpmLpfrUokLpcNFPXN37dq1+v+oe5L8xAnbBOIH4pICJiYmBprN5j/KzoQWsM83s7RyVReyiEhgwrC8vFxSnZ9s6P3OnTtXrotELUphn24wmARmaWnpP0IfCAQC4pICisXi91utlvSrn9whUbd9h+0bCjLMTAWlpsPEPmhAmp9bdPHiReF9H/nIR7SDuTL3yu+c+edRFS+2CcQDxCVhJicnv9xoNG5VnYUq4KpKV4eBiuuCWhFkOahiQbS4z58/LxQHClDfeqvy8te8jogg4uIwgfn85z//I62DgtBAXBJkYmJi8Pr165/1OwNZJoTcId0JibqQUARt6k3xEh3rgwRGBPX5pfhLWNcojLV15cqVX3/yySe/EeqAQAuIS0JQnKVQKPx7lKNHjbPI8Kv89UKCJHPbHC7D8+qrr0ofQxbT7t27Q9W7+D1H9j7Nzs5+EgJjD4hLQvT09Aw3m83QOwhFo0RMQq5YEEsil8v5jlAkkZmenpbeTyLxvve9z7nhhhuExxaJhI7VotpJTQKDXrx2gLgkAO12HhgYGIvSOFs03N0kQd2jVqslzSXz5/rKK6/47jWi477//e9fd3yRSJhoq4lm33aAuCTDSvd+3eI1v+FktgjqHsng629IWF566SXf55C4kQVDloyqV42OG6Xa7Ohwzb6PHDlyt871AD0gLjHDusrd4R5169atvsVrooyQicFjOui6R8vLy9omBAV2dQTGYeJBsRgSGpG1ZsJycZjAXL58+R9QZGcOiEuMiLrKkbCQwKgQVbfS80wNfFeh6x61Wi1hRFfmAlHsRVdgHOYq3Xbbbeuu2c9yCeI+oorXLBCXmFB1laNvX1X8hYrkRJv/yGVRZWlMQeen0/tF1DtGFV8hgdGJwbjQrue77rprdUe1jtUSdEsECczCwsLpQE8CQiAu8TGu6ipH4qKyRC5cuLDuNrIqqGQ/DguGFnSYvUd+UDzp7Nmz0iI7L5Qduv3221fOx9Z1Ly0tDaCKNzoQlxioVqv7vEPjRajiLzT1UDT5kCwXEiYTgVcVVIHrl91qtVrrcuN+guHGc6g3jCsyfgFYEhXaNqBzzWGzatgmEJ2crA0iMAMbGn/ab+aQC7lA3g77PNSmgBYkLRrXVVHVcZjm5z//uXTBFovF2Vwut+Y6aU+RbF8RsWfPHmHchDJEdK2qOhYSoampKeUV+h3fj76+vpOHDx/+eOgX6GBgudhHODReBn0bq2IJtLv4rbfeWvmXLJk4hcVhgVUZrVYrcHmtLCBLGTISDrpWGSQ8lEWySaFQ2Idm3+GAuFgkzNB4J0BvFT/3wQaq4K4oY6QbrJVBAvrGG29IrSUSO1UdTBRI6GnfE5p9hwPiYomwQ+MdFt/QiSe4jaTixtv/ljufdcOTVOKiGyCmsv/XXntNej8TACFhBZjOjfrNcKDZd0AgLhbQHWamwi975JKE9aIrfn4E2aRI10lpaxH0OlHmMIkgi8hTPNg/MzPzQ2wT0AfiYgcSlsiFWDoLxkbbBR1I/ESWhzdBYGoPFL3O66+/Lg3OioashcVN8XuZn5/fSNsEUGSnB8TFMDpD43Wh+IbOrl9TneiCQAtQZL14xSVKX1/R68jaNsimSIZpS0HFeqItD3QOtE0AVbx6QFwMcuLEibvZCFZjyCwEniRcI4cFPAXnph0EClMER1ky0XYIRzy3KFQ2TebyufEjbBPQA+JiiImJicrMzMy/NBoN7bSzDjrxjaQCuxLrRbtwKoi48O6VrCeMiawRnZNIpLwCTgJTr9d/EPmAbQzExQDUVS6fz3/H+f85PkaRWAhrSJH1sqoYUdPQPLx7JbNcrly5Evk4flYLz/z8/I2o4pUDcTFAsVj83vLy8srXHS0C0/1XaPHK0r8uSQV2vdZLq9VaDVaYFBce0ZgSKrbz9ugNI7iyGJfsWmibwOOPP/5y4AN1ABCXiHz1q199rNFo/Br/KlS+b7pylkx+v74qabBelpeX5WMAIiDLOtH7TEV2on1XQaFrELlEjs97Oz8/P4hevOuBuESAuve3Wq1D3leghWAjg+O3cTCJuIsjGEqmu18tSMxFlHWiBU+bHU01Kldl5vysMNaL9ytGTqRNgLiEhHXv/y4/NJ6H/H/Tboqf9UKillRLTJHw+S3IKC0TyDWivUcmewlHERfnXff4zyYnJyvGTijjQFxCUiwWj3mHxnuxEdz1s16SEhfKarl7jlzLxVTMxfs6VP8jirv4Pc8Pmbjoupvs+SexTeBdIC4hoPL+LVu23OmXwSFT3lQRmYuf9UILIe6d0i7u4tQZMxIEr0jo9g8OIi6qedM61hH3/P7z58//GNsEIC5hGS+VSjup5NxPYFS9WcKSVuuFLBda+KoxI2lFtc9J5wuCt3oajUZpfn7+uU4vsoO4BKRarQ67XeUoZuAnMPTtaTrQ6me9JLEdwMVG+wNbkyV5VPEWnePzzyfrEVW8EJdAsK5y4/xzSGD8alBMFHd5kaVMHSZoSdS8OGyRuWNGTKXG43DzVA26dI4vsnxcgYl8chkF4hIMYVc5+rZWleiTz27aeqFFrLKYkrJeKLBbKpWsjiTQHTwfJJOkcot0RNI9J9E2gU6t4oW4aOLXVY525KpSq6atFxIW1SJLKu7isIWqU+ui2ywqrAUUJJgeJS3u99xObfYNcdFAt6scNRiSLRgb1ouftWQ6U6WLbtwlSLMom/g1AfeDFxfZ40lgvvCFL3w3FRccExAXH1hXuZM6j6U/MtWCN12eTy6IKlaQZMVuPp83ZjrZ2qPkorKgdFwrXTdtZmbmtztpmwDExZ/jQbr3q9pT2qh7UYlZHFkWGfl8/m1Tx7ctLlHT0Lw4+YkRbRPoFIGBuCgI21VO1Z7SdKDVrS0RQVmOBCt280kV8wUl6iRJXpx0xGhubu4Pjxw5crfp60gbEBcJoqHxuqjGb9Bit7HnSEZS4lIoFIwoSxw7vaNmioKKE7XKdBznA4GelEEgLgJMdO9X1b6Ytl78ApJJWBDFYnFH7AdNiKCB6d7e3lNPPPFEqC+uLAFx8UC7nefm5v4mzDAzHgq2qjbCmVzwfoHdJKyXQqEgNt0CYjve4hjYDR2Enp6ec0eOHOmIndMQFw/UVW5ubu5jJlwX2R4gG7GQqOXrptHdXOhHHOKiwu/43vddFdAtlUqLGzZs+Kjtc04LEBeOY8eOHaKucrT4ZX1ag6CyXmwEdmWQkMXtGpkSF5P9WuJAFtDN5/Otbdu2fXh0dFTcXbwNgbgwqKtcs9l8zP2dFqQJ60JmvdA3oslvZQoq+glM3HR1dUVWBtuFgCp3Usfi0w3mDgwM3Pvoo4+KR0a2KRAXhqirnIleuKp4yNzcXKTX9qIKLCbhGnV1dSXq0+hYPSoLK+yGRS/9/f3fHBsb+5bvA9sMiMu77tDzoq5ypnrhyqwX0ws+ba5RuVyOHLiKkopOYvuD94ukp6fn9FNPPfWp2E8kBXS8uHzta1/7UKPRuE92P4lL1EVJf3Cib0jTw8zS5hoVCoVEAyZRNiOGhf+cy+XyW1/84hdvjf0kUkLHi8vWrVsPqTItJAAmrBdZ/xXT1kuaXKN+RbGPKtbhErWALqq4BG0SxUOZoY0bN3440glknI4WF9ZV7h7azaz6xjdhvcj6r5iu2E2T5aJa3KaySTYJ+5lTZmjz5s2/10mZIREdKy6svH+1q9zmzZuVe3SiWi+qBtAmLQo6TloK6lR7rHRIur1lGOj937p162eeeOKJf7V+8imnky2XNbud6Y+CLBgZJqwX2R4g060R0mK9UKYsClnY+Oi1znbs2PEnmL74Lh0pLtVqdVxU3k/f+LJvMvpDjxoDkAV2Tde8RK3dMEm5XA59wCRbRujiEZcTBw4cmEz1CcdIx4kL6yr3kOx+ShvLCqNM1KXEYb3QH7zKxYu5pD50P12Z5ZLUTGwfTo2MjAyn8cSSoqPERaerHJnysgZMJlpHyiwj0+5KWjrU9fb2trXlwjjjOM6+VJxJiug0y0XYvd+LKsgXdWGSeImyKKZ73qriLnEWl+Xz+dAD0tIec2F/J7QJbXhkZMT89LuM0zHiwrrK3aHzWNvtEuJwjVSWS5xzjbZs2SJMkfntycmQ1ULCcjoF55E6OkJcwnSVs5lxiSslraozict6kZ2D356cLGSKisXiyZGREa3m7Z1I24tL2K5yqt60UUVA5hqZ7vOShqyR3zRKGaqgs24bBpvl/5s2bfrJ4cOHP27tAG1AJ1guwrSzDqo+uFGx+douKnGJOe7iPyHNg0pcdM9dR1xUx5E9n0r7v/SlL92idRIdTCeIy56wT7RZ6SoTF7IoTLkEqsVFx4hLYLq7uwMfKK50eVBxKRaLjd7e3g9aPq22oO3FZWhoiOpa7qQ6hKDPtZlxkdWimHSNyP1S7eGJS1wKhYJRyyUpyALr6+t7oNP3DOnSEQHdoaGhWliRkVkvJham7LVNxkPS4BqVy+VrgtuUz0mDuHjPsa+v7887selTWDqqzsUjMmd0niNbnPTHb6LPiwiTjZ1KpZL0vhjFJfAkAD9x0REfE5sSXddoYGDge4cOHXrM9wlglY7cW8REhtLTDzqOozRxVXGLqN+ucWww9AtqxrGRsVwuyxVOgE42KC7Lhr4AKDN06NCh34nlgG1ER/dzGRoaOj40NLRHJTI2a0VUtSimXCO/pkxxLFKRiKqK6JJoTyljYGDgJ93d3Xel5oQyRMd3onN8RIaCorKFYGJhxuEaJV1MJ6pIDjqlMAwG6lxme3p6bkMANxwQFw6PyKwOLpL9kV67ti5OGZg4Fn5KKnVXfR2/0n+dXc86wq4jLgoXjD7/CvYMhQfiIoBEhtXHHKQ/MtkfqYmBXXF0jVMFdZ2YBIYfM2Ii0GrKnVNc+wHsGYoGxEXC0NDQzNDQ0BiJzIYNG57dsGGDcKdf1IWpcrtMxV38vsHjEBd+zIiq459jOA4U0jWaGBkZCbxlBKwF4uIDicwDDzzwx9u3b9++efPmEzKRiYJsAZhq7JQGcaExI9Qn5+abb461xiWEuLwwMjJywNgJdDAQF01IZD7xiU8McyKz8kSbxXSOIdeILCNVnCOOjNFNN93U/973vtfYZkJLGy+p9gnd5AwBcQkIJzI3DQwMvGhiREbSQd04Wl/mcvrdLnUCurqZtADxHQrg7kMA1xwQl5AMDQ1N7d+//7c2bdp0EzVmjvJaSYuLYyjzpcIvqJwCKDM0lfaTzBIQl4iQyAwNDZEpHVpk/EZwmBAYv/RvWjYKmsjA8ehMdqTSA2SGzANxMYRHZF4I+qq2NximoVK3UCj4FqPpXqvuBAA/t5UGxSMzZAeIi2GYyOwLugNbtQhMLHw/yyWOjFEul4s2JS0EKlEtl8sXO3lQvG0gLpYI2uZB5RrZrgR2sW29lEol3zS+abdIJtpsUPxtRg8G1gBxsYyuyKgWv6kF5+ci2OJvt3YAAAU8SURBVA7q5vP5Pr/HBLGgdMXQmzHCoPh4gLjEhF8vmTjcFr/AsW3Lpaura7PJ19M9X+9729/f/wgGxdsH4hIzsl4yfm6LiR3SfpaLbXHxE1Bb8Duw+/v7v3nw4MHxRE6kw4C4JIS3zUMcqeKkLRe/49s6B1e4qenTU0899SnjBwBCIC4Jw4tMuVyet3k2fgJG1pHtYWS5XE65nyGIuOimo0lcuru7ZzAOJF4gLimBRObTn/5077Zt2z7X3d29boXFsYHR1HFU5PP5t60eQEC5XJ7etGnTYNzH7XQgLinj/vvv/4tt27bt8O7Ajmu8aQyuUdx/cyt7hpAZih+ISwoR7MA20uZBx3KxLWKFQsHYATRT9BgUnxAQlxTDi0x/f/8E33ozDDrZGtuVusVicYep19I414cxKD45IC4ZgETm3nvvPcC33rR11jFYLoFnGIXkxMjICFLOCQJxyRBc683BsDuw/Vwj2zEXv1ob3QyQD2dGRkbQ9ClhIC4ZJEqbBx3XqNEw3slzFRPNtVwkQkiB24qxg4DQQFwyjIleMiJMbx70ks/nL5h4HYG4oJtcioC4tAFBREbHcrBpuTjvFtJZaYCLcSDpAuLSRnAiI92BrVOCb9ty6erqstHX5SCaPqULiEsbErSXTNzk83ljphFzjSgzNNYxH3BGgLi0MSKR0XGLbNe6lEql3bL7go4eqdfrPyF3yMR5AbNAXDoAXmSKxeJLSV+xasxIEHGhpk+Li4t3IYCbTiAuHQSJzH333XcbbY5U7cC2HdA1MWaEUuoDAwP3Ys9Qesm1Wq1Ofw86lueff/6z8/PzB5eWltZNDqPpiDa5cEGcjf7Zz36mVUhHTZ/QmyXdQFyAc/z48aOLi4sPXbt2bbVlm21xuXjx4nSz2VwXe9ERl76+vh8fPnz4wzbPD0QH4gJW4UVm165dVttSXrp06c1Go/FL3tv9xKVcLr919OjRnfjU0g9iLmCV4eHhR3fs2LGT2jwsLy/P2XxnZGNGVLOd2TgQWCwZAZYLEFKtVgdYipd++k2/SwsLC5fn5+fXTQO4ePHiyo8XNg7k9tHR0f/EJ5YNIC5AiS2RoRlJly9fXne7TFy2bNnyB2NjY9/Cp5UdIC5AC9MiQ+nuS5curbud4i0Ud+FBZiibQFxAIKrVKjWsolL7/VHfOVE62isuvb29rx45cuRX8CllD4gLCIUJkXn77bcXW63Wms50tGny7NmzK/+nQfFHjx7djk8omyBbBEJhopeMaMyIu/cJg+KzDywXYIQwlszMzMy5er1+o/f26enpxsaNGx9AADfbQFyAUarVaoWJzB1+rzs3Nzd99erVdVW6S0tLv/vII4/8Mz6ZbANxAVbQEZnFxcXFK1eueKcBPIimT+0BxAVYRSUyglqXE+ja3z5AXEAsiESGMkNcwRyNA8E85zYC2SIQC1zDqgfZ+A++Kx7GgbQhsFxAIlSrVXJ/xshyaTab+9C1v/2AuIBEef755z90//33v4JPof2AuAAArICYCwDAChAXAIAVIC4AACtAXAAAVoC4AACsAHEBAFgB4gIAsALEBQBgBYgLAMAKEBcAgBUgLgAAK0BcAABWgLgAAKwAcQEAWAHiAgCwAsQFAGAFiAsAwAoQFwCAFSAuAAArQFwAAFaAuAAArABxAQBYAeICALACxAUAYAWICwDAChAXAIAVIC4AACtAXAAAVoC4AACsAHEBAFgB4gIAsALEBQBgBYgLAMAKEBcAgBUgLgAAK0BcAABWgLgAAKwAcQEAWAHiAgAwj+M4/wf2ssl/gD3QSQAAAABJRU5ErkJggg==",
                                        onClick: function(t) {
                                            return e.showGiftHint(t, 3)
                                        }
                                    }), Object(s.jsx)("img", {
                                        id: "gift5",
                                        className: 4 == this.state.counter ? "gift movinggift" : "gift",
                                        src: this.state.counter > 3 ? Zs : qs,
                                        onClick: function(t) {
                                            return e.showGiftHint(t, 4)
                                        }
                                    })]
                                }), Object(s.jsx)("div", {
                                    id: "hint",
                                    style: {
                                        display: this.state.showHint ? "block" : "none"
                                    },
                                    onClick: function(t) {
                                        t.stopPropagation(), e.state.counter < 4 && !e.state.start && e.setState({
                                            showAnswer: !0,
                                            showHint: !1
                                        })
                                    },
                                    children: Object(s.jsx)("div", {
                                        id: "hinttext",
                                        children: this.state.start ? Object(s.jsxs)("span", {
                                            children: ["Oh nee, de kerstman heeft het dit jaar wat moeilijker gemaakt...", Object(s.jsx)("br", {}), "Los jij het grote kerst-mysterie op?"]
                                        }) : this.state.hints[this.state.counter]
                                    })
                                }), Object(s.jsxs)("div", {
                                    id: "answer",
                                    style: {
                                        display: this.state.showAnswer ? "block" : "none"
                                    },
                                    onClick: function(e) {
                                        return e.stopPropagation()
                                    },
                                    children: [Object(s.jsx)("div", {
                                        id: "back-button",
                                        onClick: function(t) {
                                            t.stopPropagation(), e.setState({
                                                showAnswer: !1,
                                                showHint: !0
                                            })
                                        },
                                        children: "Bekijk het raadsel"
                                    }), Object(s.jsxs)("div", {
                                        id: "fillin",
                                        children: ["Los jij het mysterie op?", Object(s.jsx)("br", {}), Object(s.jsx)("input", {
                                            value: this.state.answer,
                                            onChange: function(t) {
                                                return e.setState({
                                                    answer: t.target.value
                                                })
                                            },
                                            id: "password",
                                            type: "text",
                                            size: "13"
                                        }), Object(s.jsx)("p", {
                                            id: "wrong"
                                        }), Object(s.jsx)("div", {
                                            id: "submit",
                                            onClick: this.submit,
                                            children: Object(s.jsx)("img", {
                                                id: "bannergift",
                                                src: Xs
                                            })
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component),
                tn = (i(640), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).setText = s.setText.bind(Object(ve.a)(s)), s.save = s.save.bind(Object(ve.a)(s)), s.state = {
                            saving: !1,
                            hints: ["Laden...", "Laden...", "Laden...", "Laden...", "Laden..."]
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "save",
                        value: function() {
                            var e = this;
                            this.setState({
                                saving: !0
                            });
                            var t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user"));
                            fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "POST",
                                headers: {
                                    Authorization: "Bearer " + i.token,
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    hints: this.state.hints
                                })
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                e.setState({
                                    saving: !1
                                })
                            })).catch((function(e) {
                                return console.log(e)
                            }))
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            console.log("mount");
                            var t = JSON.parse(localStorage.getItem("game_info")),
                                i = JSON.parse(localStorage.getItem("user"));
                            console.log(t), fetch("http://localhost:8000/api/gamesettings?game=" + t.game + "&order=" + t.order, {
                                method: "GET",
                                headers: {
                                    Authorization: "Bearer " + i.token
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(t) {
                                console.log(t), t.hints ? e.setState({
                                    hints: t.hints
                                }) : e.setState({
                                    hints: ["", "", "", "", ""]
                                })
                            }))
                        }
                    }, {
                        key: "setText",
                        value: function(e, t) {
                            var i = this.state.hints;
                            i[t] = e.target.value, this.setState({
                                hints: i
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(s.jsxs)("div", {
                                className: "CHRISTMAS",
                                children: [Object(s.jsx)("a", {
                                    onClick: function() {
                                        return window.location.href = e.props.back
                                    },
                                    id: "back",
                                    children: "Terug"
                                }), Object(s.jsxs)("div", {
                                    className: "hint",
                                    children: ["Hint/Raadsel 1", Object(s.jsx)("br", {}), Object(s.jsx)("textarea", {
                                        id: "Text1",
                                        cols: "50",
                                        rows: "2",
                                        value: this.state.hints[0],
                                        onChange: function(t) {
                                            return e.setText(t, 0)
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    className: "hint",
                                    children: ["Hint/Raadsel 2", Object(s.jsx)("br", {}), Object(s.jsx)("textarea", {
                                        id: "Text2",
                                        cols: "50",
                                        rows: "2",
                                        value: this.state.hints[1],
                                        onChange: function(t) {
                                            return e.setText(t, 1)
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    className: "hint",
                                    children: ["Hint/Raadsel 3", Object(s.jsx)("br", {}), Object(s.jsx)("textarea", {
                                        id: "Text3",
                                        cols: "50",
                                        rows: "2",
                                        value: this.state.hints[2],
                                        onChange: function(t) {
                                            return e.setText(t, 2)
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    className: "hint",
                                    children: ["Hint/Raadsel 4", Object(s.jsx)("br", {}), Object(s.jsx)("textarea", {
                                        id: "Text4",
                                        cols: "50",
                                        rows: "2",
                                        value: this.state.hints[3],
                                        onChange: function(t) {
                                            return e.setText(t, 3)
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    className: "hint",
                                    children: ["Hint/Raadsel 5", Object(s.jsx)("br", {}), Object(s.jsx)("textarea", {
                                        id: "Text5",
                                        cols: "50",
                                        rows: "2",
                                        value: this.state.hints[4],
                                        onChange: function(t) {
                                            return e.setText(t, 4)
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    className: "bottom",
                                    children: ["  ", Object(s.jsx)("a", {
                                        onClick: this.save,
                                        class: "link",
                                        children: this.state.saving ? "Even Geduld..." : "Opslaan"
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(a.a.Component)),
                sn = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            document.title = "Kerst Mysterie - Festiviti"
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return "play" == this.props.match.params.phase ? Object(s.jsx)(Ce, {
                                background: Us,
                                next: "gifts",
                                escape: !1,
                                settings: !0
                            }) : "test" == this.props.match.params.phase ? Object(s.jsx)(ke, {
                                background: Us,
                                next: "testgifts",
                                escape: !1,
                                settings: !0
                            }) : "testgifts" == this.props.match.params.phase ? Object(s.jsx)(en, {
                                back: "test"
                            }) : "gifts" == this.props.match.params.phase ? Object(s.jsx)(en, {
                                back: "play"
                            }) : "testsettings" == this.props.match.params.phase ? Object(s.jsx)(tn, {
                                back: "test"
                            }) : "startsettings" == this.props.match.params.phase ? Object(s.jsx)(tn, {
                                back: "play"
                            }) : Object(s.jsx)(A.a, {
                                to: "/overview"
                            })
                        }
                    }]), i
                }(a.a.Component),
                nn = Object(A.h)(sn),
                an = i(273);
            var cn = !0;

            function rn() {
                console.log(cn), cn ? (document.getElementById("testmode").style.bottom = 0, document.getElementById("testmode").style.right = 0, document.getElementById("testmode").style.top = "", document.getElementById("testmode").style.left = "", cn = !1) : (document.getElementById("testmode").style.top = 0, document.getElementById("testmode").style.left = 0, document.getElementById("testmode").style.bottom = "", document.getElementById("testmode").style.right = "", cn = !0)
            }
            var on = function() {
                    var e = Object(A.g)(),
                        t = e.sku,
                        i = e.phase,
                        a = Object(an.a)(["games"]),
                        c = a.t,
                        r = (a.i18n, JSON.parse(localStorage.getItem("user"))),
                        o = JSON.parse(localStorage.getItem("game_info"));

                    /* return fetch("/api/play?game=" + o.game + "&order=" + o.order, {
                        method: "GET",
                        headers: {
                            Authorization: "Bearer " + r.token
                        }
                    }).then((function(e) {
                        return e.json()
                    })).then((function(e) {
                        return function(e) {
                            var t = JSON.parse(localStorage.getItem("game_info"));
                            t.testmode && e.test, !t.testmode && e.play
                        }(e)
                    })), */
                    return "BOX_ER01" == t || "BOX_ER01X2" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ge, {
                            phase: i
                        })]
                    }) : "FB_ER01" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ie, {
                            phase: i
                        })]
                    }) : "FB_ER02" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "movie" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ot, {
                            phase: i
                        })]
                    }) : "FB_ER03" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [ 
                            /* "test" != i && "end" != i && "menu" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(vi, {
                            phase: i
                        })]
                    }) : "FB_ER04" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "menu" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ut, {
                            phase: i
                        })]
                    }) : "FB_MINI2" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ls, {
                            phase: i
                        })]
                    }) : "FB_SH01" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "chat" != i && "welcome" != i && "testsettings" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(os, {
                            phase: i
                        })]
                    }) : "SPECIAL_2022" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "chat" != i && "welcome" != i && "testsettings" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(nn, {
                            phase: i
                        })]
                    }) : "FB_ACT02" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "chat" != i && "welcome" != i && "testsettings" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(hs, {
                            phase: i
                        })]
                    }) : "FB_ACT03" == t ? Object(s.jsxs)(n.Suspense, {
                        fallback: "loading",
                        children: [
                            /* "test" != i && "end" != i && "chat" != i && "welcome" != i && "testsettings" != i && o.testmode ? Object(s.jsxs)("div", {
                            id: "testmode",
                            className: "testmode",
                            onMouseOver: rn,
                            children: [Object(s.jsx)("div", {
                                className: "header",
                                children: c("testmode")
                            }), Object(s.jsx)("p", {
                                className: "info",
                                children: c("testinfo")
                            }), Object(s.jsx)("p", {
                                children: c("testanswer")
                            }), Object(s.jsx)("p", {
                                id: "answer",
                                children: c(t + "_" + i)
                            })]
                        }) : Object(s.jsx)("div", {}), */
                        Object(s.jsx)(Ts, {
                            phase: i
                        })]
                    }) : void 0
                },
                ln = i(54),
                dn = i.n(ln),
                jn = i(129);
            var hn = Object(p.a)()((function(e) {
                    var t = {
                            marginBottom: 15,
                            background: "#F0730D",
                            borderColor: "#F0730D"
                        },
                        i = Object(an.a)().t;
                    return Object(s.jsx)(Rt.a, {
                        title: i("download-header"),
                        visible: e.visible,
                        onCancel: function() {
                            return e.hide()
                        },
                        footer: [],
                        children: Object(s.jsxs)("div", {
                            style: {
                                textAlign: "center"
                            },
                            children: [Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/" + e.game.sku + "/Handleiding.pdf",
                                style: t,
                                download: !0,
                                children: i("download-manual")
                            }), Object(s.jsx)("br", {}), "BOX" == e.game.info.type && Object(s.jsxs)("div", {
                                children: [Object(s.jsx)("p", {
                                    children: "Druk zelf nog extra reserve documenten af:"
                                }), Object(s.jsx)(M.a, {
                                    type: "primary",
                                    target: "_blank",
                                    href: "/downloads/" + e.game.sku + "/Box_Prints.pdf",
                                    style: t,
                                    download: !0,
                                    children: i("download-extra")
                                })]
                            }), "FB_ACT02" !== e.game.sku && "BOX" != e.game.info.type && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/" + e.game.sku + "/Puzzels.pdf",
                                style: t,
                                download: !0,
                                children: i("download-puzzles")
                            }), Object(s.jsx)("br", {}), "FB_ER01" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ER01/Brief_enkelvoud.pdf",
                                style: t,
                                download: !0,
                                children: i("download-letter-1")
                            }), Object(s.jsx)("br", {}), "FB_ER01" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ER01/Brief_meervoud.pdf",
                                style: t,
                                download: !0,
                                children: i("download-letter-2")
                            }), "FB_ACT02" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ACT02/Brief.pdf",
                                style: t,
                                download: !0,
                                children: i("download-letter")
                            }), Object(s.jsx)("br", {}), "FB_ACT02" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ACT02/Doolhof.pdf",
                                style: t,
                                download: !0,
                                children: i("download-maze")
                            }), Object(s.jsx)("br", {}), "FB_ACT02" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ACT02/Embleem.pdf",
                                style: t,
                                download: !0,
                                children: i("download-emblem")
                            }), Object(s.jsx)("br", {}), "FB_ACT02" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ACT02/Wachtwoorden.pdf",
                                style: t,
                                download: !0,
                                children: i("download-passwords")
                            }), Object(s.jsx)("br", {}), "FB_ACT02" == e.game.sku && Object(s.jsx)(M.a, {
                                type: "primary",
                                target: "_blank",
                                href: "/downloads/FB_ACT02/Memory.pdf",
                                style: t,
                                download: !0,
                                children: i("download-memory")
                            }), Object(s.jsx)("br", {})]
                        })
                    })
                })),
                un = i(650),
                bn = i(648),
                gn = i(654),
                mn = i(160),
                pn = i(658),
                xn = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i() {
                        return Object(l.a)(this, i), t.apply(this, arguments)
                    }
                    return Object(d.a)(i, [{
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                className: "ACTIE",
                                children: [Object(s.jsx)("img", {
                                    src: e("refer-img")
                                }), Object(s.jsxs)("p", {
                                    className: "center desc",
                                    children: [Object(s.jsx)("span", {
                                        id: "actietitle",
                                        children: e("refer-title")
                                    }), e("refer-desc1"), Object(s.jsx)("br", {}), " ", e("refer-desc2"), " ", Object(s.jsx)("span", {
                                        className: "accent",
                                        children: e("refer-desc3")
                                    }), ".", Object(s.jsx)("br", {}), Object(s.jsx)("br", {}), " ", e("refer-desc4"), " ", Object(s.jsx)("span", {
                                        className: "accent",
                                        children: e("refer-desc5")
                                    }), " ", e("refer-desc6"), Object(s.jsx)("br", {}), " ", e("refer-desc7")]
                                }), Object(s.jsxs)("div", {
                                    id: "actioninfo",
                                    children: [Object(s.jsx)("a", {
                                        className: "actiebutton center",
                                        target: "_blank",
                                        href: "https://www.facebook.com/sharer/sharer.php?u=https://festivitibox.com",
                                        children: e("refer-share")
                                    }), Object(s.jsxs)("div", {
                                        id: "invite",
                                        children: [Object(s.jsx)("input", {
                                            className: "w3-input",
                                            type: "text",
                                            placeholder: e("refer-input"),
                                            id: "friend"
                                        }), Object(s.jsx)("a", {
                                            target: "_blank",
                                            id: "sendbutton",
                                            className: "actiebutton",
                                            children: e("refer-invite")
                                        })]
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(n.Component),
                On = (Object(p.a)()(xn), function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        return Object(l.a)(this, i), t.call(this, e)
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            for (var e = document.getElementsByClassName("accordion"), t = document.getElementsByClassName("panel"), i = 0; i < e.length; i++) e[i].onclick = function() {
                                for (var i = !this.classList.contains("active"), s = 0; s < e.length; s++) e[s].classList.remove("active");
                                for (s = 0; s < t.length; s++) t[s].classList.remove("show");
                                i && (this.classList.toggle("active"), this.nextElementSibling.classList.toggle("show"))
                            }
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.props.t;
                            return Object(s.jsxs)("div", {
                                style: {
                                    width: 700,
                                    display: "block",
                                    margin: "auto",
                                    paddingTop: 70
                                },
                                children: [Object(s.jsx)("p", {
                                    className: "accordion",
                                    children: e("faq-q1")
                                }), Object(s.jsx)("div", {
                                    className: "panel",
                                    children: e("faq-a1")
                                }), Object(s.jsx)("p", {
                                    className: "accordion",
                                    children: e("faq-q2")
                                }), Object(s.jsx)("div", {
                                    className: "panel",
                                    children: e("faq-a2")
                                }), Object(s.jsx)("p", {
                                    className: "accordion",
                                    children: e("faq-q3")
                                }), Object(s.jsx)("div", {
                                    className: "panel",
                                    children: e("faq-a3")
                                }), Object(s.jsx)("p", {
                                    className: "accordion",
                                    children: e("faq-q4")
                                }), Object(s.jsx)("div", {
                                    className: "panel",
                                    children: e("faq-a4")
                                }), Object(s.jsx)("p", {
                                    className: "accordion",
                                    children: e("faq-q5")
                                }), Object(s.jsx)("div", {
                                    className: "panel",
                                    children: e("faq-a5")
                                })]
                            })
                        }
                    }]), i
                }(n.Component)),
                An = Object(p.a)()(On),
                fn = i.p + "static/media/fotochallenge.6e11abca.jpg";
            var vn = Object(p.a)()((function(e) {
                    var t = Object(n.useState)(!1),
                        i = Object(o.a)(t, 2),
                        a = i[0],
                        c = i[1],
                        r = Object(n.useState)(""),
                        l = Object(o.a)(r, 2),
                        d = l[0],
                        j = l[1],
                        h = {
                            fontSize: 25,
                            color: "#F0730D",
                            fontWeight: 600,
                            marginRight: 10
                        },
                        u = {
                            fontSize: 18,
                            color: "#F0730D",
                            fontWeight: 600
                        },
                        b = Object(an.a)().t;
                    return Object(s.jsxs)("div", {
                        style: {
                            width: 700,
                            display: "block",
                            margin: "auto",
                            paddingTop: 70
                        },
                        children: [Object(s.jsxs)(un.a, {
                            title: b("challenge-title"),
                            style: {
                                width: 650,
                                marginBottom: 30,
                                fontSize: 16
                            },
                            headStyle: {
                                backgroundColor: "#0EAD81",
                                color: "white",
                                fontSize: 22
                            },
                            cover: Object(s.jsx)("img", {
                                src: fn,
                                style: {
                                    width: 450,
                                    marginLeft: 100
                                }
                            }),
                            children: [Object(s.jsx)("p", {
                                children: b("challenge-desc2")
                            }), Object(s.jsxs)("p", {
                                style: {
                                    paddingLeft: 30
                                },
                                children: [Object(s.jsx)("span", {
                                    style: h,
                                    children: "1."
                                }), b("challenge-step1-1") + " ", Object(s.jsx)("span", {
                                    style: u,
                                    children: b("challenge-step1-2")
                                }), " ", " " + b("challenge-step1-3"), Object(s.jsx)("br", {}), Object(s.jsx)("span", {
                                    style: h,
                                    children: "2."
                                }), b("challenge-step2-1") + " ", Object(s.jsx)("span", {
                                    style: u,
                                    children: b("challenge-step2-2")
                                }), " ", " " + b("challenge-step2-3"), Object(s.jsx)("br", {}), Object(s.jsx)("span", {
                                    style: h,
                                    children: "3."
                                }), b("challenge-step3-1") + " ", Object(s.jsx)("span", {
                                    style: u,
                                    children: b("challenge-step3-2")
                                }), " ", " " + b("challenge-step3-3")]
                            })]
                        }), Object(s.jsxs)(un.a, {
                            ref: e.friendRef,
                            title: b("free-header"),
                            id: "friends",
                            style: {
                                width: 650,
                                fontSize: 16
                            },
                            headStyle: {
                                backgroundColor: "#0EAD81",
                                color: "white",
                                fontSize: 22
                            },
                            children: [Object(s.jsxs)("p", {
                                children: [b("free-intro") + " ", Object(s.jsxs)("strong", {
                                    style: {
                                        color: "#F0730D"
                                    },
                                    children: [b("free-reduction"), " "]
                                })]
                            }), Object(s.jsxs)("p", {
                                children: [b("free-desc") + " ", Object(s.jsxs)("strong", {
                                    style: {
                                        color: "#F0730D"
                                    },
                                    children: [" ", b("free-desc2")]
                                })]
                            }), Object(s.jsxs)("p", {
                                style: {
                                    textAlign: "center",
                                    margin: 0
                                },
                                children: ["  " + b("free-code"), Object(s.jsx)("strong", {
                                    style: {
                                        color: "#F0730D",
                                        fontSize: 20
                                    },
                                    children: "  " + e.code
                                })]
                            }), Object(s.jsx)("p", {
                                style: {
                                    color: "#0EAD81",
                                    textAlign: "center"
                                },
                                children: b("free-score").replace("FF", e.friends)
                            }), Object(s.jsxs)("center", {
                                children: [Object(s.jsx)(It.a, {
                                    value: d,
                                    onChange: function(e) {
                                        return j(e.target.value)
                                    },
                                    style: {
                                        width: 300,
                                        margin: 30
                                    }
                                }), Object(s.jsx)(M.a, {
                                    onClick: function() {
                                        c(!0),
                                            function(e, t, i) {
                                                if (/^.+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(e)) {
                                                    var s = JSON.parse(localStorage.getItem("user"));
                                                    fetch("http://localhost:8000/api/referral?email=" + e, {
                                                        method: "POST",
                                                        headers: {
                                                            Authorization: "Bearer " + s.token
                                                        }
                                                    }).then((function(e) {
                                                        return e.json()
                                                    })).then((function(e) {
                                                        console.log(e), t(!1), i("Verstuurd!")
                                                    }))
                                                } else console.log("INVALID"), t(!1)
                                            }(d, c, j)
                                    },
                                    loading: a,
                                    style: {
                                        marginLeft: 20,
                                        background: "#0EAD81",
                                        borderColor: "#0EAD81",
                                        color: "white",
                                        fontWeight: 600
                                    },
                                    children: b("free-invite")
                                })]
                            })]
                        })]
                    })
                })),
                yn = un.a.Meta,
                wn = bn.a.Header,
                kn = bn.a.Content,
                Cn = bn.a.Footer,
                En = (bn.a.Sider, Object(s.jsx)(Q.a, {
                    children: Object(s.jsx)(Q.a.Item, {
                        children: Object(s.jsx)("a", {
                            onClick: function() {
                                L.changeLanguage("nl")
                            },
                            children: "Nederlands"
                        })
                    }, "0")
                }));
            var In = function() {
                    return Object(s.jsx)(ht.a, {
                        className: "gutter-row",
                        style: {
                            width: 480
                        },
                        children: Object(s.jsxs)(un.a, {
                            style: {
                                margin: 20,
                                height: 460,
                                width: 450
                            },
                            children: [Object(s.jsx)(gn.a, {
                                loading: !0,
                                active: !0,
                                children: Object(s.jsx)(yn, {
                                    title: "Card title",
                                    description: "This is the description"
                                })
                            }), Object(s.jsx)(gn.a, {
                                loading: !0,
                                active: !0,
                                children: Object(s.jsx)(yn, {
                                    title: "Card title",
                                    description: "This is the description"
                                })
                            })]
                        })
                    })
                },
                Bn = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            games: [],
                            modalVisible: !1,
                            popupVisible: !1,
                            sku: "",
                            order: "",
                            menuSelect: "1"
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            console.log("mount"), setTimeout((function() {
                                    e.setState({
                                        popupVisible: !1
                                    })
                                }), 3e3),
                                function() {
                                    var e = JSON.parse(localStorage.getItem("user"));
                                    return fetch("http://localhost:8000/api/game_list", {
                                        method: "GET",
                                        headers: {
                                            Authorization: "Bearer " + e.token
                                        }
                                    }).then((function(e) {
                                        return e.json()
                                    }))
                                }().then((function(t) {
                                    e.setState({
                                        games: t
                                    })
                                })).catch(),
                                function() {
                                    var e = JSON.parse(localStorage.getItem("user"));
                                    return fetch("http://localhost:8000/api/referral", {
                                        method: "GET",
                                        headers: {
                                            Authorization: "Bearer " + e.token
                                        }
                                    }).then((function(e) {
                                        return e.json()
                                    }))
                                }().then((function(t) {
                                    e.setState({
                                        code: t.code,
                                        count: t.count
                                    })
                                })).catch()
                        }
                    }, {
                        key: "logout",
                        value: function() {
                            localStorage.setItem("user", null), window.location.href = ""
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            console.log(this.state);
                            var t = this.props.t;
                            return "4" == this.state.menuSelect && (window.location.href = "https://festiviti.eu/pages/festiviti-party"), Object(s.jsxs)(bn.a, {
                                style: {
                                    background: "white"
                                },
                                children: [Object(s.jsxs)(wn, {
                                    className: "header",
                                    style: {
                                        backgroundColor: "white"
                                    },
                                    children: [Object(s.jsx)("img", {
                                        className: "logo",
                                        src: g,
                                        style: {
                                            width: 350,
                                            margin: "10px 0px 0 0",
                                            float: "left"
                                        }
                                    }), 
                                    /* Object(s.jsxs)(Q.a, {
                                        mode: "horizontal",
                                        defaultSelectedKeys: [this.state.menuSelect],
                                        onClick: function(t) {
                                            return e.setState({
                                                menuSelect: t.key
                                            })
                                        },
                                        children: [Object(s.jsx)(Q.a.Item, {
                                            children: t("menu-activities")
                                        }, "1"), Object(s.jsx)(Q.a.Item, {
                                            children: t("menu-questions")
                                        }, "2"), Object(s.jsx)(Q.a.Item, {
                                            children: t("menu-promo")
                                        }, "3"), Object(s.jsx)(M.a, {
                                            id: "logout",
                                            onClick: this.logout,
                                            style: {
                                                float: "right",
                                                marginTop: 15,
                                                marginRight: 10
                                            },
                                            children: t("menu-logout")
                                        })]
                                    }) */
                                    ]
                                }), Object(s.jsxs)(kn, {
                                    style: {
                                        minHeight: "calc(100vh - 135px)"
                                    },
                                    children: [Object(s.jsxs)(Rt.a, {
                                        title: t("challenge-header"),
                                        visible: this.state.popupVisible,
                                        onCancel: function() {
                                            return e.setState({
                                                popupVisible: !1
                                            })
                                        },
                                        footer: [Object(s.jsx)(M.a, {
                                            onClick: function() {
                                                return e.setState({
                                                    popupVisible: !1,
                                                    menuSelect: "3"
                                                })
                                            },
                                            style: {
                                                background: "#F0730D",
                                                color: "white",
                                                borderColor: "#F0730D"
                                            },
                                            children: t("challenge-more")
                                        }, "info")],
                                        children: [Object(s.jsx)("p", {
                                            style: {
                                                textAlign: "center",
                                                fontWeight: 600
                                            },
                                            children: t("challenge-desc")
                                        }), Object(s.jsx)("img", {
                                            src: fn,
                                            style: {
                                                width: 300,
                                                marginLeft: 75
                                            }
                                        })]
                                    }), Object(s.jsxs)("div", {
                                        style: {
                                            width: 960,
                                            display: "block",
                                            margin: "auto"
                                        },
                                        children: ["1" == this.state.menuSelect && Object(s.jsxs)(jt.a, {
                                            gutter: 16,
                                            children: [0 == this.state.games.length && In(), 0 == this.state.games.length && In(), this.state.games.map((function(e, t) {
                                                var i = this;
                                                return e.info.hidden || "GIFT" == e.info.type ? e.info.hidden || "GIFT" != e.info.type ? void 0 : Object(s.jsx)(ht.a, {
                                                    className: "gutter-row",
                                                    style: {
                                                        width: 480
                                                    },
                                                    children: Object(s.jsx)(Ln, {
                                                        game: e
                                                    })
                                                }) : Object(s.jsx)(ht.a, {
                                                    className: "gutter-row",
                                                    style: {
                                                        width: 480
                                                    },
                                                    children: Object(s.jsx)(Qn, {
                                                        game: e,
                                                        showReduction: function() {
                                                            i.setState({
                                                                menuSelect: "3"
                                                            })
                                                        }
                                                    })
                                                })
                                            }), this)]
                                        }), "2" == this.state.menuSelect && Object(s.jsx)(An, {}), "3" == this.state.menuSelect && Object(s.jsx)(vn, {
                                            code: this.state.code,
                                            friends: this.state.count
                                        })]
                                    })]
                                }), Object(s.jsxs)(Cn, {
                                    style: {
                                        height: "70px"
                                    },
                                    children: [Object(s.jsx)("span", {
                                        children: t("footer-contact")
                                    }), 
                                        /* Object(s.jsx)(mn.a, {
                                        overlay: En,
                                        trigger: ["click"],
                                        children: Object(s.jsx)(M.a, {
                                            id: "lan",
                                            style: {
                                                float: "right"
                                            },
                                            children: "Change Language"
                                        })
                                    }) */
                                    ]
                                })]
                            })
                        }
                    }]), i
                }(n.Component);

            function Sn() {
                return (Sn = Object(jn.a)(dn.a.mark((function e(t, i) {
                    var s, n;
                    return dn.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return s = {
                                    order: i,
                                    game: t,
                                    testmode: !1
                                }, localStorage.setItem("game_info", JSON.stringify(s)), n = JSON.parse(localStorage.getItem("user")), e.next = 5, fetch("http://localhost:8000/api/activate?game=" + s.game + "&order=" + s.order, {
                                    method: "GET",
                                    headers: {
                                        Authorization: "Bearer " + n.token
                                    }
                                }).catch((function(e) {
                                    return alert("Something went wrong. Contact us at info@festiviti.eu")
                                }));
                            case 5:
                                e.sent, window.location.href = "/game/" + t + "/play";
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function Ln(e) {
                var t = Object(an.a)(["translation", "games"]),
                    i = t.t,
                    a = t.i18n,
                    c = Object(n.useState)("..."),
                    r = Object(o.a)(c, 2),
                    l = r[0],
                    d = r[1],
                    j = new Date(Date.parse(e.game.order_date)).toLocaleDateString(a.language);
                return Object(n.useEffect)((function() {
                    (function() {
                        var t = Object(jn.a)(dn.a.mark((function t() {
                            var i;
                            return dn.a.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        try {
                                            i = JSON.parse(localStorage.getItem("user")), fetch("http://localhost:8000/api/gift?order_id=" + e.game.order, {
                                                method: "GET",
                                                headers: {
                                                    Authorization: "Bearer " + i.token
                                                }
                                            }).then((function(e) {
                                                return e.json()
                                            })).then((function(e) {
                                                return d(e.code)
                                            }))
                                        } catch (s) {
                                            console.log(s)
                                        }
                                    case 1:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })));
                        return function() {
                            return t.apply(this, arguments)
                        }
                    })()()
                }), []), Object(s.jsx)("div", {
                    children: Object(s.jsxs)(un.a, {
                        style: {
                            margin: 20,
                            height: 510,
                            width: 450
                        },
                        headStyle: {
                            color: "#F0730D"
                        },
                        cover: Object(s.jsx)("img", {
                            alt: "example",
                            src: "/imgs/games/" + e.game.sku + ".png",
                            style: e.game.valid ? {
                                height: 270
                            } : {
                                height: 270,
                                filter: "brightnes(50%)"
                            }
                        }),
                        children: [Object(s.jsx)(yn, {
                            description: "Aangekocht op " + j
                        }), Object(s.jsxs)("div", {
                            style: {
                                height: 50,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [i(e.game.sku + "_DESC"), " "]
                        }), Object(s.jsxs)("div", {
                            style: {
                                textAlign: "center"
                            },
                            children: [Object(s.jsxs)("p", {
                                style: {
                                    fontWeight: 700,
                                    fontSize: 20
                                },
                                children: [i("gift-code"), " ", Object(s.jsx)("span", {
                                    style: {
                                        color: "#F0730D"
                                    },
                                    children: l
                                })]
                            }), Object(s.jsx)(M.a, {
                                type: "primary",
                                href: "/downloads/escaperoom-cadeaubon.pdf",
                                style: {
                                    background: "#F0730D",
                                    borderColor: "#F0730D"
                                },
                                download: !0,
                                children: i("gift-download")
                            })]
                        })]
                    })
                })
            }

            function Qn(e) {
                var t = Object(an.a)(),
                    i = t.t,
                    a = t.i18n,
                    c = Object(n.useState)(0),
                    r = Object(o.a)(c, 2),
                    l = r[0],
                    d = r[1],
                    j = Object(n.useState)(0),
                    h = Object(o.a)(j, 2),
                    u = h[0],
                    b = h[1],
                    g = Object(n.useState)(!1),
                    m = Object(o.a)(g, 2),
                    p = m[0],
                    x = m[1],
                    O = new Date(Date.parse(e.game.order_date)).toLocaleDateString(a.language);
                return Object(s.jsxs)("div", {
                    children: [Object(s.jsx)(hn, {
                        game: e.game,
                        visible: u,
                        hide: function() {
                            return b(!1)
                        }
                    }), Object(s.jsxs)(Rt.a, {
                        title: i("card-activate"),
                        visible: l,
                        onCancel: function() {
                            d(!1)
                        },
                        footer: [Object(s.jsx)(M.a, {
                            onClick: function() {
                                d(!1)
                            },
                            children: i("cancel")
                        }, "back"), Object(s.jsx)(M.a, {
                            style: {
                                background: "#F0730D",
                                borderColor: "#F0730D"
                            },
                            type: "primary",
                            loading: p,
                            onClick: function() {
                                x(!0),
                                    function(e, t) {
                                        Sn.apply(this, arguments)
                                    }(e.game.sku, e.game.order)
                            },
                            children: i("card-activate")
                        }, "submit")],
                        children: [Object(s.jsx)("p", {
                            children: i("alert-activate")
                        }), Object(s.jsx)("p", {
                            children: i("alert-later")
                        })]
                    }), Object(s.jsxs)(un.a, {
                        style: {
                            margin: 20,
                            height: 510,
                            width: 450
                        },
                        headStyle: {
                            color: "#F0730D"
                        },
                        cover: Object(s.jsx)("img", {
                            alt: "example",
                            src: "/imgs/games/" + e.game.sku + ".png",
                            style: e.game.valid ? {
                                height: 270
                            } : {
                                height: 270,
                                filter: "brightnes(50%)"
                            }
                        }),
                        children: [
                            /* Object(s.jsx)(yn, {
                            description: i("card-time") + " " + O
                        }), */
                            !e.game.activated && Object(s.jsxs)("div", {
                            style: {
                                height: 160,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [i(e.game.sku + "_DESC", {
                                ns: "games"
                            }), 
                                /* "BOX" !== e.game.info.type && "OFFLINE" !== e.game.info.type && Object(s.jsx)("p", {
                                children: Object(s.jsxs)("b", {
                                    children: [i("card-step1"), Object(s.jsx)("br", {}), i("card-step2"), Object(s.jsx)("br", {}), i("card-step3")]
                                })
                            }), "OFFLINE" == e.game.info.type && Object(s.jsx)("p", {
                                children: Object(s.jsxs)("b", {
                                    children: [i("card-step1"), Object(s.jsx)("br", {}), i("card-step2-offline"), Object(s.jsx)("br", {}), i("card-step3-offline")]
                                })
                            }), "BOX" === e.game.info.type && Object(s.jsx)("p", {
                                children: Object(s.jsx)("b", {
                                    children: i("card-box")
                                })
                            }) */
                            ]
                        }), "GIFT" == e.game.info.type && Object(s.jsx)("p", {
                            children: "GIFT CODE"
                        }), e.game.activated && e.game.valid && Object(s.jsxs)("div", {
                            style: {
                                height: 100,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [" ", Object(s.jsx)(pn.a, {
                                style: {
                                    margin: 10
                                }
                            }), i("card-active")]
                        }), e.game.activated && !e.game.valid && Object(s.jsxs)("div", {
                            style: {
                                height: 100,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [Object(s.jsx)(pn.a, {
                                style: {
                                    margin: 10
                                }
                            }), i("card-inactive"), Object(s.jsx)("br", {}), Object(s.jsxs)("b", {
                                children: ["  ", i("card-free")]
                            }), " ", Object(s.jsx)("a", {
                                onClick: function() {
                                    return e.showReduction()
                                },
                                children: i("card-friends")
                            }), Object(s.jsx)("br", {}), i("card-noplay"), " ", Object(s.jsx)("a", {
                                href: "mailto:info@festiviti.eu",
                                children: i("card-contact")
                            })]
                        }), Object(s.jsx)("div", {
                            style: {
                                textAlign: "center"
                            },
                            children: e.game.valid ? Object(s.jsxs)("div", {
                                children: [
                                    /* Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    onClick: function() {
                                        b(!0)
                                    },
                                    children: i("card-download")
                                }), */
                                    e.game.info.testmode && Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        marginLeft: 20,
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    onClick: function(t) {
                                        return function(e, t) {
                                            var i = {
                                                order: t,
                                                game: e,
                                                testmode: !0
                                            };
                                            console.log(i), localStorage.setItem("game_info", JSON.stringify(i)), console.log(JSON.parse(localStorage.getItem("game_info"))), window.location.href = "/game/" + e + "/test"
                                        }(e.game.sku, e.game.order)
                                    },
                                    children: i("card-test")
                                }), 
                                    /* "OFFLINE" !== e.game.info.type && Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        marginLeft: 20,
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    onClick: function(t) {
                                        e.game.activated ? function(e, t) {
                                            var i = {
                                                order: t,
                                                game: e,
                                                testmode: !1
                                            };
                                            localStorage.setItem("game_info", JSON.stringify(i)), window.location.href = "/game/" + e + "/play"
                                        }(e.game.sku, e.game.order) : d(!0)
                                    },
                                    children: e.game.activated ? i("card-again") : i("card-play")
                                }) */
                                ]
                            }) : Object(s.jsx)(M.a, {
                                type: "primary",
                                style: {
                                    background: "#F0730D",
                                    borderColor: "#F0730D"
                                },
                                href: i(e.game.sku + "_REVIEW"),
                                children: i("review")
                            })
                        })]
                    })]
                })
            }
            var Fn = Object(p.a)()(Bn),
                Nn = un.a.Meta,
                Rn = bn.a.Header;
            bn.a.Content, bn.a.Footer, bn.a.Sider;
            var Gn = function() {
                    return Object(s.jsx)(ht.a, {
                        className: "gutter-row",
                        style: {
                            width: 480
                        },
                        children: Object(s.jsxs)(un.a, {
                            style: {
                                margin: 20,
                                height: 460,
                                width: 450
                            },
                            children: [Object(s.jsx)(gn.a, {
                                loading: !0,
                                active: !0,
                                children: Object(s.jsx)(Nn, {
                                    title: "Card title",
                                    description: "This is the description"
                                })
                            }), Object(s.jsx)(gn.a, {
                                loading: !0,
                                active: !0,
                                children: Object(s.jsx)(Nn, {
                                    title: "Card title",
                                    description: "This is the description"
                                })
                            })]
                        })
                    })
                },
                Yn = function(e) {
                    Object(j.a)(i, e);
                    var t = Object(h.a)(i);

                    function i(e) {
                        var s;
                        return Object(l.a)(this, i), (s = t.call(this, e)).state = {
                            games: [],
                            modalVisible: !0,
                            popupVisible: !1,
                            sku: "",
                            order: "",
                            selectedItem: "1"
                        }, s
                    }
                    return Object(d.a)(i, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            setTimeout((function() {
                                    e.setState({
                                        popupVisible: !1
                                    })
                                }), 3e3),
                                function() {
                                    var e = JSON.parse(localStorage.getItem("user"));
                                    return fetch("http://localhost:8000/api/group_game_list", {
                                        method: "GET",
                                        headers: {
                                            Authorization: "Bearer " + e.token
                                        }
                                    }).then((function(e) {
                                        return e.json()
                                    }))
                                }().then((function(t) {
                                    e.setState({
                                        games: t
                                    })
                                })).catch()
                        }
                    }, {
                        key: "logout",
                        value: function() {
                            localStorage.setItem("user", null), window.location.href = ""
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            this.props.t;
                            return "4" == this.state.selectedItem && (window.location.href = "https://festiviti.eu/pages/festiviti-party"), Object(s.jsxs)(bn.a, {
                                style: {
                                    background: "white"
                                },
                                children: [Object(s.jsxs)(Rn, {
                                    className: "header",
                                    style: {
                                        backgroundColor: "white"
                                    },
                                    children: [Object(s.jsx)("img", {
                                        className: "logo",
                                        src: g,
                                        style: {
                                            width: 180,
                                            margin: "15px 0px 0 0",
                                            float: "left"
                                        }
                                    }), Object(s.jsxs)(Q.a, {
                                        mode: "horizontal",
                                        defaultSelectedKeys: [this.state.selectedItem],
                                        onClick: function(t) {
                                            return e.setState({
                                                selectedItem: t.key
                                            })
                                        },
                                        children: [Object(s.jsx)(Q.a.Item, {
                                            children: "Jouw Activiteiten"
                                        }, "1"), Object(s.jsx)(Q.a.Item, {
                                            children: "Veelgestelde Vragen"
                                        }, "2"), Object(s.jsx)(Q.a.Item, {
                                            children: "Alle Activiteiten"
                                        }, "4"), Object(s.jsx)(M.a, {
                                            id: "logout",
                                            onClick: this.logout,
                                            style: {
                                                float: "right",
                                                marginTop: 15
                                            },
                                            children: "Uitloggen"
                                        })]
                                    })]
                                }), Object(s.jsxs)(Rt.a, {
                                    title: "Ken je de Festiviti foto-wedstrijd al?",
                                    visible: this.state.popupVisible,
                                    onCancel: function() {
                                        return e.setState({
                                            popupVisible: !1
                                        })
                                    },
                                    footer: [Object(s.jsx)(M.a, {
                                        onClick: function() {
                                            return e.setState({
                                                popupVisible: !1,
                                                selectedItem: "3"
                                            })
                                        },
                                        style: {
                                            background: "#F0730D",
                                            color: "white",
                                            borderColor: "#F0730D"
                                        },
                                        children: "Meer Info"
                                    }, "info")],
                                    children: [Object(s.jsx)("p", {
                                        style: {
                                            textAlign: "center",
                                            fontWeight: 600
                                        },
                                        children: "Win elke maand een knutselpakket t.w.v. 60 euro:"
                                    }), Object(s.jsx)("img", {
                                        src: fn,
                                        style: {
                                            width: 300,
                                            marginLeft: 75
                                        }
                                    })]
                                }), Object(s.jsxs)("div", {
                                    style: {
                                        width: 960,
                                        display: "block",
                                        margin: "auto"
                                    },
                                    children: ["1" == this.state.selectedItem && Object(s.jsxs)(jt.a, {
                                        gutter: 16,
                                        children: [0 == this.state.games.length && Gn(), 0 == this.state.games.length && Gn(), this.state.games.map((function(e, t) {
                                            var i = this;
                                            if (!e.info.hidden && "GIFT" != e.info.type) return Object(s.jsx)(ht.a, {
                                                className: "gutter-row",
                                                style: {
                                                    width: 480
                                                },
                                                children: Object(s.jsx)(Hn, {
                                                    game: e,
                                                    showReduction: function() {
                                                        i.setState({
                                                            selectedItem: "3"
                                                        })
                                                    }
                                                })
                                            })
                                        }), this)]
                                    }), "2" == this.state.selectedItem && Object(s.jsx)(An, {}), "3" == this.state.selectedItem && Object(s.jsx)(vn, {
                                        code: this.state.code,
                                        friends: this.state.count
                                    })]
                                })]
                            })
                        }
                    }]), i
                }(n.Component);

            function Mn() {
                return (Mn = Object(jn.a)(dn.a.mark((function e(t, i) {
                    var s, n;
                    return dn.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return s = {
                                    order: i,
                                    game: t,
                                    testmode: !1
                                }, localStorage.setItem("game_info", JSON.stringify(s)), n = JSON.parse(localStorage.getItem("user")), e.next = 5, fetch("http://localhost:8000/api/activate?game=" + s.game + "&order=" + s.order, {
                                    method: "GET",
                                    headers: {
                                        Authorization: "Bearer " + n.token
                                    }
                                }).catch((function(e) {
                                    return alert("Something went wrong. Contact us at info@festiviti.eu")
                                }));
                            case 5:
                                e.sent, window.location.href = "/game/" + t + "/play";
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function Hn(e) {
                var t = Object(an.a)(),
                    i = t.t,
                    a = t.i18n,
                    c = Object(n.useState)(0),
                    r = Object(o.a)(c, 2),
                    l = r[0],
                    d = r[1],
                    j = Object(n.useState)(!1),
                    h = Object(o.a)(j, 2),
                    u = h[0],
                    b = h[1],
                    g = new Date(Date.parse(e.game.start)).toLocaleDateString(a.language),
                    m = new Date(Date.parse(e.game.stop)).toLocaleDateString(a.language);
                return Object(s.jsxs)("div", {
                    children: [Object(s.jsxs)(Rt.a, {
                        title: "Spel Activeren",
                        visible: l,
                        onCancel: function() {
                            d(!1)
                        },
                        footer: [Object(s.jsx)(M.a, {
                            onClick: function() {
                                d(!1)
                            },
                            children: "Annuleren"
                        }, "back"), Object(s.jsx)(M.a, {
                            style: {
                                background: "#F0730D",
                                borderColor: "#F0730D"
                            },
                            type: "primary",
                            loading: u,
                            onClick: function() {
                                b(!0),
                                    function(e, t) {
                                        Mn.apply(this, arguments)
                                    }(e.game.sku, e.game.order)
                            },
                            children: "Spel Activeren"
                        }, "submit")],
                        children: [Object(s.jsxs)("p", {
                            children: ["Je staat op het punt om dit spel te activeren. Vanaf activatie blijft je toegang 48u geldig.", " "]
                        }), Object(s.jsx)("p", {
                            children: "Ga je pas later spelen? Gebruik dan nu de test-modus om alles al te bekijken."
                        })]
                    }), Object(s.jsxs)(un.a, {
                        style: {
                            margin: 20,
                            height: 460,
                            width: 450
                        },
                        headStyle: {
                            color: "#F0730D"
                        },
                        cover: Object(s.jsx)("img", {
                            alt: "example",
                            src: "/imgs/games/" + e.game.sku + ".png",
                            style: e.game.valid ? {
                                height: 270
                            } : {
                                height: 270,
                                filter: "brightnes(50%)"
                            }
                        }),
                        children: [e.game.active ? Object(s.jsx)(Nn, {
                            description: "Toegang vervalt op " + m
                        }) : Object(s.jsx)(Nn, {
                            description: "Toegang vanaf " + g
                        }), !e.game.active && Object(s.jsxs)("div", {
                            style: {
                                height: 100,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [i(e.game.sku + "_DESC"), " "]
                        }), e.game.active && e.game.valid && Object(s.jsxs)("div", {
                            style: {
                                height: 100,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [" ", Object(s.jsx)(pn.a, {
                                style: {
                                    margin: 10
                                }
                            }), "Je hebt toegang tot dit spel tot ", m, ". Neem contact op met Festiviti om de speelperiode te verlengen."]
                        }), e.game.active && !e.game.valid && Object(s.jsxs)("div", {
                            style: {
                                height: 100,
                                display: "block",
                                margin: "0 auto"
                            },
                            children: [Object(s.jsx)(pn.a, {
                                style: {
                                    margin: 10
                                }
                            }), "Je hebt geen toegang meer tot dit spel.", Object(s.jsx)("br", {}), "Je school of vereniging kan contact opnemen met Festiviti om de speelperiode te verlengen."]
                        }), Object(s.jsx)("div", {
                            style: {
                                textAlign: "center"
                            },
                            children: e.game.valid ? Object(s.jsxs)("div", {
                                children: [e.game.info.testmode && Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    onClick: function(t) {
                                        return function(e, t) {
                                            var i = {
                                                order: t,
                                                game: e,
                                                testmode: !0
                                            };
                                            console.log(i), localStorage.setItem("game_info", JSON.stringify(i)), console.log(JSON.parse(localStorage.getItem("game_info"))), window.location.href = "/game/" + e + "/test"
                                        }(e.game.sku, e.game.order)
                                    },
                                    children: "Spel Testen"
                                }), e.game.active ? Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        marginLeft: 20,
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    onClick: function(t) {
                                        e.game.activated ? function(e, t) {
                                            var i = {
                                                order: t,
                                                game: e,
                                                testmode: !1
                                            };
                                            localStorage.setItem("game_info", JSON.stringify(i)), window.location.href = "/game/" + e + "/play"
                                        }(e.game.sku, e.game.order) : d(!0)
                                    },
                                    children: "Spel Spelen"
                                }) : Object(s.jsx)(M.a, {
                                    type: "primary",
                                    style: {
                                        marginLeft: 20,
                                        background: "#F0730D",
                                        borderColor: "#F0730D"
                                    },
                                    disabled: !0,
                                    children: "Spel Spelen"
                                }), " "]
                            }) : Object(s.jsx)(M.a, {
                                type: "primary",
                                style: {
                                    background: "#F0730D",
                                    borderColor: "#F0730D"
                                },
                                href: i(e.game.sku + "_REVIEW"),
                                children: "Review Schrijven"
                            })
                        })]
                    })]
                })
            }
            var Jn = Object(p.a)()(Yn),
                Dn = i(48);
            var Vn = function() {
                    var e = Object(n.useState)(!0),
                        t = Object(o.a)(e, 2),
                        i = t[0],
                        a = t[1],
                        c = Object(n.useState)(null),
                        r = Object(o.a)(c, 2),
                        l = r[0],
                        d = r[1];
                    console.log("backend: file://");
                    localStorage.setItem("user", "{\"token\":\"eyJhbGciOiJIUzUxMiIsImlhdCI6MTcxODk4Mzk2MywiZXhwIjoxNzE4OTg3NTYzfQ.eyJpZCI6NzkyMTkxOTQyNjg4NCwiZW1haWwiOiJmZXN0aXZpdGlAdGFuaXgubmwiLCJjcmVhdGVkIjoxNzE4OTgzOTYzLjgyNzEwNSwiZmlyc3RuYW1lIjoiSiJ9.uOvB7yO8qUyQazKsp5n5waz_mlZDl0SYrzLHonNWnwFPpiZ-8_5zhoxKd13tUpEngA54KHvA8aaIAL_4EhkJSA\"}");
                    /* localStorage.setItem("game_info", "{\"order\":13578,\"game\":\"FB_ER03\",\"testmode\":true}"); */
                    var j = JSON.parse(localStorage.getItem("user"));
                    return fetch("http://localhost:8000/api/ping").catch((function(e) {
                        a(!1)
                    })), j && !l && function(e) {
                        return fetch("http://localhost:8000/api/refresh", {
                            method: "GET",
                            headers: {
                                Authorization: "Bearer " + e.token
                            }
                        }).then((function(e) {
                            return e.json()
                        })).then((function(e) {
                            return localStorage.setItem("user", JSON.stringify(e)), e
                        })).catch((function(e) {
                            return null
                        }))
                    }(j).then((function(e) {
                        return d(e)
                    })), i ? Object(s.jsx)("div", {
                        translate: "no",
                        id: "appRoot",
                        style: {
                            whiteSpace: "pre-line",
                            height: "100%",
                            width: "100%"
                        },
                        children: Object(s.jsx)(n.Suspense, {
                            fallback: Object(s.jsx)("div", {
                                style: {
                                    height: "100%",
                                    width: "100%",
                                    display: "inline-flex",
                                    justifyContent: "center"
                                },
                                children: Object(s.jsx)(G.a, {
                                    size: "large",
                                    style: {
                                        margin: "20%"
                                    }
                                })
                            }),
                            children: Object(s.jsx)(Dn.a, {
                                children: Object(s.jsxs)(A.d, {
                                    children: [ /* Object(s.jsx)(A.b, {
                                        path: "*",
                                        children: Object(s.jsx)(on, {})
                                    }),*/ Object(s.jsx)(A.b, {
                                        path: "/group",
                                        children: l ? Object(s.jsx)(Jn, {}) : Object(s.jsx)(K, {})
                                    }), Object(s.jsx)(A.b, {
                                        path: "/game/:sku/:phase",
                                        children: l || j ? Object(s.jsx)(on, {}) : Object(s.jsx)(A.a, {
                                            to: "/"
                                        })
                                    }), Object(s.jsx)(A.b, {
                                        path: "/admin",
                                        children: Object(s.jsx)(D, {})
                                    }), Object(s.jsx)(A.b, {
                                        path: "/",
                                        children: l ? Object(s.jsx)(Fn, {}) : Object(s.jsx)(N, {})
                                    })]
                                })
                            })
                        })
                    }) : Object(s.jsx)("h1", {
                        children: "Backend Offline"
                    })
                },
                Kn = function(e) {
                    e && e instanceof Function && i.e(3).then(i.bind(null, 659)).then((function(t) {
                        var i = t.getCLS,
                            s = t.getFID,
                            n = t.getFCP,
                            a = t.getLCP,
                            c = t.getTTFB;
                        i(e), s(e), n(e), a(e), c(e)
                    }))
                };
            r.a.render(Object(s.jsx)(a.a.StrictMode, {
                children: Object(s.jsx)(Vn, {})
            }), document.getElementById("root")), Kn()
        }
    },
    [
        [641, 1, 2]
    ]
]);
//# sourceMappingURL=main.350053a5.chunk.js.map